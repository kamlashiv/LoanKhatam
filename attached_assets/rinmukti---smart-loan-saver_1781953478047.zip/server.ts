import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";
import fs from "fs";
import crypto from "crypto";

dotenv.config();

// SECURE USER STORAGE INTERFACES & UTILS FOR BRANDED ENCRYPTED AUTH
const USERS_DB_PATH = path.join(process.cwd(), "users-db.json");

interface DBUser {
  id: string;
  username: string;
  email: string;
  phone: string;
  bank: string;
  salt: string;
  hash: string;
  createdAt: string;
}

function loadUsers(): DBUser[] {
  try {
    if (fs.existsSync(USERS_DB_PATH)) {
      const raw = fs.readFileSync(USERS_DB_PATH, "utf8");
      return JSON.parse(raw) as DBUser[];
    }
  } catch (err) {
    console.error("Error reading users DB, initializing fresh store:", err);
  }
  return [];
}

function saveUsers(users: DBUser[]) {
  try {
    fs.writeFileSync(USERS_DB_PATH, JSON.stringify(users, null, 2), "utf8");
  } catch (err) {
    console.error("Error writing users DB:", err);
  }
}

function hashPassword(password: string, salt: string): string {
  // Real industry-grade PBKDF2 hashing with 1000 rounds and modern SHA-512
  return crypto.pbkdf2Sync(password, salt, 1000, 64, "sha512").toString("hex");
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Set body parser with large limits for image and PDF base64 payloads
  app.use(express.json({ limit: "15mb" }));

  // Serve PWA Custom Manifest & Secure Launcher Icon
  app.get("/app_icon_pwa.jpg", (req, res) => {
    const iconPath = path.join(process.cwd(), "src/assets/images/app_icon_pwa_1781797279861.jpg");
    if (fs.existsSync(iconPath)) {
      res.sendFile(iconPath);
    } else {
      res.status(404).send("Icon not found");
    }
  });

  app.get("/manifest.json", (req, res) => {
    const manifestPath = path.join(process.cwd(), "public/manifest.json");
    if (fs.existsSync(manifestPath)) {
      res.sendFile(manifestPath);
    } else {
      res.status(404).send("Manifest not found");
    }
  });

  // SEED INITIAL SECURE GUEST USER SO GUEST SYSTEM TRANSITIONS WORK SEAMLESSLY
  try {
    const existing = loadUsers();
    const hasGuest = existing.some(u => u.username === "Guest User");
    if (!hasGuest) {
      const guestSalt = crypto.randomBytes(16).toString("hex");
      const guestHash = hashPassword("1234", guestSalt);
      existing.push({
        id: "guest-uuid-001",
        username: "Guest User",
        email: "guest@rinmukti.club",
        phone: "9876543210",
        bank: "HDFC Bank",
        salt: guestSalt,
        hash: guestHash,
        createdAt: new Date().toISOString()
      });
      saveUsers(existing);
    }
  } catch (err) {
    console.error("Failed seeding database", err);
  }

  // Cryptographic Authentication: Registration Endpoint
  app.post("/api/auth/register", (req, res) => {
    try {
      const { username, email, phone, password, bank } = req.body;

      if (!username || !email || !phone || !password) {
        return res.status(400).json({ error: "All account parameters (name, email, phone & secure password) are mandatory." });
      }

      const users = loadUsers();

      // Check unique constraints (username, email, phone)
      const normalizedPhone = phone.trim().replace(/\D/g, "");
      const normalizedEmail = email.trim().toLowerCase();
      const normalizedUser = username.trim();

      if (users.some(u => u.username.toLowerCase() === normalizedUser.toLowerCase())) {
        return res.status(400).json({ error: "Username is already taken by an active profile." });
      }
      if (users.some(u => u.email.toLowerCase() === normalizedEmail)) {
        return res.status(400).json({ error: "Email ID is already registered under an existing vault." });
      }
      if (users.some(u => u.phone.replace(/\D/g, "") === normalizedPhone)) {
        return res.status(400).json({ error: "Phone number is already connected to another secure vault." });
      }

      // Generate random strong dynamic salt
      const salt = crypto.randomBytes(16).toString("hex");
      const hash = hashPassword(password, salt);

      const newUser: DBUser = {
        id: crypto.randomUUID ? crypto.randomUUID() : `rin-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        username: normalizedUser,
        email: normalizedEmail,
        phone: phone.trim(),
        bank: bank || "State Bank of India (SBI)",
        salt,
        hash,
        createdAt: new Date().toISOString()
      };

      users.push(newUser);
      saveUsers(users);

      console.log(`[RinMukti Vault] Registered new secure user: ${normalizedUser} (Phone: ${phone})`);
      return res.json({
        success: true,
        message: "Secure account registered successfully in the encrypted backend vault.",
        user: {
          username: newUser.username,
          email: newUser.email,
          phone: newUser.phone,
          bank: newUser.bank
        }
      });
    } catch (err: any) {
      console.error("Registration route error:", err);
      return res.status(500).json({ error: "Failed to securely register profile due to internal cryptographic exception." });
    }
  });

  // Cryptographic Authentication: Secure Login Endpoint
  app.post("/api/auth/login", (req, res) => {
    try {
      const { loginId, password } = req.body;

      if (!loginId || !password) {
        return res.status(400).json({ error: "Login identifier and secure credentials are required." });
      }

      const users = loadUsers();
      const normalizedId = loginId.trim().toLowerCase();
      const normalizedPhone = loginId.trim().replace(/\D/g, "");

      // Match Login Identifier by Username, Email OR Phone Number (user constraint)
      const user = users.find(u => 
        u.username.toLowerCase() === normalizedId ||
        u.email.toLowerCase() === normalizedId ||
        u.phone.replace(/\D/g, "") === normalizedPhone
      );

      if (!user) {
        return res.status(401).json({ error: "Invalid credentials. Vault matching parameters failed." });
      }

      // Re-hash and compare hashes under full mathematical isolation
      const computedHash = hashPassword(password, user.salt);
      if (computedHash !== user.hash) {
        return res.status(401).json({ error: "Authentication failed. Secure signature mismatch." });
      }

      console.log(`[RinMukti Vault] Authenticated user: ${user.username} successfully via secure signature.`);
      return res.json({
        success: true,
        user: {
          username: user.username,
          email: user.email,
          phone: user.phone,
          bank: user.bank
        }
      });
    } catch (err: any) {
      console.error("Login verification route error:", err);
      return res.status(500).json({ error: "Internal cryptographic shield failure during login signature verification." });
    }
  });

  // Initialize the server-side Gemini client securely
  const genAIKey = process.env.GEMINI_API_KEY;
  const ai = new GoogleGenAI({
    apiKey: genAIKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      }
    }
  });

  // Automatically retries on 503 / 429 transient errors with exponential-ish backoff and falls back to sibling models
  async function generateContentWithFallback(
    aiClient: GoogleGenAI,
    modelName: string,
    contents: any,
    config?: any,
    retriesLeft = 2
  ): Promise<any> {
    try {
      return await aiClient.models.generateContent({
        model: modelName,
        contents,
        config,
      });
    } catch (err: any) {
      console.warn(`[Gemini Exception] Model: ${modelName}. Retries remaining: ${retriesLeft}. Msg:`, err?.message || err);
      
      const isTransient = 
        err.status === 503 || 
        err.status === 429 ||
        err.message?.includes("503") || 
        err.message?.includes("429") ||
        JSON.stringify(err).includes("503") ||
        JSON.stringify(err).includes("429");

      if (isTransient && retriesLeft > 0) {
        const delay = 1200 * (3 - retriesLeft);
        console.log(`Transient exception flagged. Retrying in ${delay}ms...`);
        await new Promise((resolve) => setTimeout(resolve, delay));
        return generateContentWithFallback(aiClient, modelName, contents, config, retriesLeft - 1);
      }

      const fallbacks: Record<string, string> = {
        "gemini-3.5-flash": "gemini-3.1-pro-preview",
        "gemini-3.1-pro-preview": "gemini-3.1-flash-lite",
      };

      const fallbackModel = fallbacks[modelName];
      if (fallbackModel) {
        console.warn(`Attempting fallback cascade: ${modelName} -> ${fallbackModel}`);
        return generateContentWithFallback(aiClient, fallbackModel, contents, config, 1);
      }

      throw err;
    }
  }

  // API route for secure document / image extraction using Gemini
  app.post("/api/extract-loan-file", async (req, res) => {
    try {
      const { fileBase64, mimeType, fileName } = req.body;

      if (!fileBase64 || !mimeType) {
        return res.status(400).json({ error: "No file data or mimeType provided." });
      }

      if (!genAIKey) {
        return res.status(500).json({
          error: "GEMINI_API_KEY is not configured on the server. Please add it to your Settings > Secrets panel."
        });
      }

      // Pre-process prefix of base64 just in case
      let base64Clean = fileBase64;
      if (fileBase64.includes(";base64,")) {
        base64Clean = fileBase64.split(";base64,").pop() || "";
      }

      const promptString = `You are a professional banking assistant.
Your task is to analyze the attached document or image (which could be a loan sanction letter, bank schedule, amortization table, or loan screenshot) and carefully extract the following loan details:
1. Loan principal amount (amount)
2. Annual interest rate percentage (rate, e.g., 8.5)
3. Total loan tenure in years (tenureYears)
4. Loan start date if mentioned (startDate in YYYY-MM format, e.g., 2026-06), otherwise use the current month and year.

Optionally, look for prepayment properties if mentioned:
5. Monthly extra payment (monthlyExtra)
6. Yearly extra prepayment (yearlyExtra)
7. Annual EMI increase percentage / top-up percentage (yearlyIncreasePercent)
8. Any specified lump-sum extra payment milestones (lumpSums)

Ensure to output clean JSON matching the requested schema. Return the most realistic numbers. If a value isn't specified in the document, return the standard defaults.`;

      const response = await generateContentWithFallback(
        ai,
        "gemini-3.5-flash",
        [
          {
            inlineData: {
              mimeType: mimeType,
              data: base64Clean,
            }
          },
          {
            text: promptString
          }
        ],
        {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              amount: { type: Type.NUMBER, description: "Loan principal amount (number). Search carefully for sanction letter amount." },
              rate: { type: Type.NUMBER, description: "Annual interest rate percentage (number, e.g., 8.5, 9.2)." },
              tenureYears: { type: Type.NUMBER, description: "Total tenure of the loan in years. If given in months (e.g. 180 months), divide by 12 to get years." },
              startDate: { type: Type.STRING, description: "Start date of loan in YYYY-MM format. If not found, use current month." },
              monthlyExtra: { type: Type.NUMBER, description: "Monthly extra payment if found, else 0." },
              yearlyExtra: { type: Type.NUMBER, description: "Yearly extra payment if found, else 0." },
              yearlyIncreasePercent: { type: Type.NUMBER, description: "Annual EMI topup increase percentage if found, else 0." },
              lumpSums: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    amount: { type: Type.NUMBER, description: "Lump-sum extra payment amount." },
                    atMonth: { type: Type.INTEGER, description: "Month index of payment from 1 to total tenure months." },
                    label: { type: Type.STRING, description: "Brief short note / label for this prepayment (e.g., Bonus payment)." }
                  },
                  required: ["amount", "atMonth", "label"]
                },
                description: "List of custom lump sum extra payments with indices, if specified."
              }
            },
            required: ["amount", "rate", "tenureYears"]
          }
        }
      );

      const extractedText = response.text;
      if (!extractedText) {
        throw new Error("Gemini returned an empty response.");
      }

      const parsedJSON = JSON.parse(extractedText);
      return res.json({ success: true, data: parsedJSON });

    } catch (error: any) {
      console.error("AI Extraction failed:", error);
      return res.status(500).json({
        error: error.message || "Failed to extract data using AI."
      });
    }
  });

  // API route for interactive personalized AI Debt Coach advice
  app.post("/api/gemini-coach", async (req, res) => {
    try {
      const { query, context } = req.body;

      if (!query) {
        return res.status(400).json({ error: "No user query provided." });
      }

      if (!genAIKey) {
        return res.status(500).json({
          error: "GEMINI_API_KEY is not configured on the server. Please add it to your Settings > Secrets panel."
        });
      }

      // Build personalized context string
      let contextString = "";
      if (context) {
        contextString = `
[Active User Profile & Liabilities Context]
Username: ${context.username || "User"}
Current Bank: ${context.bank || "N/A"}
Active Loan details:
- Base loan amount: ${context.amount ? `₹${context.amount.toLocaleString()}` : "N/A"}
- Interest rate: ${context.rate || "N/A"}% p.a.
- Tenure: ${context.tenureYears || "N/A"} years
- Current Prepayments:
  * Extra monthly payment: ₹${context.monthlyExtra || 0}
  * Extra yearly payment: ₹${context.yearlyExtra || 0}
  * Annual EMI top-up rate: ${context.yearlyIncreasePercent || 0}%

Selected Prepayment Strategy: ${context.activeStrategy || "None selected"}
List of Multi-Liability Simulator Debts inside user's dashboard:
${(context.debts || []).map((d: any, idx: number) => `Debt #${idx+1}: ${d.name} | Balance: ₹${d.balance} | Rate: ${d.rate}% | EMI: ₹${d.emi}`).join("\n")}
`;
      }

      const systemInstruction = `You are the ultimate premier 'AI Debt Elimination Coach' expert for Indian borrowers.
You analyze user home loans, personal loans, auto loans, and credit cards. You guide them with clear math on how to compound their interest savings.
Your knowledge includes:
- Indian banking guidelines & RBI policies on interest reset, APR disclosures, and card rules.
- Debt reduction methodologies (Debt Snowball, Debt Avalanche, Custom Hybrid plans).
- Indian tax landscape under Chapter VI-A (Section 80C up to ₹1.5L, Section 24b up to ₹2L for interest deductions).
- Expected long-term Index & Equity mutual funds returns (~12% p.a.) vs. loan prepayment guaranteed savings.

Rule constraints on responses:
1. Provide actionable advice tailored directly to the [Active User Profile & Liabilities Context] if present.
2. Keep math clear, breaking down exact numbers (e.g., total interest saved, years saved, or equivalent tax yields).
3. Do not formulate complex lists of codes, instead prioritize direct conversational answers with elegant markdown spacing.
4. If asked about CRED Money or AA (Account Aggregators), proudly explain how the app allows trusted, consented, encrypted fetch from major NBFC-AAs like Finvu and OneMoney.
`;

      const response = await generateContentWithFallback(
        ai,
        "gemini-3.5-flash",
        [
          {
            text: `${systemInstruction}\n\nClient Personal Details context:\n${contextString}\n\nUser Question: ${query}`
          }
        ]
      );

      const reply = response.text || "I am sorry, but I couldn't formulate a recommendation at this time.";
      return res.json({ success: true, reply });

    } catch (error: any) {
      console.error("AI coaching failure:", error);
      return res.status(500).json({ error: error.message || "Coaching consultation errored out." });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    // Serve production static assets
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
