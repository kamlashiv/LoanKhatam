import { useState, useEffect, ChangeEvent } from "react";
import { LoanInput, PrepaymentInput, SavedProfile, LoanReport } from "./types";
import { calculateLoanReport, parseUploadedFileContent } from "./utils/loanCalculator";
import Header from "./components/Header";
import LoanCalculatorForm from "./components/LoanCalculatorForm";
import EducationalHacks from "./components/EducationalHacks";
import LoanSummaryCards from "./components/LoanSummaryCards";
import SavingsCharts from "./components/SavingsCharts";
import AmortizationScheduleTable from "./components/AmortizationScheduleTable";
import SecureLoginPortal from "./components/SecureLoginPortal";
import LoanPieChart from "./components/LoanPieChart";
import BankLetterGenerator from "./components/BankLetterGenerator";
import { FileText, Sparkles, HelpCircle, RefreshCcw, LogOut, Trash2, Shield, User, Calculator, Mail } from "lucide-react";
import { translations } from "./utils/translations";
import FounderStudio, { OwnerSettings } from "./components/FounderStudio";
import AIDebtCoach from "./components/AIDebtCoach";
import ScheduleComparisonChart from "./components/ScheduleComparisonChart";
import TopUpBuster from "./components/TopUpBuster";


export default function App() {
  // Region-Based Language Selection State: Defaults automatically to English ('en')
  const [lang, setLang] = useState<"en" | "hi" | "bilingual">("en");

  // Active main tab state: dashboard vs tools vs ai_coach
  const [activeMainTab, setActiveMainTab] = useState<"dashboard" | "tools" | "ai_coach">("dashboard");

  // Load translations dictionary
  const t = translations[lang];

  // 👑 APP OWNER CONFIGURATION WORKSPACE STATE & FALLBACK ENGINE
  const defaultOwnerSettings: OwnerSettings = {
    appNameEn: "SMART LOAN PREPAYMENT SAVER",
    appNameHi: "लोन प्रीपेमेंट और ब्याज कैलकुलेटर (Loan Prepayment Saver)",
    appSubtitleEn: "Calculate compounding interest saved by making dynamic extra repayments",
    appSubtitleHi: "नियमित अतिरिक्त किस्तों द्वारा लाखों का ब्याज बचाएं और अपना लोन आधा समय से पहले चुकाएं!",
    primaryColor: "indigo",
    borderStyle: "dashed",
    layoutOrder: ["summary", "hacks", "inputsAndCharts", "schedule", "pieAndLetter"],
    hiddenSections: {},
    announcementEn: "⚡ SBI SPECIAL PREPAYMENT BENEFIT CAMPAIGN: Lock in savings of up to 45% today!",
    announcementHi: "⚡ बैंक अलर्ट: अतिरिक्त लोन चुकाने पर बैंकों का नया बचत नियम आज से लागू, यहाँ गणना करें!",
    showAnnouncement: true,
    boxThemes: {
      summary: "default",
      hacks: "default",
      inputsAndCharts: "default",
      schedule: "default",
      pieAndLetter: "default",
    },
  };

  const [ownerSettings, setOwnerSettings] = useState<OwnerSettings>(() => {
    try {
      const stored = localStorage.getItem("loan_saver_owner_settings_v3");
      if (stored) {
        return { ...defaultOwnerSettings, ...JSON.parse(stored) };
      }
    } catch (e) {
      console.error("Owner settings loading failed:", e);
    }
    return defaultOwnerSettings;
  });

  const handleResetOwnerSettings = () => {
    setOwnerSettings(defaultOwnerSettings);
    localStorage.removeItem("loan_saver_owner_settings_v3");
  };

  // Synchronize configuration to persistent client state
  useEffect(() => {
    localStorage.setItem("loan_saver_owner_settings_v3", JSON.stringify(ownerSettings));
  }, [ownerSettings]);

  // 0. Secure User authentication session state
  const [currentUser, setCurrentUser] = useState<{username: string, pin: string, bank: string} | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  // 1. Core Loan States - Default initialized with a beautiful, realistic Home Loan of ₹25 Lakhs
  const [loanInput, setLoanInput] = useState<LoanInput>({
    amount: 2500000,
    rate: 8.5,
    tenureYears: 20,
    startDate: new Date().toISOString().slice(0, 7), // YYYY-MM
  });

  // 2. Extra Prepayment States
  const [prepayments, setPrepayments] = useState<PrepaymentInput>({
    monthlyExtra: 0,
    yearlyExtra: 0,
    yearlyIncreasePercent: 0,
    lumpSums: [],
  });

  // Active Strategy name tracking for the guide section
  const [activeStrategyName, setActiveStrategyName] = useState<string>("");

  // 3. Saved profiles in localStorage
  const [savedProfiles, setSavedProfiles] = useState<SavedProfile[]>([]);

  // 4. Load saved session and profiles on startup safely
  useEffect(() => {
    try {
      const storedUser = localStorage.getItem("loan_saver_currentUser_v2");
      if (storedUser) {
        const parsedUser = JSON.parse(storedUser);
        setCurrentUser(parsedUser);

        // Load profiles belonging specifically to this authenticated user
        const storedProfiles = localStorage.getItem(`loan_saver_profiles_${parsedUser.username}`);
        if (storedProfiles) {
          setSavedProfiles(JSON.parse(storedProfiles));
        } else {
          const initialDummy: SavedProfile[] = [
            {
              id: "dummy-home",
              name: "SBI Home Loan - ₹25L",
              input: { amount: 2500000, rate: 8.5, tenureYears: 20, startDate: "2026-06" },
              prepayments: { monthlyExtra: 3500, yearlyExtra: 0, yearlyIncreasePercent: 5, lumpSums: [] },
              createdAt: new Date().toISOString(),
            }
          ];
          setSavedProfiles(initialDummy);
          localStorage.setItem(`loan_saver_profiles_${parsedUser.username}`, JSON.stringify(initialDummy));
        }
      }
    } catch (e) {
      console.error("Local session loading failed:", e);
    }
  }, []);

  // Secure User Portal Login Handler
  const handleUserLogin = (username: string, pin: string, bank: string) => {
    const userObj = { username, pin, bank };
    setCurrentUser(userObj);
    localStorage.setItem("loan_saver_currentUser_v2", JSON.stringify(userObj));

    // Load or bootstrap profiles for this user securely
    const stored = localStorage.getItem(`loan_saver_profiles_${username}`);
    if (stored) {
      setSavedProfiles(JSON.parse(stored));
    } else {
      const initialDummy: SavedProfile[] = [
        {
          id: "dummy-home",
          name: `${bank} Home - ₹25L`,
          input: { amount: 2500000, rate: 8.5, tenureYears: 20, startDate: "2026-06" },
          prepayments: { monthlyExtra: 3000, yearlyExtra: 0, yearlyIncreasePercent: 5, lumpSums: [] },
          createdAt: new Date().toISOString(),
        }
      ];
      setSavedProfiles(initialDummy);
      localStorage.setItem(`loan_saver_profiles_${username}`, JSON.stringify(initialDummy));
    }
  };

  // Secure user logout handler
  const handleUserLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem("loan_saver_currentUser_v2");
    setSavedProfiles([]);
    setShowDeleteConfirm(false);
  };

  // Securely delete all accounts comparison metadata
  const handleDeleteAllUserData = () => {
    if (!currentUser) return;
    localStorage.removeItem(`loan_saver_profiles_${currentUser.username}`);
    localStorage.removeItem("loan_saver_currentUser_v2");
    setCurrentUser(null);
    setSavedProfiles([]);
    setShowDeleteConfirm(false);
  };

  // Compute live report on every state input change
  const activeReport: LoanReport = calculateLoanReport(loanInput, prepayments);

  // Apply quick pre-set strategy hacks
  const handleApplyStrategy = (strat: {
    monthlyExtra: number;
    yearlyExtra: number;
    yearlyIncreasePercent: number;
    description: string;
    name: string;
  }) => {
    setPrepayments({
      ...prepayments,
      monthlyExtra: strat.monthlyExtra,
      yearlyExtra: strat.yearlyExtra,
      yearlyIncreasePercent: strat.yearlyIncreasePercent,
    });
    setActiveStrategyName(strat.name);
  };

  // Reset all prepayments back to normal/standard
  const handleResetPrepayments = () => {
    setPrepayments({
      monthlyExtra: 0,
      yearlyExtra: 0,
      yearlyIncreasePercent: 0,
      lumpSums: [],
    });
    setActiveStrategyName("");
  };

  // Profile triggers under current isolated user namespace
  const handleSaveProfile = (name: string) => {
    const newProfile: SavedProfile = {
      id: Math.random().toString(36).substr(2, 9),
      name,
      input: { ...loanInput },
      prepayments: { ...prepayments },
      createdAt: new Date().toISOString(),
    };

    const updated = [...savedProfiles, newProfile];
    setSavedProfiles(updated);
    if (currentUser) {
      localStorage.setItem(`loan_saver_profiles_${currentUser.username}`, JSON.stringify(updated));
    }
  };

  // Auto save profile on every file extraction success automatically!
  const handleAutoSaveUploadedProfile = (fileName: string, parsed: any) => {
    const cleanName = fileName.replace(/\.[^/.]+$/, "");
    const autoName = lang === "en" 
      ? `Extracted: ${cleanName}` 
      : lang === "hi" 
      ? `निकाला: ${cleanName}` 
      : `Extracted: ${cleanName}`;

    const newProfile: SavedProfile = {
      id: "auto-" + Math.random().toString(36).substr(2, 9),
      name: autoName,
      input: {
        amount: parsed.amount ?? loanInput.amount,
        rate: parsed.rate ?? loanInput.rate,
        tenureYears: parsed.tenureYears ?? loanInput.tenureYears,
        startDate: parsed.startDate || loanInput.startDate,
      },
      prepayments: {
        monthlyExtra: parsed.monthlyExtra ?? prepaymentInputFallback().monthlyExtra,
        yearlyExtra: parsed.yearlyExtra ?? prepaymentInputFallback().yearlyExtra,
        yearlyIncreasePercent: parsed.yearlyIncreasePercent ?? prepaymentInputFallback().yearlyIncreasePercent,
        lumpSums: parsed.lumpSums ?? prepaymentInputFallback().lumpSums,
      },
      createdAt: new Date().toISOString(),
    };

    setSavedProfiles((prev) => {
      const updated = [...prev, newProfile];
      if (currentUser) {
        localStorage.setItem(`loan_saver_profiles_${currentUser.username}`, JSON.stringify(updated));
      }
      return updated;
    });
  };

  const prepaymentInputFallback = () => ({
    monthlyExtra: prepayments.monthlyExtra,
    yearlyExtra: prepayments.yearlyExtra,
    yearlyIncreasePercent: prepayments.yearlyIncreasePercent,
    lumpSums: prepayments.lumpSums,
  });

  const handleSelectProfile = (id: string) => {
    const found = savedProfiles.find((p) => p.id === id);
    if (found) {
      setLoanInput({ ...found.input });
      setPrepayments({ ...found.prepayments });
      // Clear strategy spotlight if it's custom
      setActiveStrategyName("");
    }
  };

  const handleDeleteProfile = (id: string) => {
    const updated = savedProfiles.filter((p) => p.id !== id);
    setSavedProfiles(updated);
    if (currentUser) {
      localStorage.setItem(`loan_saver_profiles_${currentUser.username}`, JSON.stringify(updated));
    }
  };

  // Handle uploaded file parser
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [showUploadTemplateGuide, setShowUploadTemplateGuide] = useState(false);
  const [isExtracting, setIsExtracting] = useState<boolean>(false);
  const [extractionFeedback, setExtractionFeedback] = useState<string | null>(null);

  const handleFileUpload = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const fileExtension = file.name.split(".").pop()?.toLowerCase() || "";
    setUploadError(null);
    setExtractionFeedback(null);

    // If it's a standard simple text file, do fast local extraction
    if (["json", "csv", "txt"].includes(fileExtension)) {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const textStr = e.target?.result as string;
          const parsed = parseUploadedFileContent(textStr, fileExtension);

          setLoanInput((prev) => ({
            ...prev,
            amount: parsed.amount ?? prev.amount,
            rate: parsed.rate ?? prev.rate,
            tenureYears: parsed.tenureYears ?? prev.tenureYears,
          }));

          setPrepayments((prev) => ({
            ...prev,
            monthlyExtra: parsed.monthlyExtra ?? prev.monthlyExtra,
            yearlyExtra: parsed.yearlyExtra ?? prev.yearlyExtra,
            yearlyIncreasePercent: parsed.yearlyIncreasePercent ?? prev.yearlyIncreasePercent,
            lumpSums: parsed.lumpSums ?? prev.lumpSums,
          }));

          setExtractionFeedback(
            lang === "en"
              ? `File '${file.name}' loaded successfully!`
              : `फ़ाइल '${file.name}' सफलतापूर्वक लोड की गई है!`
          );
          // Auto save profile on successful load!
          handleAutoSaveUploadedProfile(file.name, parsed);
          // Auto clear after 6 seconds
          setTimeout(() => setExtractionFeedback(null), 6000);
        } catch (err: any) {
          setUploadError(err.message || "File parsing failed.");
        }
      };
      reader.readAsText(file);
    } else {
      // It is a binary document (PDF or image). Send to our server-side secure Gemini extractor!
      setIsExtracting(true);
      setExtractionFeedback(t.extractingDocument);

      const reader = new FileReader();
      reader.onload = async (e) => {
        try {
          const dataUrl = e.target?.result as string;
          const base64Clean = dataUrl.split(";base64,").pop() || "";

          let mimeType = file.type;
          if (!mimeType) {
            if (fileExtension === "pdf") mimeType = "application/pdf";
            else if (["jpg", "jpeg"].includes(fileExtension)) mimeType = "image/jpeg";
            else if (fileExtension === "png") mimeType = "image/png";
            else if (fileExtension === "webp") mimeType = "image/webp";
            else mimeType = "application/octet-stream";
          }

          const response = await fetch("/api/extract-loan-file", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              fileBase64: base64Clean,
              mimeType: mimeType,
              fileName: file.name,
            }),
          });

          if (!response.ok) {
            const errData = await response.json();
            throw new Error(errData.error || "Failed to process the document.");
          }

          const resData = await response.json();
          if (resData.success && resData.data) {
            const parsed = resData.data;

            setLoanInput((prev) => ({
              ...prev,
              amount: parsed.amount ?? prev.amount,
              rate: parsed.rate ?? prev.rate,
              tenureYears: parsed.tenureYears ?? prev.tenureYears,
            }));

            setPrepayments((prev) => ({
              ...prev,
              monthlyExtra: parsed.monthlyExtra ?? prev.monthlyExtra,
              yearlyExtra: parsed.yearlyExtra ?? prev.yearlyExtra,
              yearlyIncreasePercent: parsed.yearlyIncreasePercent ?? prev.yearlyIncreasePercent,
              lumpSums: parsed.lumpSums ?? prev.lumpSums,
            }));

            setExtractionFeedback(
              lang === "en"
                ? `Successfully extracted loan details from ${file.name} using Gemini AI!`
                : `जेमिनी एआई द्वारा ${file.name} से ऋण विवरण सफलतापूर्वक निकाला गया!`
            );
            // Auto save profile on successful extraction!
            handleAutoSaveUploadedProfile(file.name, parsed);
            setTimeout(() => setExtractionFeedback(null), 7000);
          } else {
            throw new Error("Invalid format returned by the server extractor.");
          }
        } catch (err: any) {
          console.error("Extraction error:", err);
          setUploadError(err.message || "Failed to parse document. Please make sure GEMINI_API_KEY is configured.");
        } finally {
          setIsExtracting(false);
        }
      };

      reader.onerror = () => {
        setUploadError("Could not read local file. Please try selecting again.");
        setIsExtracting(false);
      };

      reader.readAsDataURL(file);
    }
  };
  if (!currentUser) {
    return (
      <div className="min-h-screen bg-slate-50/50 dark:bg-slate-950 pb-16 text-slate-800 dark:text-slate-200 antialiased selection:bg-indigo-500 selection:text-white">
        <Header lang={lang} onLangChange={setLang} ownerSettings={ownerSettings} hideLangSelector={true} />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SecureLoginPortal onLogin={handleUserLogin} lang={lang} />
        </div>
        <footer className="mt-16 border-t border-slate-100 dark:border-slate-900 py-8 text-center text-xs text-slate-400 dark:text-slate-500 font-medium">
          <div className="max-w-7xl mx-auto px-4">
            <p>© 2026 लोनबचत - Loan Saver & Payoff Platform. All mathematical calculations follow global banking standards.</p>
          </div>
        </footer>
      </div>
    );
  }

  const getBoxThemeClasses = (sectionKey: string) => {
    const chosen = ownerSettings.boxThemes?.[sectionKey] || "default";
    switch (chosen) {
      case "emerald":
        return "bg-emerald-500/5 dark:bg-emerald-950/15 border border-emerald-500/25 dark:border-emerald-800/35 p-6 rounded-3xl shadow-[0_4px_24px_rgba(16,185,129,0.03)] transition-all duration-300";
      case "amber":
        return "bg-amber-500/5 dark:bg-amber-950/15 border border-amber-500/25 dark:border-amber-800/35 p-6 rounded-3xl shadow-[0_4px_24px_rgba(245,158,11,0.03)] transition-all duration-300";
      case "purple":
        return "bg-purple-500/5 dark:bg-purple-950/15 border border-purple-500/25 dark:border-purple-800/35 p-6 rounded-3xl shadow-[0_4px_24px_rgba(168,85,247,0.03)] transition-all duration-300";
      case "rose":
        return "bg-rose-500/5 dark:bg-rose-950/15 border border-rose-500/25 dark:border-rose-800/35 p-6 rounded-3xl shadow-[0_4px_24px_rgba(244,63,94,0.03)] transition-all duration-300";
      case "dark":
        return "bg-slate-900/95 dark:bg-slate-900/90 border border-slate-850 dark:border-slate-800/80 p-6 rounded-3xl shadow-xl text-slate-100 transition-all duration-300";
      case "default":
      default:
        return "p-0 rounded-none border-0 shadow-none transition-all duration-300";
    }
  };

  return (
    <div className="min-h-screen bg-slate-50/50 dark:bg-slate-950 pb-16 text-slate-800 dark:text-slate-200 antialiased selection:bg-indigo-500 selection:text-white font-sans">
      {/* 🧭 NAVIGATION HEADER WITH LANGUAGE CONTROLLER */}
      <Header lang={lang} onLangChange={setLang} ownerSettings={ownerSettings} />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        
        {/* 👤 AUTHENTICATED USER SESSION STATUS BAR */}
        <div className="flex flex-col md:flex-row justify-between items-stretch md:items-center p-5 bg-gradient-to-r from-slate-900 to-indigo-950 border border-slate-800 text-white rounded-3xl gap-4 shadow-md">
          <div className="flex items-center space-x-3.5">
            <div className="p-3 bg-white/10 text-emerald-400 rounded-2xl shrink-0">
              <User className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
                <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-widest">{lang === "en" ? "Isolated Secure Vault" : "सुरक्षित तिजोरी सक्रिय"}</span>
              </div>
              <h3 className="text-base font-black tracking-tight mt-0.5">
                {currentUser.username} <span className="text-xs text-slate-400 font-semibold inline-block ml-1">({currentUser.bank})</span>
              </h3>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {/* Toggle delete confirm inline to avoid window.confirm */}
            {showDeleteConfirm ? (
              <div className="bg-slate-950 p-2.5 rounded-2xl border border-rose-500/30 flex items-center gap-3 shrink-0">
                <span className="text-[10px] font-bold text-rose-400 max-w-[130px] leading-tight">
                  {lang === "en" ? "Delete all profile records permanently?" : "सभी डेटा स्थायी रूप से हटा दें?"}
                </span>
                <button
                  onClick={handleDeleteAllUserData}
                  className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white text-[10px] font-black rounded-lg transition-colors cursor-pointer"
                >
                  {lang === "en" ? "Yes, Delete" : "हां, हटाएं"}
                </button>
                <button
                  onClick={() => setShowDeleteConfirm(false)}
                  className="px-3 py-1.5 bg-slate-800 text-slate-350 text-[10px] font-black rounded-lg transition-colors cursor-pointer"
                >
                  {lang === "en" ? "Cancel" : "रद्द करें"}
                </button>
              </div>
            ) : (
              <button
                onClick={() => setShowDeleteConfirm(true)}
                className="px-3.5 py-2 hover:bg-rose-950/20 text-rose-400 hover:text-rose-300 text-xs font-bold rounded-xl transition cursor-pointer flex items-center space-x-1 border border-rose-500/20"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>{lang === "en" ? "Delete All My Data" : "मेरा सारा डेटा हटाएं"}</span>
              </button>
            )}

            <button
              onClick={handleUserLogout}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-750 text-slate-350 hover:text-white text-xs font-bold rounded-xl transition cursor-pointer flex items-center space-x-1.5"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>{lang === "en" ? "Lock Vault" : "लॉक्स आउट"}</span>
            </button>
          </div>
        </div>

        {/* 👑 INJECTED BRAND STYLING & KEY ACCENT COLOUR DEFINITIONS FOR APP OWNER */}
        <style>{`
          :root {
            --brand-primary: ${
              ownerSettings.primaryColor === "emerald" ? "#059669" :
              ownerSettings.primaryColor === "purple" ? "#7c3aed" :
              ownerSettings.primaryColor === "rose" ? "#e11d48" :
              ownerSettings.primaryColor === "amber" ? "#d97706" :
              "#4f46e5" /* indigo base */
            };
            --brand-light: ${
              ownerSettings.primaryColor === "emerald" ? "#ecfdf5" :
              ownerSettings.primaryColor === "purple" ? "#f5f3ff" :
              ownerSettings.primaryColor === "rose" ? "#fff1f2" :
              ownerSettings.primaryColor === "amber" ? "#fffbeb" :
              "#eef2ff" /* indigo light */
            };
            --brand-border-style: ${ownerSettings.borderStyle === "none" ? "solid" : ownerSettings.borderStyle};
            --brand-border-width: ${ownerSettings.borderStyle === "none" ? "0px" : "1px"};
          }
          
          /* Override color utilities to respect creator branding */
          .bg-indigo-650, .bg-indigo-600 {
            background-color: var(--brand-primary) !important;
          }
          .text-indigo-600, .text-indigo-700, .text-indigo-650 {
            color: var(--brand-primary) !important;
          }
          .border-indigo-100, .border-slate-100, .border-slate-200 {
            border-style: var(--brand-border-style) !important;
            border-width: var(--brand-border-width) !important;
          }
          .bg-indigo-50 {
            background-color: var(--brand-light) !important;
          }
        `}</style>

        {/* 👑 APP OWNER CONFIG WORKSPACE - RESTRICTED TO CERTIFIED ADMINS ONLY */}
        {currentUser && (
          (currentUser.username.toLowerCase() === "shiva chand" && currentUser.pin === "2026") ||
          (currentUser.username.toLowerCase() === "admin" && currentUser.pin === "2026")
        ) ? (
          <FounderStudio
            settings={ownerSettings}
            onUpdateSettings={setOwnerSettings}
            lang={lang}
            onReset={handleResetOwnerSettings}
          />
        ) : null}

        {/* 📢 OWNER ANNOUNCEMENT LIVE MARQUEE CAMPAIGN */}
        {ownerSettings.showAnnouncement && (
          <div id="live-marquee-notice" className="bg-amber-450/10 dark:bg-amber-950/20 border border-amber-400/40 text-amber-800 dark:text-amber-300 rounded-2xl py-2 px-4 text-xs font-bold flex items-center space-x-2.5 animate-fadeIn">
            <span className="shrink-0 font-extrabold text-[10px] bg-amber-400 text-slate-900 px-2.5 py-0.5 rounded-lg uppercase tracking-wider flex items-center gap-1 shrink-0 select-none">
              <Sparkles className="w-3 h-3" />
              {lang === "en" ? "Broadcast Alert" : "लाइव सुचना"}
            </span>
            <div className="flex-grow overflow-hidden font-semibold">
              <marquee className="text-xs font-bold text-amber-700 dark:text-amber-400" scrollamount="3">
                {lang === "en" ? ownerSettings.announcementEn : ownerSettings.announcementHi}
              </marquee>
            </div>
          </div>
        )}

        {/* 🧭 NAVIGATION TAB CONTRASTS - SWAP BETWEEN CORE ANALYSIS & INTERACTIVE LETTER DISPATCH */}
        <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800/85 p-2 rounded-2xl shadow-xs flex flex-col md:flex-row justify-between items-center gap-3">
          <div className="flex flex-wrap gap-2 w-full md:w-auto">
            <button
              id="tab-dashboard-lnk"
              onClick={() => setActiveMainTab("dashboard")}
              style={{ fontSize: "14px" }}
              className={`flex-1 md:flex-none flex items-center justify-center space-x-2 px-5 py-3 rounded-xl font-black transition cursor-pointer select-none ${
                activeMainTab === "dashboard"
                  ? "bg-slate-900 text-white dark:bg-white dark:text-slate-950 shadow-xs"
                  : "text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/50"
              }`}
            >
              <Calculator className="w-4 h-4" />
              <span>{lang === "en" ? "Home Loan Savings Analyser" : lang === "hi" ? "लोन बचत विश्लेषक" : "Savings Analyser"}</span>
            </button>
            <button
              id="tab-tools-lnk"
              onClick={() => setActiveMainTab("tools")}
              style={{ fontSize: "14px" }}
              className={`flex-1 md:flex-none flex items-center justify-center space-x-2 px-5 py-3 rounded-xl font-black transition cursor-pointer select-none ${
                activeMainTab === "tools"
                  ? "bg-indigo-650 text-white shadow-xs"
                  : "text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/50"
              }`}
            >
              <Mail className="w-4 h-4 animate-pulse text-rose-300" />
              <span>{lang === "en" ? "Send Request to Bank (Official Letters)" : lang === "hi" ? "बैंक आवेदन पत्र जेनरेटर" : "Bank Letters & Benefits"}</span>
            </button>
            <button
              id="tab-coach-lnk"
              onClick={() => setActiveMainTab("ai_coach")}
              className={`flex-1 md:flex-none flex items-center justify-center space-x-2 px-5 py-3 rounded-xl font-black transition cursor-pointer select-none ${
                activeMainTab === "ai_coach"
                  ? "bg-amber-500 text-slate-950 shadow-xs"
                  : "text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/50"
              }`}
            >
              <Sparkles className="w-4 h-4 text-emerald-600 dark:text-emerald-400 animate-pulse" />
              <span style={{ fontSize: "14px" }}>{lang === "en" ? "AI Debt Elimination Coach" : lang === "hi" ? "एआई कर्ज मुक्ति कोच" : "AI Coach"}</span>
            </button>
          </div>

          <div className="hidden md:flex items-center space-x-2.5 px-3 text-slate-450 dark:text-slate-500 text-[10.5px] font-bold uppercase tracking-wider">
            <div className="flex items-center space-x-1">
              <span className="w-2 h-2 rounded-full bg-indigo-500 animate-ping inline-block" />
              <span className="w-2 h-2 rounded-full bg-indigo-500 absolute inline-block" />
            </div>
            <span style={{ fontSize: "14px" }}>{lang === "en" ? "Active Calculation Engine" : "सक्रिय गणना इंजन"}</span>
          </div>
        </div>

        {/* 🌟 ACTION CONTROLS / UTILITY BAR */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm">
          <div>
            <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white tracking-tight flex items-center gap-1.5">
              <Sparkles className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
              {lang === "en" ? "Interactive Prepayment Hub" : "त्वरित बचत और भुगतान हब"}
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 font-medium">
              {lang === "en" ? "Manage prepayments and view custom action templates dynamically" : "अपने एक्स्ट्रा बजट और अपलोड क्रेडेंशियल्स का प्रबंधन करें"}
            </p>
          </div>

          <div className="flex flex-wrap gap-2.5 w-full sm:w-auto">
            <button
              id="reset-prepayments-btn"
              onClick={handleResetPrepayments}
              className="flex-1 sm:flex-none px-4 py-2 bg-slate-100 hover:bg-slate-205 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold rounded-xl transition duration-200 cursor-pointer flex items-center justify-center space-x-1 border border-slate-200/50 dark:border-transparent active:scale-95"
            >
              <RefreshCcw className="w-4 h-4" />
              <span>{t.resetSavingsBtn}</span>
            </button>
            <button
              id="toggle-template-guide"
              onClick={() => setShowUploadTemplateGuide(!showUploadTemplateGuide)}
              className="flex-1 sm:flex-none px-4 py-2 bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/40 dark:hover:bg-indigo-900/40 text-indigo-700 dark:text-indigo-400 text-xs font-bold rounded-xl transition duration-200 cursor-pointer flex items-center justify-center space-x-1 active:scale-95"
            >
              <HelpCircle className="w-4 h-4" />
              <span>{t.uploadFormatBtn}</span>
            </button>
          </div>
        </div>

        {/* 📂 OPTIONAL: UPLOAD FORMAT INSTRUCTIONS GUIDE */}
        {showUploadTemplateGuide && (
          <div className="bg-gradient-to-r from-slate-900 to-indigo-950 text-white rounded-2xl p-6 shadow-sm border border-slate-800 animate-fadeIn">
            <div className="flex justify-between items-start">
              <h3 className="font-semibold text-sm sm:text-base text-slate-100 mb-2 flex items-center gap-2">
                <FileText className="w-5 h-5 text-indigo-400" />
                {t.uploadGuideTitle}
              </h3>
              <button
                id="close-guide-btn"
                onClick={() => setShowUploadTemplateGuide(false)}
                className="text-xs text-slate-400 hover:text-white bg-white/10 px-2 py-1 rounded transition cursor-pointer"
              >
                {t.closeBtn}
              </button>
            </div>
            <p className="text-xs text-slate-350 mb-4 leading-relaxed font-semibold">
              {t.uploadGuideDesc} <span className="text-amber-400 font-bold">{t.multiFormatUploadGuide}</span>
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* CSV column */}
              <div className="bg-slate-950/70 p-4 rounded-xl border border-slate-800">
                <p className="text-xs font-bold text-amber-400 mb-1.5">{t.csvFormatGuide}</p>
                <code className="text-[11px] text-indigo-300 block leading-tight whitespace-pre font-mono">
                  amount,2500000{"\n"}
                  rate,8.5{"\n"}
                  tenureYears,15{"\n"}
                  monthlyExtra,2000{"\n"}
                  yearlyExtra,10000{"\n"}
                  yearlyIncreasePercent,5
                </code>
                <div className="relative inline-block group/tooltip mt-2.5">
                  <div className="inline-flex items-center gap-1.5 bg-white/5 border border-white/10 px-2 py-0.5 rounded text-[9px] font-bold cursor-help select-none transition hover:bg-white/10">
                    <span className="text-[9px] font-black uppercase text-amber-400">
                      💡 {lang === "en" ? "Important Note" : lang === "hi" ? "महत्वपूर्ण नोट" : "Note / नोट"}
                    </span>
                    <span className="text-amber-500 font-bold">&#9662;</span>
                  </div>
                  {/* ABSOLUTE FLOATING TOOLTIP */}
                  <div className="absolute bottom-full left-0 mb-2 w-72 p-3 bg-slate-950 text-white rounded-xl shadow-2xl border border-slate-800 text-[10.5px] leading-relaxed font-semibold transition-all duration-200 origin-bottom opacity-0 pointer-events-none scale-95 translate-y-1 group-hover/tooltip:opacity-100 group-hover/tooltip:pointer-events-auto group-hover/tooltip:scale-100 group-hover/tooltip:translate-y-0 z-50">
                    <div className="font-extrabold text-[8.5px] uppercase text-amber-400 mb-1 tracking-wider">
                      {lang === "en" ? "CSV Structuring Rule" : "कौमा सेपेरेटेड नियम"}
                    </div>
                    <p>{t.csvFormatNote}</p>
                    <div className="absolute top-full left-5 -mt-1 border-4 border-transparent border-t-slate-950" />
                  </div>
                </div>
              </div>

              {/* JSON column */}
              <div className="bg-slate-950/70 p-4 rounded-xl border border-slate-800 font-mono">
                <p className="text-xs font-bold text-teal-400 mb-1.5">{t.jsonFormatGuide}</p>
                <code className="text-[11px] text-emerald-300 block leading-tight whitespace-pre max-h-24 overflow-y-auto">
                  {`{
  "amount": 2500000,
  "rate": 8.5,
  "tenureYears": 15,
  "monthlyExtra": 2000,
  "yearlyExtra": 10000,
  "yearlyIncreasePercent": 5
}`}
                </code>
                <div className="relative inline-block group/tooltip mt-2.5">
                  <div className="inline-flex items-center gap-1.5 bg-white/5 border border-white/10 px-2 py-0.5 rounded text-[9px] font-bold cursor-help select-none transition hover:bg-white/10">
                    <span className="text-[9px] font-black uppercase text-teal-400">
                      💡 {lang === "en" ? "Important Note" : lang === "hi" ? "महत्वपूर्ण नोट" : "Note / नोट"}
                    </span>
                    <span className="text-teal-450 font-bold">&#9662;</span>
                  </div>
                  {/* ABSOLUTE FLOATING TOOLTIP */}
                  <div className="absolute bottom-full left-0 mb-2 w-72 p-3 bg-slate-950 text-white rounded-xl shadow-2xl border border-slate-800 text-[10.5px] leading-relaxed font-semibold transition-all duration-200 origin-bottom opacity-0 pointer-events-none scale-95 translate-y-1 group-hover/tooltip:opacity-100 group-hover/tooltip:pointer-events-auto group-hover/tooltip:scale-100 group-hover/tooltip:translate-y-0 z-50">
                    <div className="font-extrabold text-[8.5px] uppercase text-teal-400 mb-1 tracking-wider">
                      {lang === "en" ? "JSON Formatting Rule" : "डबल कोट्स नियम"}
                    </div>
                    <p>{t.jsonFormatNote}</p>
                    <div className="absolute top-full left-5 -mt-1 border-4 border-transparent border-t-slate-950" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {isExtracting && (
          <div className="bg-indigo-50 dark:bg-indigo-950/30 text-indigo-850 dark:text-indigo-300 border-l-4 border-indigo-500 rounded-xl p-4 text-xs font-semibold flex items-center space-x-3 animate-pulse">
            <svg className="animate-spin h-5 w-5 text-indigo-600 dark:text-indigo-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
            <span>✨ {extractionFeedback || t.extractingDocument}</span>
          </div>
        )}

        {extractionFeedback && !isExtracting && (
          <div className="bg-emerald-50 dark:bg-emerald-950/20 text-emerald-800 dark:text-emerald-300 border-l-4 border-emerald-500 rounded-xl p-4 text-xs font-semibold flex justify-between items-center animate-fadeIn">
            <span>🎉 {extractionFeedback}</span>
            <button id="clear-feedback-btn" onClick={() => setExtractionFeedback(null)} className="text-slate-400 hover:text-slate-650 font-bold px-2">{t.clearBtn}</button>
          </div>
        )}

        {uploadError && (
          <div className="bg-rose-50 dark:bg-rose-950/20 text-rose-800 dark:text-rose-450 border-l-4 border-rose-500 rounded-xl p-4 text-xs font-medium flex justify-between items-center animate-fadeIn">
            <span>❌ {t.uploadErrorPrefix}: {uploadError}</span>
            <button id="clear-error-btn" onClick={() => setUploadError(null)} className="text-slate-400 hover:text-slate-650 font-bold px-2">{t.clearBtn}</button>
          </div>
        )}

        {activeMainTab === "dashboard" ? (
          <div className="space-y-8">
            {ownerSettings.layoutOrder.map((sectionKey) => {
              if (ownerSettings.hiddenSections?.[sectionKey]) return null;

              let sectionContent = null;

              if (sectionKey === "summary") {
                sectionContent = <LoanSummaryCards report={activeReport} lang={lang} />;
              } else if (sectionKey === "hacks") {
                sectionContent = (
                  <div className="space-y-8 animate-fadeIn">
                    <EducationalHacks 
                      regularEMI={activeReport.standardMonthlyEMI} 
                      onApplyStrategy={handleApplyStrategy} 
                      activeStrategyName={activeStrategyName} 
                      lang={lang}
                    />
                    <TopUpBuster
                      input={loanInput}
                      prepayments={prepayments}
                      onChangeInput={setLoanInput}
                      onChangePrepayments={setPrepayments}
                      lang={lang}
                    />
                  </div>
                );
              } else if (sectionKey === "inputsAndCharts") {
                sectionContent = (
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start animate-fadeIn">
                    {/* Inputs Section */}
                    <div className="lg:col-span-5 space-y-6 font-sans">
                      <LoanCalculatorForm
                        input={loanInput}
                        prepayments={prepayments}
                        onChangeInput={setLoanInput}
                        onChangePrepayments={setPrepayments}
                        savedProfiles={savedProfiles}
                        onSaveProfile={handleSaveProfile}
                        onSelectProfile={handleSelectProfile}
                        onDeleteProfile={handleDeleteProfile}
                        onFileUpload={handleFileUpload}
                        lang={lang}
                      />
                    </div>

                    {/* Graphical/Trend Charts Section */}
                    <div className="lg:col-span-7 space-y-6">
                      <ScheduleComparisonChart report={activeReport} lang={lang} />
                    </div>
                  </div>
                );
              } else if (sectionKey === "schedule") {
                sectionContent = <AmortizationScheduleTable report={activeReport} lang={lang} />;
              }

              if (!sectionContent) return null;

              const boxClass = getBoxThemeClasses(sectionKey) || "animate-fadeIn";
              return (
                <div key={sectionKey} className={`${boxClass} animate-fadeIn`}>
                  {sectionContent}
                </div>
              );
            })}
          </div>
        ) : activeMainTab === "tools" ? (
          <div className="space-y-8">
            {ownerSettings.layoutOrder.map((sectionKey) => {
              if (ownerSettings.hiddenSections?.[sectionKey]) return null;

              if (sectionKey === "pieAndLetter") {
                const boxClass = getBoxThemeClasses("pieAndLetter") || "animate-fadeIn";
                return (
                  <div key="pieAndLetter" className={`${boxClass} space-y-8 animate-fadeIn`} style={{ contentVisibility: "auto" }}>
                    {/* 🥧 ROW 2.5: INTERACTIVE PIE CHART BREAKDOWN */}
                    <LoanPieChart
                      report={activeReport}
                      applicantName={currentUser?.username || "Guest"}
                      bankName={currentUser?.bank || "Bank"}
                      lang={lang}
                    />

                    {/* 📬 INTERACTIVE BANK REQUEST LETTER GENERATOR WITH MULTI-MODAL OPTIONS */}
                    <BankLetterGenerator
                      report={activeReport}
                      applicantName={currentUser?.username || "Guest"}
                      bankName={currentUser?.bank || "Bank"}
                      lang={lang}
                    />
                  </div>
                );
              }
              return null;
            })}
          </div>
        ) : (
          <div className="space-y-8 animate-fadeIn">
            <AIDebtCoach
              lang={lang}
              username={currentUser?.username || "Guest"}
              bankName={currentUser?.bank || "Lender"}
              baseLoanReport={activeReport}
            />
          </div>
        )}

      </main>

      {/* FOOTER BRUTALIST SIGNATURE */}
      <footer className="mt-16 border-t border-slate-100 dark:border-slate-900 py-8 text-center text-xs text-slate-400 dark:text-slate-500 font-medium">
        <div className="max-w-7xl mx-auto px-4">
          <p>© 2026 लोनबचत - Loan Saver & Payoff Platform. All mathematical calculations follow global banking standards.</p>
          <p className="mt-1">Designed with professional diligence to ease financial stress & make loan repayments faster and smarter.</p>
        </div>
      </footer>
    </div>
  );
}
