import React, { useState, useEffect, useRef } from "react";
import { 
  Sparkles, TrendingUp, Coins, ShieldCheck, AlertCircle, ArrowRight, Send, 
  Activity, Database, Award, HelpCircle, FileText, CheckCircle2, RefreshCw, 
  FileCheck, Network, TrendingDown, ArrowDownNarrowWide, CalendarRange
} from "lucide-react";

interface Debt {
  id: string;
  name: string;
  institution: string;
  balance: number;
  rate: number;
  emi: number;
  dueDate: string;
}

interface ChatMessage {
  sender: "user" | "ai" | "system";
  text: string;
  time: string;
}

interface AIDebtCoachProps {
  lang: "en" | "hi" | "bilingual";
  username: string;
  bankName: string;
  baseLoanReport?: any; // To extract live context if needed
}

export default function AIDebtCoach({ lang, username, bankName, baseLoanReport }: AIDebtCoachProps) {
  // Ingestion Mode State
  const [ingestionStatus, setIngestionStatus] = useState<"idle" | "requesting" | "linked" | "failed">("idle");
  const [ingestionSource, setIngestionSource] = useState<"aa" | "sms" | "pdf" | "none">("none");
  const [feedbackMsg, setFeedbackMsg] = useState<string | null>(null);

  // Loaded multi-liabilities debts (populated via simulator or manually)
  const [debts, setDebts] = useState<Debt[]>([
    { id: "d1", name: "SBI Home Loan", institution: "SBI Bank", balance: 3500000, rate: 8.5, emi: 30400, dueDate: "25th" },
    { id: "d2", name: "HDFC Personal Loan", institution: "HDFC Bank", balance: 400000, rate: 12.75, emi: 11500, dueDate: "10th" },
    { id: "d3", name: "SBI Credit Card Revolving", institution: "SBI Cards", balance: 80000, rate: 45.0, emi: 4000, dueDate: "20th" },
  ]);

  // Form for custom manual debt entries
  const [newDebt, setNewDebt] = useState({ name: "", institution: "", balance: "", rate: "", emi: "", dueDate: "5th" });

  // Strategic Surplus allocation parameters
  const [surplusAmnt, setSurplusAmnt] = useState<number>(15000);
  const [payoffStrategy, setPayoffStrategy] = useState<"avalanche" | "snowball" | "hybrid">("avalanche");

  // Comparison investment inputs
  const [sipCAGR, setSipCAGR] = useState<number>(12); // standard equity returns 12% in India
  const [investmentYears, setInvestmentYears] = useState<number>(10);
  const [isLtcgExempt, setIsLtcgExempt] = useState<boolean>(true); // tax considerations

  // Stress-tester parameters for default/missed EMI risks
  const [monthlyIncome, setMonthlyIncome] = useState<number>(85000);
  const [employmentType, setEmploymentType] = useState<string>("salaried"); // salaried vs self_employed
  const [savingsBuffer, setSavingsBuffer] = useState<number>(45000); // liquid cash emergency fund

  // Interactive AI Coach Chat State
  const [chatInput, setChatInput] = useState<string>("");
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>(() => [
    {
      sender: "system",
      text: lang === "en" 
        ? `Welcome to the secure AI Debt Coach vault. I have successfully ingested your personal profile securely from the private cache.`
        : `सुरक्षित एआई कर्ज कोच तिजोरी में आपका स्वागत है। मैंने आपकी आवश्यकताओं की जांच पूरी कर ली है।`,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    },
    {
      sender: "ai",
      text: lang === "en"
        ? `Hello! I am your AI Debt Elimination Specialist. I specialize in Indian credit cards, tax optimization strategies (like Section 80C & Section 24), and dynamic interest simulations. Ask me anything about your loans or how to tackle high interest credit cards like SBI card dues!`
        : `नमस्ते! मैं आपका एआई ऋण मुक्ति विशेषज्ञ हूँ। मैं भारतीय वित्तीय नियमों, टैक्स छूट (जैसे Section 80C, Section 24) और लोन को न्यूनतम ब्याज में चुकाने की योजनाओं में विशेषज्ञता रखता हूँ। मुझसे अपना कोई भी सवाल पूछें!`,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [isChatLoading, setIsChatLoading] = useState<boolean>(false);
  const chatBottomRef = useRef<HTMLDivElement>(null);

  // Auto Scroll Chat
  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatHistory]);

  // AA Link Simulation trigger
  const triggerIngestionSimulation = (source: "aa" | "sms" | "pdf") => {
    setIngestionStatus("requesting");
    setIngestionSource(source);
    setFeedbackMsg(lang === "en" ? "Polling encrypted servers securely..." : "एन्क्रिप्टेड सर्वर से कनेक्ट किया जा रहा है...");

    setTimeout(() => {
      if (source === "aa") {
        // RBI AA framework mock links
        setDebts([
          { id: "aa-home", name: "CAMS AA SBI Home Loan", institution: "SBI Bank", balance: 4500000, rate: 8.6, emi: 39500, dueDate: "25th" },
          { id: "aa-car", name: "Finvu ICICI Car Loan", institution: "ICICI Bank", balance: 750000, rate: 9.35, emi: 14800, dueDate: "5th" },
          { id: "aa-card", name: "OneMoney SBI Credit Card", institution: "SBI Cards", balance: 120000, rate: 45.0, emi: 6000, dueDate: "18th" },
          { id: "aa-personal", name: "Federal Bank Personal Loan", institution: "Federal Bank", balance: 300000, rate: 13.5, emi: 8800, dueDate: "10th" }
        ]);
        setFeedbackMsg(lang === "en" ? "AA consent authorization verified securely via OneMoney / Finvu interface! Ingested 4 accounts." : "वनमनी / फिनवु इंटरफ़ेस के माध्यम से एए सहमति सत्यापित! 4 खाते सफलतापूर्वक लिंक किए गए।");
      } else if (source === "sms") {
        setDebts([
          { id: "sms-cc", name: "SMS: HDFC Core Visa Dues", institution: "HDFC Bank", balance: 95000, rate: 42.0, emi: 4750, dueDate: "15th" },
          { id: "sms-auto", name: "SMS: ICICI Car Loan Alert", institution: "ICICI Bank", balance: 540000, rate: 9.1, emi: 11200, dueDate: "5th" }
        ]);
        setFeedbackMsg(lang === "en" ? "Discovered 2 transaction alerts parsed from transaction-history inbox!" : "स्मार्ट इनबॉक्स पार्सिंग सफल: 2 ऋण/क्रेडिट अलर्ट निकाले गए!");
      } else {
        setDebts([
          { id: "pdf-home", name: "PDF Extracted Axis Home", institution: "Axis Bank", balance: 3800000, rate: 8.9, emi: 32000, dueDate: "28th" },
          { id: "pdf-pl", name: "PDF Extracted HDFC Personal", institution: "HDFC Bank", balance: 250000, rate: 14.5, emi: 7200, dueDate: "12th" }
        ]);
        setFeedbackMsg(lang === "en" ? "E-Statement PDF parsed securely with structured fields!" : "पीडीएफ ई-स्टेटमेंट सफलतापूर्वक पार्स कर लिया गया है!");
      }
      setIngestionStatus("linked");
    }, 2000);
  };

  const handleAddCustomDebt = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDebt.name || !newDebt.balance || !newDebt.rate) return;
    
    const d: Debt = {
      id: "manual-" + Math.random().toString(36).substr(2, 9),
      name: newDebt.name,
      institution: newDebt.institution || "Other Lender",
      balance: parseFloat(newDebt.balance),
      rate: parseFloat(newDebt.rate),
      emi: parseFloat(newDebt.emi || "0"),
      dueDate: newDebt.dueDate || "5th"
    };

    setDebts([...debts, d]);
    setNewDebt({ name: "", institution: "", balance: "", rate: "", emi: "", dueDate: "5th" });
    setFeedbackMsg(lang === "en" ? `Created liability '${d.name}' successfully.` : `नया दायित्व '${d.name}' सफलतापूर्वक जोड़ा गया।`);
  };

  const handleDeleteDebt = (id: string) => {
    setDebts(debts.filter(d => d.id !== id));
  };

  // Strategic Payoff sequence calculations
  const totalOutstanding = debts.reduce((sum, d) => sum + d.balance, 0);
  const totalBaseEmi = debts.reduce((sum, d) => sum + d.emi, 0);

  // Repayment sequencing algorithm logic
  // Avalanche prioritizes highest interest rate first
  // Snowball prioritizes smallest balance first
  // Hybrid balances prioritizes credit cards first, then highest rate
  const getSortedDebts = () => {
    const list = [...debts];
    if (payoffStrategy === "avalanche") {
      return list.sort((a, b) => b.rate - a.rate);
    } else if (payoffStrategy === "snowball") {
      return list.sort((a, b) => a.balance - b.balance);
    } else {
      // credit cards first, then highest rate
      return list.sort((a, b) => {
        const isACard = a.name.toLowerCase().includes("card") || a.rate > 25;
        const isBCard = b.name.toLowerCase().includes("card") || b.rate > 25;
        if (isACard && !isBCard) return -1;
        if (!isACard && isBCard) return 1;
        return b.rate - a.rate;
      });
    }
  };

  const sortedDebts = getSortedDebts();

  // Simple simulator equations for visual feedback
  // Standard: total months = balance / emi (approx under compounding)
  // Saved: with monthly surplus applied to the prioritized active debt
  const calculateTotalProjectedInterest = (includeSurplus: boolean) => {
    let totalInterest = 0;
    let extraCash = includeSurplus ? surplusAmnt : 0;
    
    // Simple amortization heuristic
    debts.forEach((d) => {
      const annualR = d.rate / 100;
      // if rate is high (e.g. 45% CC), compounding interest is brutal
      const weight = d.rate > 25 ? 1.4 : 1.15;
      totalInterest += d.balance * (annualR * 0.45 * weight);
    });

    if (includeSurplus) {
      // Reduce interest compounding burden depending on dynamic extra cash
      const relativeReduction = (extraCash * 12 * 7) / Math.max(1, totalOutstanding);
      totalInterest = totalInterest * Math.max(0.48, (1 - relativeReduction));
    }

    return Math.round(totalInterest);
  };

  const baseProjectedInterest = calculateTotalProjectedInterest(false);
  const optimizedProjectedInterest = calculateTotalProjectedInterest(true);
  const savedInterestAmount = Math.max(0, baseProjectedInterest - optimizedProjectedInterest);
  const acceleratedYearsSaved = totalOutstanding > 0 
    ? Math.round((surplusAmnt / 4000) * 3.5 * (1000000 / totalOutstanding) * 10) / 10
    : 0;

  // Investment model calculations
  // Formula: Compound Interest of SIP alternatives
  // S = P * [ (1 + i)^n - 1 ] / i * (1 + i)
  const calculateSipAccumulation = () => {
    const monthlyRate = (sipCAGR / 100) / 12;
    const totalMonths = investmentYears * 12;
    const monthlyContribution = surplusAmnt;

    if (monthlyRate === 0) return monthlyContribution * totalMonths;

    let totalSipFutureVal = monthlyContribution * ((Math.pow(1 + monthlyRate, totalMonths) - 1) / monthlyRate) * (1 + monthlyRate);
    
    // Factor capital gains tax in India (15% for LTCG above threshold)
    const gains = totalSipFutureVal - (monthlyContribution * totalMonths);
    if (gains > 0) {
      const ltcgTaxRate = isLtcgExempt ? 0.125 : 0.20; // Union budget rules
      totalSipFutureVal = totalSipFutureVal - (gains * ltcgTaxRate);
    }

    return Math.round(totalSipFutureVal);
  };

  const sipProjectedVal = calculateSipAccumulation();

  // EMI Risk Scoring logic
  const emiToIncomeRatio = monthlyIncome > 0 ? (totalBaseEmi / monthlyIncome) * 100 : 0;
  const bufferPercentage = monthlyIncome > 0 ? (savingsBuffer / monthlyIncome) * 100 : 0;

  const getRiskDetails = () => {
    let score = 0; // out of 100
    
    // high ratio is major risk
    if (emiToIncomeRatio > 55) score += 40;
    else if (emiToIncomeRatio > 40) score += 25;
    else score += 10;

    // self-employed has variable volatility
    if (employmentType === "self_employed") score += 15;

    // insufficient buffer increases risk
    if (savingsBuffer < totalBaseEmi * 3) score += 30; // less than 3 months of EMI
    else if (savingsBuffer < totalBaseEmi * 6) score += 15;

    let label = "LOW DEFAULT RISK (SAFE)";
    let color = "bg-emerald-500 text-emerald-950";
    let bgStyle = "border-emerald-500/30 bg-emerald-500/5";

    if (score > 60) {
      label = "CRITICAL LIMIT (EMI RISK HIGH)";
      color = "bg-rose-500 text-white";
      bgStyle = "border-rose-500/30 bg-rose-500/5 animate-pulse";
    } else if (score > 35) {
      label = "ELEVATED risk (STRESS POSSIBLE)";
      color = "bg-amber-500 text-amber-950";
      bgStyle = "border-amber-500/35 bg-amber-500/5";
    }

    return { score, label, color, bgStyle };
  };

  const riskDetails = getRiskDetails();

  // Handle Gemini Interaction Chat Submission
  const handleSendChat = async () => {
    if (!chatInput.trim()) return;

    const userMsg: ChatMessage = {
      sender: "user",
      text: chatInput,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setChatHistory(prev => [...prev, userMsg]);
    setChatInput("");
    setIsChatLoading(true);

    try {
      // Bundle rich context for the server side assistant
      const activeContext = {
        username,
        bankName,
        amount: totalOutstanding,
        rate: debts[0]?.rate || 8.5,
        tenureYears: 15,
        monthlyExtra: surplusAmnt,
        yearlyExtra: 0,
        yearlyIncreasePercent: 0,
        activeStrategy: payoffStrategy,
        debts: debts.map(d => ({ name: d.name, balance: d.balance, rate: d.rate, emi: d.emi }))
      };

      const response = await fetch("/api/gemini-coach", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          query: userMsg.text,
          context: activeContext,
        }),
      });

      if (!response.ok) {
        throw new Error("Coaching API connection errored.");
      }

      const resData = await response.json();
      setChatHistory(prev => [...prev, {
        sender: "ai",
        text: resData.reply,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }]);

    } catch (error: any) {
      setChatHistory(prev => [...prev, {
        sender: "system",
        text: `Error connecting to AI Coach: ${error.message || "Please make sure your GEMINI_API_KEY is configured."}`,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }]);
    } finally {
      setIsChatLoading(false);
    }
  };

  return (
    <div id="ai-coach-dashboard-wrapper" className="space-y-8">
      
      {/* SECTION 1: AA AGGREGATION & INGESTION SIMULATOR HERO */}
      <section id="coach-ingestion-block" className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800/80 rounded-3xl p-6 shadow-sm relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/5 rounded-full blur-3xl pointer-events-none" />
        
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6 pb-6 border-b border-slate-100 dark:border-slate-800/80">
          <div className="space-y-1.5 col-span-2">
            <span className="inline-flex items-center gap-1 bg-amber-500/10 text-amber-700 dark:text-amber-400 text-[10px] font-black uppercase px-3 py-1 rounded-full select-none">
              <Database className="w-3.5 h-3.5" />
              {lang === "en" ? "RBI ACCOUNT AGGREGATOR CONSENT GATEWAY" : "आरबीआई खाता एग्रीगेटर इंटरफेस"}
            </span>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight flex items-center gap-2">
              <Network className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
              {lang === "en" ? "Secure Liability Ingestion Engine" : "सुरक्षित लायबिलिटी डेटा इनपुट"}
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 font-medium">
              {lang === "en" 
                ? "Bypass manual spreadsheet entry! Pull home loans, credit cards, and investments directly via verified consent conduits."
                : "मैनुअल प्रविष्टियों को छोड़ें! खाता एग्रीगेटर, बैंक विवरण या अलर्ट एसएमएस के माध्यम से संपूर्ण सूची लोड करें।"}
            </p>
          </div>

          <div className="flex flex-wrap gap-2 shrink-0">
            <button
              onClick={() => triggerIngestionSimulation("aa")}
              disabled={ingestionStatus === "requesting"}
              className="px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white dark:bg-white dark:text-slate-900 text-xs font-black rounded-xl transition cursor-pointer flex items-center gap-1.5 disabled:opacity-40"
            >
              <Network className="w-4 h-4 text-emerald-400" />
              <span>LINK VIA NBFC-AA</span>
            </button>
            <button
              onClick={() => triggerIngestionSimulation("sms")}
              disabled={ingestionStatus === "requesting"}
              className="px-4 py-2.5 bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 border border-indigo-100 dark:border-indigo-900/50 text-xs font-black rounded-xl transition cursor-pointer flex items-center gap-1.5 disabled:opacity-40"
            >
              <FileText className="w-4 h-4 text-purple-400" />
              <span>READ EMI SMS HISTORIES</span>
            </button>
            <button
              onClick={() => triggerIngestionSimulation("pdf")}
              disabled={ingestionStatus === "requesting"}
              className="px-4 py-2.5 bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-350 border border-slate-200 dark:border-slate-700 text-xs font-black rounded-xl transition cursor-pointer flex items-center gap-1.5 disabled:opacity-40"
            >
              <FileCheck className="w-4 h-4 text-amber-500" />
              <span>PARSE BANK E-STATEMENT</span>
            </button>
          </div>
        </div>

        {/* Feedback Alert Bar */}
        {feedbackMsg && (
          <div className="mt-4 p-3.5 bg-indigo-500/5 border border-indigo-400/20 text-indigo-800 dark:text-indigo-300 rounded-xl text-xs font-bold flex items-center justify-between space-x-2">
            <div className="flex items-center space-x-2">
              {ingestionStatus === "requesting" ? (
                <RefreshCw className="w-4 h-4 text-indigo-500 animate-spin" />
              ) : (
                <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
              )}
              <span>{feedbackMsg}</span>
            </div>
            {ingestionStatus === "linked" && (
              <button 
                onClick={() => setFeedbackMsg(null)}
                className="text-[10px] uppercase font-black tracking-normal text-slate-400 hover:text-slate-200 cursor-pointer"
              >
                DISMISS
              </button>
            )}
          </div>
        )}

        {/* SECTION 1.5: ACTIVE DEBT STATEMENT LISTING & INTAKE */}
        <div className="mt-6 grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Active Debt list (7 spans) */}
          <div className="lg:col-span-8 space-y-4">
            <h3 className="text-xs font-black text-slate-400 dark:text-slate-500 uppercase tracking-wider flex items-center gap-1">
              <span>{lang === "en" ? "ACTIVE LIABILITIES UNDER ANALYSIS" : "कैलकुलेटर में शामिल सक्रिय लोन और कार्ड"}</span>
              <span className="bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-300 font-extrabold px-2 py-0.5 rounded text-[10px]">
                {debts.length} {lang === "en" ? "Accounts" : "खाते"}
              </span>
            </h3>

            <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
              {debts.map((d) => (
                <div 
                  key={d.id} 
                  id={`debt-card-${d.id}`}
                  className="p-4 bg-slate-50 dark:bg-slate-900/60 border border-slate-100 dark:border-slate-800/80 rounded-2xl flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 hover:border-indigo-500/20 transition group"
                >
                  <div className="space-y-1">
                    <span className="text-[9px] text-indigo-600 dark:text-indigo-400 font-black tracking-wider uppercase bg-indigo-500/5 px-2 py-0.5 rounded-md">
                      {d.institution}
                    </span>
                    <h4 className="text-sm font-extrabold text-slate-900 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition">
                      {d.name}
                    </h4>
                    <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs font-semibold text-slate-400">
                      <span>Rate: <strong className="text-slate-700 dark:text-slate-300 font-bold">{d.rate}% p.a.</strong></span>
                      <span>Min Monthly EMI: <strong className="text-slate-700 dark:text-slate-300 font-bold">₹{d.emi.toLocaleString()}</strong></span>
                      {d.dueDate && <span>Due Date: <strong className="text-slate-700 dark:text-slate-300 font-bold">{d.dueDate}</strong></span>}
                    </div>
                  </div>

                  <div className="flex items-center gap-4 self-end sm:self-center">
                    <div className="text-right">
                      <span className="text-[10px] text-slate-400 font-black block uppercase tracking-wide">OUTSTANDING</span>
                      <strong className="text-base font-black text-rose-500">₹{d.balance.toLocaleString()}</strong>
                    </div>
                    <button
                      onClick={() => handleDeleteDebt(d.id)}
                      className="p-2 bg-rose-500/5 hover:bg-rose-500/15 text-rose-500 rounded-xl transition cursor-pointer"
                      title="De-link liability"
                    >
                      &times;
                    </button>
                  </div>
                </div>
              ))}

              {debts.length === 0 && (
                <div className="p-8 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-200">
                  <AlertCircle className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                  <p className="text-sm font-bold text-slate-500">
                    {lang === "en" ? "No loaded liabilities yet! Link via options above or add manually on the right." : "कोई प्रविष्टि अभी शामिल नहीं है! कृपया एग्रीगेटर लिंक करें या दाईं ओर जोड़ें।"}
                  </p>
                </div>
              )}
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-4.5 bg-slate-900 border border-slate-800 rounded-2xl text-white">
              <div>
                <span className="text-[9px] text-slate-400 font-black uppercase tracking-wider block">Total Outstanding Dues</span>
                <strong className="text-base sm:text-lg font-black text-amber-400">₹{totalOutstanding.toLocaleString()}</strong>
              </div>
              <div>
                <span className="text-[9px] text-slate-400 font-black uppercase tracking-wider block">Minimum Combined EMI</span>
                <strong className="text-base sm:text-lg font-bold text-white">₹{totalBaseEmi.toLocaleString()}</strong>
              </div>
              <div>
                <span className="text-[9px] text-slate-400 font-black uppercase tracking-wider block">Base Interest Projection</span>
                <strong className="text-base sm:text-lg font-bold text-rose-400">₹{baseProjectedInterest.toLocaleString()}</strong>
              </div>
              <div>
                <span className="text-[9px] text-emerald-400 font-black uppercase tracking-wider block">Interest Saved (Optimized)</span>
                <strong className="text-base sm:text-lg font-black text-emerald-400 select-all">₹{savedInterestAmount.toLocaleString()}</strong>
              </div>
            </div>
          </div>

          {/* Quick Manual Add Form (5 spans) */}
          <form onSubmit={handleAddCustomDebt} className="lg:col-span-4 bg-slate-50 dark:bg-slate-900/40 border border-slate-100 dark:border-slate-800 p-5 rounded-2xl space-y-4">
            <h4 className="text-xs font-black text-slate-900 dark:text-white uppercase tracking-wider pb-2 border-b border-slate-100 dark:border-slate-800 flex items-center gap-1.5">
              <Coins className="w-4 h-4 text-amber-500" />
              {lang === "en" ? "MANUAL DEBT ENROLLER" : "मैन्युअल दायित्व एंट्री"}
            </h4>

            <div>
              <label className="block text-[10px] text-slate-450 dark:text-slate-450 font-bold uppercase tracking-wide mb-1">
                Liability Name (e.g., Personal Loan)
              </label>
              <input 
                type="text" 
                required
                className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-900 dark:text-white font-bold"
                placeholder="Axis Personal Loan"
                value={newDebt.name}
                onChange={(e) => setNewDebt({...newDebt, name: e.target.value})}
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[10px] text-slate-450 font-bold uppercase tracking-wide mb-1">Institution</label>
                <input 
                  type="text"
                  placeholder="Axis Bank"
                  className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-2 text-xs font-bold"
                  value={newDebt.institution}
                  onChange={(e) => setNewDebt({...newDebt, institution: e.target.value})}
                />
              </div>
              <div>
                <label className="block text-[10px] text-slate-450 font-bold uppercase tracking-wide mb-1">Due Date</label>
                <input 
                  type="text"
                  placeholder="5th"
                  className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-2 text-xs font-bold"
                  value={newDebt.dueDate}
                  onChange={(e) => setNewDebt({...newDebt, dueDate: e.target.value})}
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2">
              <div>
                <label className="block text-[10px] text-slate-450 font-bold uppercase tracking-wide mb-1">Balance (₹)</label>
                <input 
                  type="number"
                  required
                  placeholder="40000"
                  className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-2.5 py-2 text-xs font-bold text-slate-900 dark:text-white"
                  value={newDebt.balance}
                  onChange={(e) => setNewDebt({...newDebt, balance: e.target.value})}
                />
              </div>
              <div>
                <label className="block text-[10px] text-slate-450 font-bold uppercase tracking-wide mb-1">Rate (% p.a.)</label>
                <input 
                  type="number"
                  step="0.01"
                  required
                  placeholder="12"
                  className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-2.5 py-2 text-xs font-bold text-slate-900 dark:text-white"
                  value={newDebt.rate}
                  onChange={(e) => setNewDebt({...newDebt, rate: e.target.value})}
                />
              </div>
              <div>
                <label className="block text-[10px] text-slate-450 font-bold uppercase tracking-wide mb-1">Monthly EMI</label>
                <input 
                  type="number"
                  placeholder="1500"
                  className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-2.5 py-2 text-xs font-bold"
                  value={newDebt.emi}
                  onChange={(e) => setNewDebt({...newDebt, emi: e.target.value})}
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black rounded-xl cursor-pointer transition uppercase"
            >
              Add to Liability Profile
            </button>
          </form>

        </div>
      </section>

      {/* SECTION 2: SURPLUS PAYOFF SEQUENCER STRATEGY ACCELERATOR (AVALANCHE etc.) */}
      <section id="payoff-sequencer" className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Interactive strategy config card (5 spans) */}
        <div className="lg:col-span-5 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800/80 p-6 rounded-3xl shadow-sm space-y-6">
          <div className="space-y-1">
            <span className="text-[10px] font-black uppercase text-indigo-600 dark:text-indigo-400 bg-indigo-500/10 px-2.5 py-0.5 rounded">
              🎯 ALGORITHMIC TARGETING
            </span>
            <h3 className="text-lg font-black text-slate-900 dark:text-white tracking-tight">
              {lang === "en" ? "Surplus Payment Strategy Engine" : "अतिरिक्त भुगतान रणनीति इंजन"}
            </h3>
            <p className="text-xs text-slate-400">
              {lang === "en" 
                ? "Simulate exactly which debts to allocate extra cash pool monthly to collapse compounds."
                : "तय करें कि हर महीने बचा हुआ अतिरिक्त धन किस ऋण को पहले समाप्त करने में उपयोग करना है।"}
            </p>
          </div>

          {/* Surplus Slider input */}
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <label className="text-xs font-black text-slate-500 uppercase tracking-wide">
                Monthly Repayment Pool Surplus
              </label>
              <span className="text-sm font-black text-indigo-600 dark:text-indigo-400 tracking-tight">
                ₹{surplusAmnt.toLocaleString()} / month
              </span>
            </div>
            <input 
              type="range"
              min="2000"
              max="100000"
              step="1000"
              className="w-full h-2 bg-slate-100 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-600"
              value={surplusAmnt}
              onChange={(e) => setSurplusAmnt(parseInt(e.target.value))}
            />
            <div className="flex justify-between text-[9px] text-slate-400 font-bold uppercase">
              <span>₹2k Surplus</span>
              <span>₹50k</span>
              <span>₹100k Max Pool</span>
            </div>
          </div>

          {/* Strategy buttons selection */}
          <div className="space-y-2">
            <label className="block text-xs font-black text-slate-500 uppercase tracking-wide">
              Priority Ranking Metaphor
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setPayoffStrategy("avalanche")}
                className={`flex flex-col items-center p-3 rounded-2xl border text-center transition cursor-pointer ${
                  payoffStrategy === "avalanche"
                    ? "bg-indigo-600 border-indigo-600 text-white shadow-md shadow-indigo-100 dark:shadow-none"
                    : "bg-slate-50 border-slate-150 dark:bg-slate-900 dark:border-slate-800 text-slate-600 dark:text-slate-400"
                }`}
              >
                <ArrowDownNarrowWide className="w-4 h-4 mb-1 text-amber-300" />
                <span className="text-[10px] font-black uppercase block">Avalanche</span>
                <span className="text-[8px] opacity-75 font-semibold leading-tight mt-0.5">Highest Interest First</span>
              </button>

              <button
                type="button"
                onClick={() => setPayoffStrategy("snowball")}
                className={`flex flex-col items-center p-3 rounded-2xl border text-center transition cursor-pointer ${
                  payoffStrategy === "snowball"
                    ? "bg-slate-900 border-slate-900 text-white shadow-md dark:bg-white dark:text-slate-950"
                    : "bg-slate-50 border-slate-150 dark:bg-slate-900 dark:border-slate-800 text-slate-600 dark:text-slate-400"
                }`}
              >
                <TrendingDown className="w-4 h-4 mb-1 text-emerald-400" />
                <span className="text-[10px] font-black uppercase block">Snowball</span>
                <span className="text-[8px] opacity-75 font-semibold leading-tight mt-0.5">Lowest Balance First</span>
              </button>

              <button
                type="button"
                onClick={() => setPayoffStrategy("hybrid")}
                className={`flex flex-col items-center p-3 rounded-2xl border text-center transition cursor-pointer ${
                  payoffStrategy === "hybrid"
                    ? "bg-amber-600 border-amber-600 text-white shadow-md shadow-amber-100 dark:shadow-none"
                    : "bg-slate-50 border-slate-150 dark:bg-slate-900 dark:border-slate-800 text-slate-600 dark:text-slate-400"
                }`}
              >
                <Sparkles className="w-4 h-4 mb-1 text-indigo-300" />
                <span className="text-[10px] font-black uppercase block">Card First</span>
                <span className="text-[8px] opacity-75 font-semibold leading-tight mt-0.5 text-center">CC Dues + High Rate</span>
              </button>
            </div>
          </div>

          <div className="p-3.5 bg-indigo-50 dark:bg-indigo-950/20 rounded-2xl border border-indigo-100 dark:border-indigo-900/50 text-[11px] text-indigo-750 dark:text-indigo-300 font-semibold leading-relaxed">
            <span className="font-extrabold block mb-1">
              {payoffStrategy === "avalanche" 
                ? "💡 AVALANCHE ADVICE:" 
                : payoffStrategy === "snowball" 
                ? "💡 SNOWBALL ADVICE:"
                : "💡 CC HYBRID ADVICE:"}
            </span>
            {payoffStrategy === "avalanche" 
              ? "Prioritizes high APR (like 42%-45% on SBI/HDFC Credit cards). This yields the mathematically absolute lowest overall interest payout over time."
              : "Focuses on wiping out small balances first to clear loan counts. This provides psychological boost and simplifies monthly bills."}
          </div>
        </div>

        {/* Simulated strategy payback prioritized queue (7 spans) */}
        <div className="lg:col-span-7 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800/80 p-6 rounded-3xl shadow-sm space-y-4">
          <div className="flex justify-between items-center pb-2 border-b border-slate-100 dark:border-slate-800">
            <h4 className="text-xs font-black text-slate-400 uppercase tracking-widest">
              {lang === "en" ? "OPTIMIZED REPAYMENT SEQUENCE & LANDSCAPE" : "ऑप्टिमाइज्ड क्रमवार भुगतान और प्रभाव सूची"}
            </h4>
            <span className="text-[10px] bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 font-black px-2 py-0.5 rounded uppercase">
              {payoffStrategy} Mode Active
            </span>
          </div>

          {/* Stepper Timeline list representation of prioritized debts */}
          <div className="space-y-4 relative pl-4 border-l border-slate-100 dark:border-slate-800/80">
            {sortedDebts.map((d, index) => {
              const isTargetZero = index === 0;
              return (
                <div key={d.id} className="relative space-y-1.5">
                  {/* Dot */}
                  <div className={`absolute -left-[21.5px] top-1 w-3.5 h-3.5 rounded-full border-2 bg-white dark:bg-slate-950 ${isTargetZero ? "border-amber-500 scale-125 ring-2 ring-amber-300 animate-pulse" : "border-slate-400"}`} />
                  
                  <div className="flex flex-wrap justify-between items-center gap-2">
                    <div>
                      <h5 className="text-xs font-black text-slate-900 dark:text-white flex items-center gap-1.5 leading-none">
                        <span>{index + 1}. {d.name}</span>
                        {isTargetZero && (
                          <span className="bg-amber-400 text-slate-950 text-[8px] font-black px-1.5 py-0.5 rounded">
                            PRIMARY TARGET MATCH
                          </span>
                        )}
                      </h5>
                      <span className="text-[10px] text-slate-450 font-bold">{d.institution} &bull; Rate: {d.rate}% p.a.</span>
                    </div>

                    <div className="text-right">
                      {isTargetZero ? (
                        <div>
                          <span className="text-[9px] text-emerald-500 font-black block uppercase tracking-wide">
                            POOLING +₹{surplusAmnt.toLocaleString()}/mo
                          </span>
                          <span className="text-xs font-black text-slate-900 dark:text-white">
                            Total EMI: ₹{(d.emi + surplusAmnt).toLocaleString()}
                          </span>
                        </div>
                      ) : (
                        <div className="text-xs font-semibold text-slate-400 dark:text-slate-500">
                          Standard Min EMI: ₹{d.emi.toLocaleString()}
                        </div>
                      )}
                    </div>
                  </div>
                  
                  {isTargetZero && (
                    <div className="p-3 bg-slate-50 dark:bg-slate-900/60 rounded-xl space-y-1">
                      <div className="flex justify-between items-center text-[10px] text-slate-700 dark:text-slate-350">
                        <span>Projected Paydown Rate:</span>
                        <span className="font-extrabold text-amber-400">FASTER BY ≈{(d.rate * 0.44 * (surplusAmnt / 10000)).toFixed(1)}x Months</span>
                      </div>
                      <div className="w-full bg-slate-200 dark:bg-slate-800 h-1.5 rounded-full overflow-hidden">
                        <div className="bg-gradient-to-r from-amber-500 to-indigo-500 h-full rounded-full animate-pulse" style={{ width: "35%" }} />
                      </div>
                    </div>
                  )}
                </div>
              );
            })}

            {sortedDebts.length === 0 && (
              <p className="text-xs text-slate-400 text-center py-6">
                Please link your Account Aggregator above to populate accounts!
              </p>
            )}
          </div>
          
          <div className="pt-4 grid grid-cols-2 gap-4 border-t border-slate-100 dark:border-slate-800/80">
            <div className="p-4 bg-slate-50 dark:bg-slate-900/40 rounded-2xl text-center">
              <span className="text-[10px] font-black uppercase text-slate-400 tracking-wide block">PROVABLE SAVINGS</span>
              <span className="text-base sm:text-lg font-black text-emerald-500">₹{savedInterestAmount.toLocaleString()}</span>
              <p className="text-[10px] text-slate-400 mt-1">Compound interest preserved</p>
            </div>
            
            <div className="p-4 bg-slate-50 dark:bg-slate-900/40 rounded-2xl text-center">
              <span className="text-[10px] font-black uppercase text-slate-400 tracking-wide block">DEBT-FREE DEADLINE</span>
              <span className="text-base sm:text-lg font-black text-indigo-600 dark:text-indigo-400">SAVED {acceleratedYearsSaved} YEARS</span>
              <p className="text-[10px] text-slate-400 mt-1">Accelerated freedom timeline</p>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 3: DEBT PREPAYMENT VS MUTUAL FUNDS INVESTING COMPASS */}
      <section id="prepay-vs-invest" className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-6 rounded-3xl shadow-sm relative overflow-hidden">
        <div className="absolute inset-x-0 bottom-0 h-1 bg-gradient-to-r from-red-500 via-amber-500 to-emerald-500" />
        
        <div className="space-y-1 mb-6">
          <span className="text-[10px] font-black uppercase tracking-wider text-rose-500 bg-rose-500/10 px-2.5 py-0.5 rounded">
            📊 OPPORTUNITY COST COMPASS
          </span>
          <h3 className="text-lg sm:text-xl font-black text-slate-900 dark:text-white tracking-tight flex items-center gap-1.5">
            <Coins className="w-5 h-5 text-amber-500" />
            {lang === "en" ? "India Prepayment vs. Equity Mutual Fund SIP" : "लोन प्रीपेमेंट बनाम स्टॉक/म्युचुअल फंड में एसआईपी निवेश"}
          </h3>
          <p className="text-xs sm:text-sm text-slate-450 font-medium">
            {lang === "en" 
              ? "Should you pay extra loan principal or invest surplus in Indian equities? Compare the guaranteed debt return with market risk CAGR."
              : "क्या आपको अतिरिक्त राशि लोन को चुकाने में लगानी चाहिए या म्युचुअल फंड में निवेश करनी चाहिए? गारंटीड बचत बनाम लॉन्ग टर्म CAGR की तुलना करें।"}
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Controls inputs (4 spans) */}
          <div className="lg:col-span-4 space-y-4 bg-slate-50 dark:bg-slate-900/40 border border-slate-100 dark:border-slate-800 p-5 rounded-2xl">
            
            <div className="space-y-1.5">
              <label className="text-xs font-black text-slate-450 uppercase block">Expected Mutual Funds CAGR (%)</label>
              <div className="flex items-center space-x-2">
                <input 
                  type="number"
                  className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-1.5 text-xs font-extrabold"
                  value={sipCAGR}
                  onChange={(e) => setSipCAGR(parseFloat(e.target.value) || 0)}
                />
                <span className="text-xs font-bold text-slate-400">p.a.</span>
              </div>
              <span className="text-[9px] text-slate-450 block italic">Historical Indian Equities: 12% - 15%</span>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-black text-slate-450 uppercase block">Simulation Years Horizon</label>
              <input 
                type="range"
                min="3"
                max="25"
                step="1"
                className="w-full h-1.5 bg-slate-200 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-500"
                value={investmentYears}
                onChange={(e) => setInvestmentYears(parseInt(e.target.value))}
              />
              <div className="flex justify-between text-[9px] text-slate-400 font-bold uppercase">
                <span>3 Years</span>
                <span className="text-indigo-400 font-extrabold">{investmentYears} Years Matrix</span>
                <span>25 Years</span>
              </div>
            </div>

            <div className="flex justify-between items-center pt-2 border-t border-slate-100 dark:border-slate-800">
              <div>
                <span className="text-xs font-black text-slate-500 uppercase tracking-tight block">Budget 2024 LTCG Tax Impact</span>
                <span className="text-[9px] text-slate-400 font-bold leading-normal block">Factor 12.5% vs 20% Tax rate on stock gains</span>
              </div>
              <input 
                type="checkbox"
                checked={isLtcgExempt}
                onChange={(e) => setIsLtcgExempt(e.target.checked)}
                className="w-4 h-4 rounded border-slate-350 text-indigo-600 focus:ring-slate-900 cursor-pointer"
              />
            </div>
          </div>

          {/* Results comparisons (8 spans) */}
          <div className="lg:col-span-8 grid grid-cols-1 md:grid-cols-2 gap-6 items-stretch">
            
            {/* Box A: Prepayment option */}
            <div className="border border-indigo-100 dark:border-indigo-900/50 bg-indigo-50/15 p-5 rounded-2xl flex flex-col justify-between">
              <div>
                <div className="flex justify-between items-start">
                  <span className="text-[9px] text-indigo-700 bg-indigo-100 font-black px-2.5 py-0.5 rounded uppercase">Option A: Prepayment</span>
                  <ShieldCheck className="w-4 h-4 text-emerald-500" />
                </div>
                <h4 className="text-base font-extrabold text-indigo-950 dark:text-indigo-300 mt-2">
                  Guaranteed Debt Elimination
                </h4>
                <p className="text-xs text-slate-400 mt-1">
                  Applying safety focus to wipe out active loans in order of interest weight.
                </p>
              </div>

              <div className="mt-6 pt-4 border-t border-indigo-100 dark:border-indigo-900/50">
                <span className="text-[9px] text-slate-400 font-black block uppercase tracking-wide">GUARANTEED INTEREST VALUE SAVED</span>
                <strong className="text-xl font-black text-emerald-500">₹{savedInterestAmount.toLocaleString()}</strong>
                <span className="text-[10px] text-indigo-600 dark:text-indigo-400 font-bold block mt-1">
                  Equivalent to clear tax-free returns of ~8.5% - 12% depending on tax slab!
                </span>
              </div>
            </div>

            {/* Box B: Investment option */}
            <div className="border border-amber-100 dark:border-amber-900/50 bg-amber-50/15 p-5 rounded-2xl flex flex-col justify-between">
              <div>
                <div className="flex justify-between items-start">
                  <span className="text-[9px] text-amber-700 bg-amber-100 font-black px-2.5 py-0.5 rounded uppercase">Option B: SIP Mutual Funds</span>
                  <TrendingUp className="w-4 h-4 text-amber-500 animate-pulse" />
                </div>
                <h4 className="text-base font-extrabold text-amber-950 dark:text-amber-300 mt-2">
                  Wealth Accrual (Equities)
                </h4>
                <p className="text-xs text-slate-400 mt-1">
                  Investing ₹{surplusAmnt.toLocaleString()} monthly inside index/equity funds.
                </p>
              </div>

              <div className="mt-6 pt-4 border-t border-amber-100 dark:border-amber-900/50">
                <div className="flex justify-between items-baseline">
                  <div>
                    <span className="text-[9px] text-slate-400 font-black block uppercase tracking-wide">POST-TAX FUTURE POTENTIAL VALUE</span>
                    <strong className="text-xl font-black text-amber-500">₹{sipProjectedVal.toLocaleString()}</strong>
                  </div>
                </div>
                <span className="text-[10px] text-slate-450 block mt-1">
                  *Subject to market volatility. Includes LTCG tax assessment logic.
                </span>
              </div>
            </div>

            {/* Coach verdict recommendation summary bar */}
            <div className="md:col-span-2 p-4 bg-slate-900 rounded-2xl text-slate-300 text-xs font-semibold flex items-start gap-3">
              <Award className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-extrabold text-[10px] text-amber-400 uppercase tracking-widest block mb-0.5">COACH PERSONALIZED TRADE-OFF VERDICT</span>
                {totalOutstanding === 0 ? (
                  "You have no live outstanding debts! Allocating 100% of your surplus cash into SIP or active equity mutual funds is strongly recommended."
                ) : (debts[0]?.rate > 20) ? (
                  `Urgent: You are holding high compounding debts (Credit Card rates are ${debts[0]?.rate}%). Equity mutual funds cannot guarantee 45% yields! Prioritize 100% of your ₹${surplusAmnt.toLocaleString()} monthly pool to wipe out credit card dues instantly.`
                ) : (
                  `Balanced Strategy: If your home loan rate is 8.5% and expected SIP CAGR is ${sipCAGR}%, you have a potential surplus spread of ${(sipCAGR - 8.5).toFixed(1)}%. We recommend a hybrid route: Apply 60% of surplus to prepay loans and acquire peace of mind, and 40% into Section 80C tax-saving ELSS or active large-cap mutual funds!`
                )}
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* SECTION 4: PREDICTIVE EMI DEFAULT RISK STRESS TESTER */}
      <section id="predictive-default-check" className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-6 rounded-3xl shadow-sm space-y-6">
        <div className="space-y-1">
          <span className="text-[10px] font-black uppercase tracking-wider text-rose-500 bg-rose-500/10 px-2.5 py-0.5 rounded">
            ⚠️ PREDICTIVE ANALYTICS STRESS VAULT
          </span>
          <h3 className="text-lg font-black text-slate-900 dark:text-white tracking-tight flex items-center gap-1.5">
            <Activity className="w-5 h-5 text-red-500" />
            {lang === "en" ? "Interactive Cashflow & EMI Volatility Stress Tester" : "कैशफ्लो और ईएमआई डिफॉल्ट जोखिम संकेतक"}
          </h3>
          <p className="text-xs text-slate-450">
            {lang === "en" 
              ? "Are you over-leveraged? Calculate your cashflow resiliency rating depending on income-to-EMI multipliers and job stability."
              : "क्या आपके ऊपर कर्ज़ का बोझ अधिक है? आय-टू-ईएमआई अनुपात और अनपेक्षित खर्चों के प्रति अपनी ऋण अदायगी सुरक्षा रेटिंग मापें।"}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-stretch">
          
          {/* Input controls (2 spans equivalent to left segment) */}
          <div className="md:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-4 bg-slate-50 dark:bg-slate-900/40 border border-slate-100 dark:border-slate-800 p-5 rounded-2xl">
            
            <div className="space-y-1.5">
              <label className="text-xs font-black text-slate-450 uppercase block">Monthly Take-Home Income (₹)</label>
              <input 
                type="number" 
                className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-2 text-xs font-extrabold"
                value={monthlyIncome}
                onChange={(e) => setMonthlyIncome(parseFloat(e.target.value) || 0)}
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-black text-slate-450 uppercase block">Liquid Cash emergency funds (₹)</label>
              <input 
                type="number" 
                className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-2 text-xs font-extrabold"
                value={savingsBuffer}
                onChange={(e) => setSavingsBuffer(parseFloat(e.target.value) || 0)}
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-black text-slate-450 uppercase block">Job / Business Stability Type</label>
              <select
                className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-2 text-xs font-bold"
                value={employmentType}
                onChange={(e) => setEmploymentType(e.target.value)}
              >
                <option value="salaried">Govt or MNC Salaried (High Stability)</option>
                <option value="private_contract">Private Venture Employee (Medium Stability)</option>
                <option value="self_employed">Business / Self-Employed Professional (Variable Income)</option>
              </select>
            </div>

            <div className="flex items-center justify-between p-3.5 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-xl">
              <div className="space-y-0.5">
                <span className="text-[10px] text-slate-400 font-extrabold uppercase block">CONSTRAINED EMI RATIO</span>
                <strong className="text-sm font-black text-slate-850 dark:text-white">{emiToIncomeRatio.toFixed(1)}% Ratio</strong>
              </div>
              <span className={`text-[10px] font-black px-2.5 py-1 rounded-md uppercase ${emiToIncomeRatio > 40 ? "bg-rose-100 text-rose-700" : "bg-emerald-100 text-emerald-700"}`}>
                {emiToIncomeRatio > 50 ? "Aggressive (High Debt)" : emiToIncomeRatio > 35 ? "Warning (Moderate)" : "Safe (<35%)"}
              </span>
            </div>

          </div>

          {/* Meter representation (1 span) */}
          <div className={`p-6 border rounded-2xl flex flex-col justify-between items-center transition-all ${riskDetails.bgStyle}`}>
            <span className="text-[10px] font-extrabold tracking-widest text-slate-400 uppercase">VOLATILITY RISK RATING</span>
            
            <div className="text-center space-y-1 my-4">
              <span className={`text-[11px] font-black px-3.5 py-1 rounded-full uppercase ${riskDetails.color}`}>
                {riskDetails.label}
              </span>
              <div className="text-3xl font-black text-slate-900 dark:text-white mt-1.5">
                {riskDetails.score} <span className="text-sm text-slate-400">/ 100</span>
              </div>
            </div>

            <p className="text-[10.5px] text-slate-500 font-medium text-center leading-normal">
              {riskDetails.score > 60 
                ? "Immediate action needed! Liquid cash buffer holds less than 3 months EMI requirements. Switch to strict home budgeting."
                : riskDetails.score > 35
                ? "Moderate leverage risk. Expand liquid cash storage buffer equivalents before embarking on extreme lumpsum prepayments."
                : "Excellent cashflow cushion! Your liabilities are safe. You can confidently deploy surplus payments without default worries."}
            </p>
          </div>

        </div>
      </section>

      {/* SECTION 5: PREMIUM GEMINI CHAT VAULT FOR ADVISORY */}
      <section id="ai-chat-vault" className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl p-6 shadow-sm flex flex-col items-stretch min-h-[460px] relative overflow-hidden">
        <div className="absolute top-0 right-0 w-24 h-24 bg-amber-500/5 rounded-full blur-2xl pointer-events-none" />
        
        <div className="pb-4 border-b border-slate-150 dark:border-slate-800/80 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div className="space-y-0.5">
            <span className="bg-amber-400 text-slate-950 font-black text-[9px] px-2 py-0.5 rounded uppercase tracking-wider">
              Secure Consultation Chat
            </span>
            <h3 className="text-base sm:text-lg font-black text-slate-900 dark:text-white tracking-tight flex items-center gap-1.5">
              <Sparkles className="w-5 h-5 text-amber-500" />
              {lang === "en" ? "AI Debt & Refinancing Consultation Specialist" : "एआई कर्ज सलाहकार वार्तालाप डेस्क"}
            </h3>
          </div>

          <span className="text-[10.5px] font-bold text-slate-450 uppercase flex items-center gap-1">
            <ShieldCheck className="w-4 h-4 text-emerald-500" />
            {lang === "en" ? "Direct Connection (Gemini 3.5)" : "सुरक्षित एआई कनेक्शन"}
          </span>
        </div>

        {/* Chat History Messages Scroll Pane */}
        <div className="flex-grow my-4 overflow-y-auto space-y-3.5 max-h-[350px] min-h-[220px] pr-2 scrollbar-thin">
          {chatHistory.map((msg, idx) => {
            const isUser = msg.sender === "user";
            const isSys = msg.sender === "system";

            return (
              <div 
                key={idx} 
                className={`flex flex-col ${isUser ? "items-end" : isSys ? "items-center" : "items-start"}`}
              >
                {!isSys && (
                  <span className="text-[9px] text-slate-400 font-bold mb-0.5 px-1">
                    {isUser ? `${username} (You)` : "AI Debt Eliminator Coach"} &bull; {msg.time}
                  </span>
                )}
                
                <div 
                  className={`max-w-[85%] rounded-2xl p-3.5 text-xs font-semibold leading-relaxed ${
                    isUser
                      ? "bg-slate-900 text-white rounded-tr-none"
                      : isSys
                      ? "bg-slate-100 dark:bg-slate-850 text-slate-700 dark:text-slate-400 border border-slate-200 dark:border-slate-800 text-[11px] font-mono text-center rounded-lg px-6 py-2 w-full max-w-sm"
                      : "bg-indigo-50/70 dark:bg-slate-950 border border-indigo-100/50 dark:border-indigo-900/40 text-slate-800 dark:text-slate-200 rounded-tl-none whitespace-pre-wrap"
                  }`}
                >
                  {msg.text}
                </div>
              </div>
            );
          })}
          
          {isChatLoading && (
            <div className="flex items-center space-x-2.5 p-3.5 bg-slate-50 dark:bg-slate-950 border border-slate-100 dark:border-slate-800/80 rounded-2xl max-w-xs animate-pulse">
              <RefreshCw className="w-4 h-4 text-amber-500 animate-spin" />
              <span className="text-xs text-slate-500 font-bold">Coach is calculating dynamic interest schedules...</span>
            </div>
          )}
          <div ref={chatBottomRef} />
        </div>

        {/* Input Text Box Trigger */}
        <div className="flex items-center gap-3 mt-auto pt-3 border-t border-slate-100 dark:border-slate-800/80">
          <input 
            type="text" 
            placeholder={lang === "en" ? "Ask me: Should i pay home loan or invest in SIP? How to do Avalanche?" : "मुझसे पूछें: पर्सनल लोन पहले चुकाएं या म्युचुअल फंड में लगाएं?"}
            className="flex-grow bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-850 rounded-2xl px-4 py-3 text-xs text-slate-900 dark:text-white font-semibold focus:outline-none focus:border-indigo-500"
            value={chatInput}
            onChange={(e) => setChatInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") handleSendChat();
            }}
          />
          <button
            onClick={handleSendChat}
            disabled={!chatInput.trim() || isChatLoading}
            className="p-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl transition cursor-pointer disabled:opacity-50"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </section>

      {/* SECTION 6: INDIAN FINTECH BENCHMARK COMPARISON & GANTT ROADMAP */}
      <section id="roadmap-comparison-box" className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Competitive matrices grid (5 spans) */}
        <div className="lg:col-span-5 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800/80 p-5 rounded-3xl shadow-sm space-y-4">
          <h4 className="text-xs font-black text-slate-400 uppercase tracking-widest pb-1 border-b border-slate-100 dark:border-slate-800">
            {lang === "en" ? "COMPETITIVE LANDSCAPE & MATRIX" : "भारतीय फिनटेक मार्केट तुलना सूची"}
          </h4>

          <div className="space-y-3.5">
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-black text-slate-900 dark:text-white">
                <span>CRED Money</span>
                <span className="text-[10px] text-slate-400 uppercase">Aggregator but no Paydown logic</span>
              </div>
              <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                <div className="bg-slate-400 h-full" style={{ width: "65%" }} />
              </div>
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-xs font-black text-slate-900 dark:text-white">
                <span>INDmoney / ETMoney</span>
                <span className="text-[10px] text-slate-400 uppercase">SIP focus, little deep debt tools</span>
              </div>
              <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                <div className="bg-slate-400 h-full" style={{ width: "40%" }} />
              </div>
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-xs font-black text-slate-900 dark:text-white">
                <span>AI Debt Coach Dashboard</span>
                <span className="text-[10px] text-indigo-500 font-extrabold uppercase">100% Avalanche, AA, & AI Coaching</span>
              </div>
              <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                <div className="bg-gradient-to-r from-emerald-400 to-indigo-600 h-full" style={{ width: "100%" }} />
              </div>
            </div>
          </div>

          <p className="text-[10.5px] text-slate-400 leading-normal font-medium pt-2">
            *Conclusion: Indian credit ecosystems specialize in lead generation or standard score checking (like credit bureau lookups on CRED), but lack algorithmic multi-debt avalanche calculators and opportunity cost indicators. This app fully addresses that gap.
          </p>
        </div>

        {/* Mermaid timeline roadmap replica layout (7 spans) */}
        <div className="lg:col-span-7 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800/80 p-5 rounded-3xl shadow-sm space-y-4">
          <h4 className="text-xs font-black text-slate-400 uppercase tracking-widest pb-1 border-b border-slate-100 dark:border-slate-800">
            {lang === "en" ? "COMPLIANCE & PRODUCT DEPLOYMENT ROADMAP (2026-2027)" : "विकास रोडमैप और आरबीआई फ्रेमवर्क गाइड"}
          </h4>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="p-3 bg-slate-50 dark:bg-slate-950 border border-slate-150 dark:border-slate-800 rounded-2xl flex flex-col justify-between">
              <div>
                <span className="text-[8px] bg-slate-200 dark:bg-slate-800 text-slate-650 px-2.5 py-0.5 rounded font-black tracking-wider uppercase block w-max">PHASE 1 - 2026</span>
                <h5 className="text-xs font-black text-slate-900 dark:text-white mt-2">Architecture & AA SDK Integration</h5>
                <p className="text-[10px] text-slate-400 leading-relaxed mt-1">Develop API schemas and consent flows for Sahamati-certified Account Aggregator networks (Finvu/OneMoney).</p>
              </div>
            </div>

            <div className="p-3 bg-slate-50 dark:bg-slate-950 border border-slate-150 dark:border-slate-800 rounded-2xl flex flex-col justify-between">
              <div>
                <span className="text-[8px] bg-indigo-500/10 text-indigo-500 px-2.5 py-0.5 rounded font-black tracking-wider uppercase block w-max">PHASE 2 - Q1 2027</span>
                <h5 className="text-xs font-black text-slate-900 dark:text-white mt-2">ML Optimization Engine</h5>
                <p className="text-[10px] text-slate-400 leading-relaxed mt-1">Implement linear programming cashflow algorithms and predictive default models using customer spend metrics.</p>
              </div>
            </div>

            <div className="p-3 bg-slate-50 dark:bg-slate-950 border border-slate-150 dark:border-slate-800 rounded-2xl flex flex-col justify-between">
              <div>
                <span className="text-[8px] bg-amber-500/10 text-amber-500 px-2.5 py-0.5 rounded font-black tracking-wider uppercase block w-max">PHASE 3 - Q3 2027</span>
                <h5 className="text-xs font-black text-slate-900 dark:text-white mt-2">Compliance Review & Launch</h5>
                <p className="text-[10px] text-slate-400 leading-relaxed mt-1">Undergo regulatory guidelines audit, confirm data localization laws inside Indian datacenters, and public playstore launch.</p>
              </div>
            </div>
          </div>
        </div>

      </section>

    </div>
  );
}
