import React, { useState, Fragment } from "react";
import { LoanReport, AmortizationRow } from "../types";
import { convertScheduleToCSV } from "../utils/loanCalculator";
import { generateReportPDF } from "../utils/pdfGenerator";
import { Download, Search, Table, Calendar, Eye, EyeOff, ChevronDown, FileSpreadsheet, FileText, FileCode, ArrowUpDown, ArrowUp, ArrowDown, RotateCcw } from "lucide-react";
import { translations } from "../utils/translations";

interface AmortizationScheduleTableProps {
  report: LoanReport;
  lang: "en" | "hi" | "bilingual";
}

export default function AmortizationScheduleTable({ report, lang }: AmortizationScheduleTableProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [viewMode, setViewMode] = useState<"monthly" | "yearly">("yearly");
  const [searchQuery, setSearchQuery] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const rowsPerPage = 12; // 1 year of months per page

  const t = translations[lang];
  const { schedule } = report;

  // 1. Calculate Yearly Collapsed Summary rows
  const yearlySummary: {
    yearNumber: number;
    yearLabel: string;
    openingBalance: number;
    scheduledEMI: number;
    totalInterest: number;
    totalPrincipal: number;
    totalExtra: number;
    totalPaid: number;
    closingBalance: number;
    monthsList: AmortizationRow[];
  }[] = [];

  // Group by yearNumber
  const groupedByYear: { [key: number]: AmortizationRow[] } = {};
  schedule.forEach((row) => {
    if (!groupedByYear[row.yearNumber]) {
      groupedByYear[row.yearNumber] = [];
    }
    groupedByYear[row.yearNumber].push(row);
  });

  Object.keys(groupedByYear).forEach((yrStr) => {
    const yr = Number(yrStr);
    const months = groupedByYear[yr];
    const firstMonth = months[0];
    const lastMonth = months[months.length - 1];

    const openingBalance = firstMonth.openingBalance;
    const closingBalance = lastMonth.closingBalance;
    const scheduledEMI = months.reduce((sum, m) => sum + m.scheduledEMI, 0);
    const totalInterest = months.reduce((sum, m) => sum + m.regularInterest, 0);
    const totalExtra = months.reduce((sum, m) => sum + m.extraPayment, 0);
    const totalPrincipal = months.reduce((sum, m) => sum + m.regularPrincipal, 0);
    const totalPaid = months.reduce((sum, m) => sum + m.totalPaidThisMonth, 0);

    // Get date label range
    const yearLabel = months.length > 0 
      ? lang === "en" 
        ? `Year ${yr} (${firstMonth.dateLabel.split(" ").pop()})`
        : `${firstMonth.dateLabel.split(" ").pop()} (${lang === "hi" ? "वर्ष" : "Year"} ${yr})` 
      : `Year ${yr}`;

    yearlySummary.push({
      yearNumber: yr,
      yearLabel,
      openingBalance,
      scheduledEMI,
      totalInterest,
      totalPrincipal: totalPrincipal + totalExtra, // correct display
      totalExtra,
      totalPaid,
      closingBalance,
      monthsList: months,
    });
  });

  // Expandable state for yearly rows
  const [expandedYears, setExpandedYears] = useState<{ [key: number]: boolean }>({});

  const toggleYearExpand = (yr: number) => {
    setExpandedYears((prev) => ({
      ...prev,
      [yr]: !prev[yr],
    }));
  };

  // Sorting state
  const [sortField, setSortField] = useState<"chronological" | "interest" | "principal">("chronological");
  const [sortAscending, setSortAscending] = useState(true);
  const [secondarySortField, setSecondarySortField] = useState<"chronological" | "interest" | "principal" | null>(null);
  const [secondarySortAscending, setSecondarySortAscending] = useState(true);

  const handleSort = (field: "chronological" | "interest" | "principal", isShiftKey: boolean = false) => {
    if (isShiftKey) {
      if (sortField === field) {
        // Toggle primary sort direction
        setSortAscending(!sortAscending);
      } else {
        // Toggle or set secondary sort
        if (secondarySortField === field) {
          setSecondarySortAscending(!secondarySortAscending);
        } else {
          setSecondarySortField(field);
          setSecondarySortAscending(field === "chronological");
        }
      }
    } else {
      // Normal click resets secondary sort
      setSecondarySortField(null);
      if (sortField === field) {
        setSortAscending(!sortAscending);
      } else {
        setSortField(field);
        setSortAscending(field === "chronological");
      }
    }
    setCurrentPage(1);
  };

  const handleKeyDown = (e: React.KeyboardEvent, field: "chronological" | "interest" | "principal") => {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      handleSort(field, e.shiftKey);
    }
  };

  const handleResetSort = () => {
    setSortField("chronological");
    setSortAscending(true);
    setSecondarySortField(null);
    setSecondarySortAscending(true);
    setCurrentPage(1);
  };

  const isSorted = sortField !== "chronological" || !sortAscending || secondarySortField !== null;

  const getActiveSortLabel = () => {
    let primaryLabel = "";
    if (sortField === "chronological") {
      primaryLabel = lang === "en" 
        ? `Timeline (${sortAscending ? "Earliest first" : "Latest first"})`
        : `समय (${sortAscending ? "पहले से पुराना" : "नवीनतम पहले"})`;
    } else if (sortField === "interest") {
      primaryLabel = lang === "en"
        ? `Interest Component (${sortAscending ? "Lowest first" : "Interest-heavy first"})`
        : `ब्याज आकार (${sortAscending ? "कम पहले" : "अधिकतम ब्याज पहले"})`;
    } else if (sortField === "principal") {
      primaryLabel = lang === "en"
        ? `Principal Components (${sortAscending ? "Lowest first" : "Principal-heavy first"})`
        : `मूलधन आकार (${sortAscending ? "कम पहले" : "अधिकतम मूलधन पहले"})`;
    }

    if (secondarySortField) {
      let secondaryLabel = "";
      if (secondarySortField === "chronological") {
        secondaryLabel = lang === "en"
          ? `Timeline (${secondarySortAscending ? "Earliest" : "Latest"})`
          : `समय (${secondarySortAscending ? "पहले" : "नवीनतम"})`;
      } else if (secondarySortField === "interest") {
        secondaryLabel = lang === "en"
          ? `Interest (${secondarySortAscending ? "Lowest" : "Interest-heavy"})`
          : `ब्याज (${secondarySortAscending ? "कम" : "अधिकतम"})`;
      } else if (secondarySortField === "principal") {
        secondaryLabel = lang === "en"
          ? `Principal (${secondarySortAscending ? "Lowest" : "Principal-heavy"})`
          : `मूलधन (${secondarySortAscending ? "कम" : "अधिकतम"})`;
      }
      return lang === "en"
        ? `${primaryLabel}, then by ${secondaryLabel}`
        : `${primaryLabel}, फिर ${secondaryLabel}`;
    }
    return primaryLabel;
  };

  const renderSortIndicator = (field: "chronological" | "interest" | "principal") => {
    const isPrimary = sortField === field;
    const isSecondary = secondarySortField === field;

    if (isPrimary) {
      return (
        <span 
          key={`${field}-primary-${sortAscending}`}
          className={`inline-flex items-center gap-1 font-bold sort-icon-pulse ${field === "interest" ? "text-rose-600 dark:text-rose-400" : "text-indigo-600 dark:text-indigo-400"}`}
        >
          <ArrowUp 
            className={`w-3.5 h-3.5 shrink-0 transition-transform duration-305 ${
              sortAscending ? "rotate-0" : "rotate-180"
            }`} 
          />
          <span className="text-[8px] font-black select-none leading-none bg-slate-200/70 dark:bg-slate-800/85 px-1 py-0.5 rounded" title="Primary sort priority">1</span>
        </span>
      );
    }

    if (isSecondary) {
      return (
        <span 
          key={`${field}-secondary-${secondarySortAscending}`}
          className="inline-flex items-center gap-1 font-semibold text-indigo-500 dark:text-indigo-400 sort-icon-pulse"
        >
          <ArrowUp 
            className={`w-3.5 h-3.5 shrink-0 transition-transform duration-305 ${
              secondarySortAscending ? "rotate-0" : "rotate-180"
            }`} 
          />
          <span className="text-[8px] font-black select-none leading-none bg-indigo-55/60 dark:bg-indigo-950/40 px-1 py-0.5 rounded text-indigo-700 dark:text-indigo-300" title="Secondary sort priority">2</span>
        </span>
      );
    }

    return (
      <ArrowUpDown key={`${field}-inactive`} className="w-3 h-3 text-slate-400 opacity-30 group-hover/th:opacity-100 transition-opacity shrink-0" />
    );
  };

  // 2. Filter rules based on searchQuery
  const filteredMonthly = schedule.filter((row) => {
    const term = searchQuery.toLowerCase();
    return (
      row.monthNumber.toString().includes(term) ||
      row.dateLabel.toLowerCase().includes(term) ||
      `year ${row.yearNumber}`.includes(term)
    );
  });

  const filteredYearly = yearlySummary.filter((row) => {
    const term = searchQuery.toLowerCase();
    return (
      row.yearNumber.toString().includes(term) ||
      row.yearLabel.toLowerCase().includes(term)
    );
  });

  // Apply sorting
  const sortedYearly = [...filteredYearly].sort((a, b) => {
    // 1. Primary Sort
    let comp = 0;
    if (sortField === "chronological") {
      comp = sortAscending ? a.yearNumber - b.yearNumber : b.yearNumber - a.yearNumber;
    } else if (sortField === "interest") {
      comp = sortAscending ? a.totalInterest - b.totalInterest : b.totalInterest - a.totalInterest;
    } else if (sortField === "principal") {
      comp = sortAscending ? a.totalPrincipal - b.totalPrincipal : b.totalPrincipal - a.totalPrincipal;
    }

    // 2. Secondary Sort if primary comparison is equal
    if (comp === 0 && secondarySortField) {
      if (secondarySortField === "chronological") {
        comp = secondarySortAscending ? a.yearNumber - b.yearNumber : b.yearNumber - a.yearNumber;
      } else if (secondarySortField === "interest") {
        comp = secondarySortAscending ? a.totalInterest - b.totalInterest : b.totalInterest - a.totalInterest;
      } else if (secondarySortField === "principal") {
        comp = secondarySortAscending ? a.totalPrincipal - b.totalPrincipal : b.totalPrincipal - a.totalPrincipal;
      }
    }
    return comp;
  });

  const sortedMonthly = [...filteredMonthly].sort((a, b) => {
    // 1. Primary Sort
    let comp = 0;
    if (sortField === "chronological") {
      comp = sortAscending ? a.monthNumber - b.monthNumber : b.monthNumber - a.monthNumber;
    } else if (sortField === "interest") {
      comp = sortAscending ? a.regularInterest - b.regularInterest : b.regularInterest - a.regularInterest;
    } else if (sortField === "principal") {
      const aTotalP = a.regularPrincipal + a.extraPayment;
      const bTotalP = b.regularPrincipal + b.extraPayment;
      comp = sortAscending ? aTotalP - bTotalP : bTotalP - aTotalP;
    }

    // 2. Secondary Sort if primary comparison is equal
    if (comp === 0 && secondarySortField) {
      if (secondarySortField === "chronological") {
        comp = secondarySortAscending ? a.monthNumber - b.monthNumber : b.monthNumber - a.monthNumber;
      } else if (secondarySortField === "interest") {
        comp = secondarySortAscending ? a.regularInterest - b.regularInterest : b.regularInterest - a.regularInterest;
      } else if (secondarySortField === "principal") {
        const aTotalP = a.regularPrincipal + a.extraPayment;
        const bTotalP = b.regularPrincipal + b.extraPayment;
        comp = secondarySortAscending ? aTotalP - bTotalP : bTotalP - aTotalP;
      }
    }
    return comp;
  });

  // Pagination for Monthly (since monthly has up to 300+ rows)
  const totalPages = Math.ceil(sortedMonthly.length / rowsPerPage);
  const indexOfLastRow = currentPage * rowsPerPage;
  const indexOfFirstRow = indexOfLastRow - rowsPerPage;
  const currentMonthlyRows = sortedMonthly.slice(indexOfFirstRow, indexOfLastRow);

  const [exportDropdownOpen, setExportDropdownOpen] = useState(false);

  const downloadCSV = () => {
    const csvContent = convertScheduleToCSV(report);
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `LoanSaver_Amortization_Schedule_${inputLabel()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setExportDropdownOpen(false);
  };

  const downloadJSON = () => {
    const jsonStr = JSON.stringify(report, null, 2);
    const blob = new Blob([jsonStr], { type: "application/json;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `LoanSaver_Amortization_Data_${inputLabel()}.json`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setExportDropdownOpen(false);
  };

  const downloadPDF = () => {
    generateReportPDF(report, lang);
    setExportDropdownOpen(false);
  };

  const inputLabel = () => {
    return report.input.amount ? `${Math.round(report.input.amount / 100000)}L` : "Report";
  };

  if (!isExpanded) {
    return (
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 shadow-sm border border-slate-100 dark:border-slate-800 transition-all text-center">
        <div className="max-w-md mx-auto space-y-4 py-6">
          <div className="inline-flex items-center justify-center p-3 bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 rounded-2xl shadow-xs">
            <Table className="w-6 h-6 text-indigo-550" />
          </div>
          <div>
            <h4 className="font-extrabold text-slate-800 dark:text-white text-base">
              {t.tableTitle}
            </h4>
            <p className="text-xs text-slate-400 dark:text-slate-500 mt-1.5 leading-relaxed">
              {lang === "en" 
                ? "The complete payment schedule and amortization ledger is collapsed. Click below to expand and search through your complete payoff details."
                : "आपकी स्क्रीन का स्थान बचाने के लिए विस्तृत विवरण छुपाया गया है। पूरी भुगतान तालिका देखने और खोजने के लिए नीचे बटन पर क्लिक करें।"}
            </p>
          </div>
          <button
            id="expand-amortization-schedule-trigger-btn"
            onClick={() => setIsExpanded(true)}
            className="w-full inline-flex items-center justify-center gap-2 px-6 py-3.5 bg-indigo-600 hover:bg-slate-900 dark:hover:bg-indigo-500 text-white font-black text-xs rounded-xl shadow-xs hover:shadow-md transition duration-200 cursor-pointer active:scale-95"
          >
            <span>{lang === "en" ? "Expand Amortization Schedule" : "लोन भुगतान तालिका का विस्तार करें"}</span>
            <ChevronDown className="w-4 h-4" />
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-100 dark:border-slate-800 transition-all">
      {/* HEADER CONTROL AREA */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
        <div>
          <h3 className="font-bold text-slate-800 dark:text-slate-150 text-base flex items-center gap-2">
            <Table className="w-5 h-5 text-indigo-500" />
            {t.tableTitle}
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            {t.tableSubtitle}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
          {/* View Toggles */}
          <div className="flex bg-slate-100 dark:bg-slate-800 p-1 rounded-xl border border-slate-200/40 dark:border-slate-700/50">
            <button
              id="view-toggle-yearly"
              onClick={() => {
                setViewMode("yearly");
                setSearchQuery("");
                setCurrentPage(1);
              }}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition duration-150 cursor-pointer ${
                viewMode === "yearly"
                  ? "bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-300 shadow-sm"
                  : "text-slate-500 hover:text-slate-800"
              }`}
            >
              {t.viewYearlyBtn}
            </button>
            <button
              id="view-toggle-monthly"
              onClick={() => {
                setViewMode("monthly");
                setSearchQuery("");
                setCurrentPage(1);
              }}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition duration-150 cursor-pointer ${
                viewMode === "monthly"
                  ? "bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-300 shadow-sm"
                  : "text-slate-500 hover:text-slate-800"
              }`}
            >
              {t.viewMonthlyBtn}
            </button>
          </div>

          {/* Collapse Button */}
          <button
            id="collapse-amortization-schedule-direct-btn"
            onClick={() => setIsExpanded(false)}
            className="px-3.5 py-2 bg-slate-50 hover:bg-slate-100 dark:bg-slate-800 dark:hover:bg-slate-750 text-slate-650 dark:text-slate-300 rounded-xl text-xs font-black transition duration-250 cursor-pointer flex items-center space-x-1.5 border border-slate-200/40 dark:border-slate-750/50 active:scale-95 shadow-2xs"
          >
            <EyeOff className="w-3.5 h-3.5 text-indigo-505" />
            <span>{lang === "en" ? "Collapse" : "छोटा करें"}</span>
          </button>

          {/* Download split dropdown */}
          <div className="relative">
            <button
              id="download-split-dropdown-btn"
              onClick={() => setExportDropdownOpen(!exportDropdownOpen)}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-750 text-white rounded-xl text-xs font-bold transition duration-200 cursor-pointer flex items-center space-x-1.5 shadow-sm active:scale-95"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{lang === "en" ? "Export Report" : lang === "hi" ? "एक्सपोर्ट रिपोर्ट" : "Export (एक्सपोर्ट देखें)"}</span>
              <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-250 ${exportDropdownOpen ? "rotate-180" : ""}`} />
            </button>

            {exportDropdownOpen && (
              <>
                <div
                  id="export-dropdown-backdrop"
                  className="fixed inset-0 z-40"
                  onClick={() => setExportDropdownOpen(false)}
                />
                <div
                  id="export-formats-menu"
                  className="absolute right-0 mt-2 w-56 bg-white dark:bg-slate-800 rounded-xl shadow-xl border border-slate-100 dark:border-slate-700/80 p-1.5 z-50 animate-fadeIn"
                >
                  <p className="text-[10px] uppercase tracking-wider font-semibold text-slate-400 dark:text-slate-500 px-3 py-1.5">
                    {lang === "en" ? "Select format" : lang === "hi" ? "प्रारूप चुनें" : "Format (प्रारूप)"}
                  </p>
                  
                  <button
                    id="export-to-csv-action-btn"
                    onClick={downloadCSV}
                    className="w-full text-left px-3 py-2 text-xs font-medium text-slate-705 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-750 rounded-lg flex items-center space-x-2.5 transition duration-150 cursor-pointer text-slate-700"
                  >
                    <FileSpreadsheet className="w-4 h-4 text-emerald-500" />
                    <span className="flex-1">{t.exportCsvBtn}</span>
                    <span className="text-[10px] text-slate-400 bg-slate-100 dark:bg-slate-700 px-1.5 py-0.5 rounded font-mono">.csv</span>
                  </button>

                  <button
                    id="export-to-pdf-action-btn"
                    onClick={downloadPDF}
                    className="w-full text-left px-3 py-2 text-xs font-medium text-slate-705 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-750 rounded-lg flex items-center space-x-2.5 transition duration-150 cursor-pointer text-slate-700"
                  >
                    <FileText className="w-4 h-4 text-rose-500" />
                    <span className="flex-1">{t.exportPdfBtn}</span>
                    <span className="text-[10px] text-slate-400 bg-slate-100 dark:bg-slate-700 px-1.5 py-0.5 rounded font-mono">.pdf</span>
                  </button>

                  <button
                    id="export-to-json-action-btn"
                    onClick={downloadJSON}
                    className="w-full text-left px-3 py-2 text-xs font-medium text-slate-705 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-750 rounded-lg flex items-center space-x-2.5 transition duration-150 cursor-pointer text-slate-700"
                  >
                    <FileCode className="w-4 h-4 text-amber-500" />
                    <span className="flex-1">{t.exportJsonBtn}</span>
                    <span className="text-[10px] text-slate-400 bg-slate-100 dark:bg-slate-700 px-1.5 py-0.5 rounded font-mono">.json</span>
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      </div>

      {/* FILTER & STAT INFO */}
      <div className="flex flex-col sm:flex-row gap-3 justify-between items-center mb-4">
        {/* Search */}
        <div className="relative w-full sm:w-64">
          <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
            <Search className="h-3.5 w-3.5 text-slate-400" />
          </span>
          <input
            id="schedule-search-input"
            type="text"
            placeholder={viewMode === "yearly" ? t.searchPlaceholderYearly : t.searchPlaceholderMonthly}
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setCurrentPage(1);
            }}
            className="pl-9 pr-3 py-1.5 w-full text-xs sm:text-sm rounded-xl bg-slate-50 dark:bg-slate-850/80 border border-slate-200 dark:border-slate-800 text-slate-850 dark:text-slate-200 focus:outline-none focus:ring-1 focus:ring-indigo-500"
          />
        </div>

        {/* Info & Sorting Status */}
        <div className="flex flex-wrap items-center gap-2 justify-end w-full sm:w-auto text-[11px] text-slate-400 dark:text-slate-500 font-medium">
          <span className="bg-indigo-50/80 dark:bg-slate-800/80 text-indigo-650 dark:text-indigo-400 px-2.5 py-0.5 rounded-lg font-bold border border-indigo-150/50 dark:border-slate-750/50 text-[10px]">
            {getActiveSortLabel()}
          </span>
          <span className="text-slate-300 dark:text-slate-700 hidden sm:inline">&bull;</span>
          <span>
            {viewMode === "yearly" 
              ? `${t.totalDurationRowText} ${yearlySummary.length} ${lang === "en" ? "Years" : "साल"}`
              : `${t.totalDurationRowText} ${schedule.length} ${lang === "en" ? "Months" : "महीने"}`}
          </span>
        </div>
      </div>

      {/* TABLE CONTAINER */}
      <div className="overflow-x-auto border border-slate-100 dark:border-slate-800/80 rounded-xl">
        <table className="min-w-full divide-y divide-slate-100 dark:divide-slate-800/60 text-xs sm:text-sm">
          <thead className="bg-slate-100/75 dark:bg-slate-850/90 text-slate-700 dark:text-slate-200 font-extrabold uppercase tracking-wider text-[10px]">
            <tr className="amortization-table-header border-b border-slate-100 dark:border-slate-800">
              <th 
                className={`px-3.5 py-3 text-left cursor-pointer hover:bg-slate-200/50 dark:hover:bg-slate-800/70 transition-all select-none group/th ${
                  sortField === "chronological" 
                    ? "bg-indigo-50/60 dark:bg-slate-800/90 text-indigo-700 dark:text-indigo-300 font-extrabold border-b-2 border-indigo-500/80" 
                    : secondarySortField === "chronological"
                    ? "bg-indigo-50/20 dark:bg-slate-800/40 text-indigo-600/90 dark:text-indigo-400/90 font-bold border-b border-indigo-400/40"
                    : ""
                }`}
                onClick={(e) => handleSort("chronological", e.shiftKey)}
                onKeyDown={(e) => handleKeyDown(e, "chronological")}
                tabIndex={0}
              >
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center space-x-1">
                    <span>{t.colYear}</span>
                    {renderSortIndicator("chronological")}
                  </div>
                  {isSorted && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleResetSort();
                      }}
                      className="px-2 py-1 rounded-lg text-[9px] sm:text-[10px] leading-none bg-indigo-50 hover:bg-indigo-100 dark:bg-slate-800 dark:hover:bg-slate-700 text-indigo-600 dark:text-indigo-400 font-extrabold tracking-wide border border-indigo-200/55 dark:border-slate-700 transition-all shadow-sm shrink-0 whitespace-nowrap cursor-pointer hover:scale-105 active:scale-95 flex items-center gap-1"
                      title="Reset sorting to default"
                    >
                      <RotateCcw className="w-2.5 h-2.5 shrink-0" />
                      <span>{lang === "en" ? "Reset Sorting" : "सॉर्टिंग रीसेट"}</span>
                    </button>
                  )}
                </div>
              </th>
              <th className="px-3 py-3 text-right text-slate-650 dark:text-slate-350 font-bold">
                {t.colOpening}
              </th>
              <th className="px-3 py-3 text-right text-slate-650 dark:text-slate-350 font-bold">
                {t.colEMI}
              </th>
              <th className="px-3 py-3 text-right text-slate-650 dark:text-slate-350 font-bold">
                {t.colExtra}
              </th>
              <th 
                className={`px-3 py-3 text-right cursor-pointer hover:bg-rose-50/40 dark:hover:bg-slate-800/70 transition-all select-none group/th ${
                  sortField === "interest" 
                    ? "bg-rose-50/30 dark:bg-slate-850/70 text-rose-700 dark:text-rose-400 font-extrabold border-b-2 border-rose-500/80" 
                    : secondarySortField === "interest"
                    ? "bg-rose-50/10 dark:bg-slate-850/30 text-rose-600/90 dark:text-rose-400/90 font-bold border-b border-rose-400/40"
                    : ""
                }`}
                onClick={(e) => handleSort("interest", e.shiftKey)}
                onKeyDown={(e) => handleKeyDown(e, "interest")}
                tabIndex={0}
              >
                <div className="flex items-center justify-end space-x-1">
                  <span>{t.colInterest}</span>
                  {renderSortIndicator("interest")}
                </div>
              </th>
              <th 
                className={`px-3 py-3 text-right cursor-pointer hover:bg-slate-200/50 dark:hover:bg-slate-800/70 transition-all select-none group/th ${
                  sortField === "principal" 
                    ? "bg-indigo-50/70 dark:bg-slate-850/70 text-indigo-700 dark:text-indigo-400 font-extrabold border-b-2 border-indigo-500/80" 
                    : secondarySortField === "principal"
                    ? "bg-indigo-50/25 dark:bg-slate-850/30 text-indigo-600/90 dark:text-indigo-400/90 font-bold border-b border-indigo-400/40"
                    : ""
                }`}
                onClick={(e) => handleSort("principal", e.shiftKey)}
                onKeyDown={(e) => handleKeyDown(e, "principal")}
                tabIndex={0}
              >
                <div className="flex items-center justify-end space-x-1">
                  <span>{t.colPrincipal}</span>
                  {renderSortIndicator("principal")}
                </div>
              </th>
              <th className="px-3 py-3 text-right text-slate-700 dark:text-slate-300">
                {t.colClosing}
              </th>
            </tr>
          </thead>
          <tbody className="bg-white dark:bg-slate-900 divide-y divide-slate-100 dark:divide-slate-800/40 text-slate-700 dark:text-slate-300">
            {/* YEARLY SUMMARY VIEW */}
            {viewMode === "yearly" && (
              sortedYearly.map((yr) => (
                <Fragment key={yr.yearNumber}>
                  <tr
                    id={`yearly-row-${yr.yearNumber}`}
                    onClick={() => toggleYearExpand(yr.yearNumber)}
                    className="hover:bg-slate-50/50 dark:hover:bg-slate-850/30 transition cursor-pointer"
                  >
                    <td className="px-3.5 py-3 font-semibold text-slate-800 dark:text-slate-200 flex items-center space-x-1.5">
                      <Calendar className="w-3.5 h-3.5 text-indigo-500 shrink-0" />
                      <span>{yr.yearLabel}</span>
                      {expandedYears[yr.yearNumber] ? (
                        <EyeOff className="w-3 h-3 text-slate-400 shrink-0" />
                      ) : (
                        <Eye className="w-3 h-3 text-slate-400 shrink-0" />
                      )}
                    </td>
                    <td className="px-3 py-3 text-right font-medium">₹{Math.round(yr.openingBalance).toLocaleString("en-IN")}</td>
                    <td className="px-3 py-3 text-right text-slate-500">₹{Math.round(yr.scheduledEMI).toLocaleString("en-IN")}</td>
                    <td className="px-3 py-3 text-right font-bold">
                      {yr.totalExtra > 0 ? (
                        <span className="text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 px-2 py-0.5 rounded text-[11px]">
                          +₹{Math.round(yr.totalExtra).toLocaleString("en-IN")}
                        </span>
                      ) : (
                        <span className="text-slate-350 font-normal">-</span>
                      )}
                    </td>
                    <td className="px-3 py-3 text-right text-rose-500/90 font-medium">₹{Math.round(yr.totalInterest).toLocaleString("en-IN")}</td>
                    <td className="px-3 py-3 text-right text-indigo-600 dark:text-indigo-400 font-bold">
                      ₹{Math.round(yr.totalPrincipal).toLocaleString("en-IN")}
                    </td>
                    <td className="px-3 py-3 text-right font-bold text-slate-850 dark:text-slate-100">
                      {yr.closingBalance <= 0.01 ? (
                        <span className="text-emerald-600 bg-emerald-50 dark:bg-emerald-950/40 px-2.5 py-0.5 rounded font-bold text-[11px] uppercase tracking-wider">{t.fullPaidOffLabel}</span>
                      ) : (
                        `₹${Math.round(yr.closingBalance).toLocaleString("en-IN")}`
                      )}
                    </td>
                  </tr>

                  {/* SUB MONTHS (if year row expanded) */}
                  {expandedYears[yr.yearNumber] && (
                    yr.monthsList.map((mth) => {
                      const isPrepaid = mth.extraPayment > 0;
                      return (
                        <tr
                          key={mth.monthNumber}
                          id={`month-expanded-${mth.monthNumber}`}
                          className="bg-indigo-50/10 dark:bg-slate-850/10 text-[11px] sm:text-xs text-slate-600 dark:text-slate-400"
                        >
                          <td className="px-8 py-2 text-slate-500 dark:text-slate-450 italic flex items-center space-x-1 border-l-2 border-indigo-200 dark:border-indigo-800">
                            <span>#{mth.monthNumber} &bull; {mth.dateLabel.split(" ")[0]}</span>
                          </td>
                          <td className="px-3 py-2 text-right text-slate-400">₹{Math.round(mth.openingBalance).toLocaleString("en-IN")}</td>
                          <td className="px-3 py-2 text-right text-slate-400">₹{Math.round(mth.scheduledEMI).toLocaleString("en-IN")}</td>
                          <td className="px-3 py-2 text-right">
                            {isPrepaid ? (
                              <span className="text-emerald-600 font-bold bg-emerald-500/10 px-1.5 py-0.5 rounded">
                                +₹{Math.round(mth.extraPayment).toLocaleString("en-IN")}
                              </span>
                            ) : (
                              <span className="text-slate-350 font-normal">-</span>
                            )}
                          </td>
                          <td className="px-3 py-2 text-right text-rose-400">₹{Math.round(mth.regularInterest).toLocaleString("en-IN")}</td>
                          <td className="px-3 py-2 text-right text-indigo-400 font-medium">
                            ₹{Math.round(mth.regularPrincipal + mth.extraPayment).toLocaleString("en-IN")}
                          </td>
                          <td className="px-3 py-2 text-right font-medium text-slate-500">
                            {mth.closingBalance <= 0.01 ? (
                              <span className="text-emerald-500 font-bold bg-emerald-50/20 px-1.5 py-0.5 rounded">0 (Paid)</span>
                            ) : (
                              `₹${Math.round(mth.closingBalance).toLocaleString("en-IN")}`
                            )}
                          </td>
                        </tr>
                      );
                    })
                  )}
                </Fragment>
              ))
            )}

            {/* MONTHLY DETAILED VIEW ONLY */}
            {viewMode === "monthly" && (
              currentMonthlyRows.map((row) => {
                const isPrepaid = row.extraPayment > 0;
                return (
                  <tr
                    key={row.monthNumber}
                    id={`monthly-row-${row.monthNumber}`}
                    className={`hover:bg-slate-50/50 dark:hover:bg-slate-850/30 transition ${
                      isPrepaid ? "bg-emerald-50/10 dark:bg-emerald-950/5" : ""
                    }`}
                  >
                    <td className="px-3.5 py-2.5 font-medium text-slate-800 dark:text-slate-200">
                      <div className="flex flex-col">
                        <span>{row.dateLabel}</span>
                        <span className="text-[10px] text-slate-400 font-mono">#{row.monthNumber} &bull; {lang === "en" ? "Year" : "वर्ष"} {row.yearNumber}</span>
                      </div>
                    </td>
                    <td className="px-3 py-2.5 text-right font-medium">₹{Math.round(row.openingBalance).toLocaleString("en-IN")}</td>
                    <td className="px-3 py-2.5 text-right text-slate-500">₹{Math.round(row.scheduledEMI).toLocaleString("en-IN")}</td>
                    <td className="px-3 py-2.5 text-right font-bold">
                      {isPrepaid ? (
                        <span className="text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 px-2 py-0.5 rounded text-[11px]">
                          +₹{Math.round(row.extraPayment).toLocaleString("en-IN")}
                        </span>
                      ) : (
                        <span className="text-slate-350 font-normal">-</span>
                      )}
                    </td>
                    <td className="px-3 py-2.5 text-right text-rose-500/90 font-medium">₹{Math.round(row.regularInterest).toLocaleString("en-IN")}</td>
                    <td className="px-3 py-2.5 text-right text-indigo-600 dark:text-indigo-400 font-bold">
                      ₹{Math.round(row.regularPrincipal + row.extraPayment).toLocaleString("en-IN")}
                    </td>
                    <td className="px-3 py-2.5 text-right font-bold text-slate-850 dark:text-slate-100">
                      {row.closingBalance <= 0.01 ? (
                        <span className="text-emerald-600 bg-emerald-50 dark:bg-emerald-950/40 px-2.5 py-0.5 rounded font-bold text-[11px] uppercase tracking-wider">{t.fullPaidOffLabel}</span>
                      ) : (
                        `₹${Math.round(row.closingBalance).toLocaleString("en-IN")}`
                      )}
                    </td>
                  </tr>
                );
              })
            )}

            {/* Zero records */}
            {((viewMode === "monthly" && sortedMonthly.length === 0) ||
              (viewMode === "yearly" && sortedYearly.length === 0)) && (
              <tr>
                <td colSpan={7} className="px-4 py-8 text-center text-slate-400 dark:text-slate-500 italic font-medium">
                  {t.noRecordsFound}
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* FOOTER PAGINATION FOR MONTHLY */}
      {viewMode === "monthly" && totalPages > 1 && (
        <div className="flex flex-col sm:flex-row justify-between items-center mt-4 gap-3">
          <p className="text-xs text-slate-550 dark:text-slate-400 font-medium">
            {t.showingRecordsPrefix} {indexOfFirstRow + 1} - {Math.min(indexOfLastRow, sortedMonthly.length)} of {sortedMonthly.length}
          </p>
          <div className="flex items-center space-x-1.5">
            <button
              id="pag-prev"
              type="button"
              onClick={() => setCurrentPage((c) => Math.max(1, c - 1))}
              disabled={currentPage === 1}
              className="px-3.5 py-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 disabled:opacity-40 text-xs font-bold rounded-lg text-slate-700 dark:text-slate-300 disabled:cursor-not-allowed cursor-pointer transition active:scale-95"
            >
              {t.btnPrev}
            </button>
            <span className="px-3 py-1 font-semibold text-xs dark:text-slate-300">
              {currentPage} / {totalPages}
            </span>
            <button
              id="pag-next"
              type="button"
              onClick={() => setCurrentPage((c) => Math.min(totalPages, c + 1))}
              disabled={currentPage === totalPages}
              className="px-3.5 py-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 disabled:opacity-40 text-xs font-bold rounded-lg text-slate-700 dark:text-slate-300 disabled:cursor-not-allowed cursor-pointer transition active:scale-95"
            >
              {t.btnNext}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
