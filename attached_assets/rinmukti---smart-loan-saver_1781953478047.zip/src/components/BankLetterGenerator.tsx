import { useState, useRef } from "react";
import { LoanReport } from "../types";
import { Copy, Printer, Check, FileText, ChevronRight, RefreshCw, HelpCircle, Landmark, ShieldCheck, Mail } from "lucide-react";

interface BankLetterGeneratorProps {
  report: LoanReport;
  applicantName: string;
  bankName: string;
  lang: "en" | "hi" | "bilingual";
}

export default function BankLetterGenerator({ report, applicantName, bankName, lang }: BankLetterGeneratorProps) {
  const [requestType, setRequestType] = useState<"custom_emi" | "extra_emi" | "prepayment" | "adjust_tenure" | "super_save">("prepayment");
  const [customEmiVal, setCustomEmiVal] = useState<string>("25000");
  const [extraEmiVal, setExtraEmiVal] = useState<string>("5000");
  const [prepaymentVal, setPrepaymentVal] = useState<string>("100000");
  const [targetYears, setTargetYears] = useState<string>("15");
  const [copied, setCopied] = useState(false);
  
  const letterRef = useRef<HTMLDivElement>(null);

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
      maximumFractionDigits: 0
    }).format(val);
  };

  const todayDate = new Date().toLocaleDateString("en-IN", {
    day: "numeric",
    month: "long",
    year: "numeric"
  });

  // Calculate some beneficial data
  const { interestSaved, tenureSavedMonths, standardMonthlyEMI } = report;
  const savedYears = (tenureSavedMonths / 12).toFixed(1);

  // Generate customized letter content (English and Hindi combined based on parameters)
  const getLetterContent = () => {
    const subjectPrefix = {
      en: "SUB: Request for ",
      hi: "विषय: "
    };

    let subject = "";
    let bodyEn = "";
    let bodyHi = "";

    switch (requestType) {
      case "custom_emi":
        subject = `${subjectPrefix.en}Switching to a Custom Monthly EMI of ₹${Number(customEmiVal).toLocaleString("en-IN")} \n${subjectPrefix.hi}मासिक EMI में बदलाव करके ₹${Number(customEmiVal).toLocaleString("en-IN")} करने हेतु आवेदन`;
        bodyEn = `I am writing to formally request a customized adjustment in my monthly Equated Monthly Installment (EMI) for my ongoing loan account. Currently, my standard scheduled EMI is ${formatCurrency(standardMonthlyEMI)}. Under my current financial capacity, I wish to revise and increase my recurring monthly repayment to a customized regular sum of ₹${Number(customEmiVal).toLocaleString("en-IN")} per month. By setting this custom EMI, I wish to accelerate the reduction of the outstanding principal amount and minimize the cumulative interest liability over the remaining tenure of the loan.`;
        bodyHi = `सविनय निवेदन है कि उपरोक्त ऋण खाते के तहत मेरी निर्धारित मासिक किस्त (EMI) वर्तमान में ${formatCurrency(standardMonthlyEMI)} है। मैं अपनी वित्तीय सुदृढ़ता के आधार पर इस मासिक पुनर्भुगतान को बढ़ाकर ₹${Number(customEmiVal).toLocaleString("en-IN")} प्रति माह कराना चाहता हूँ। कृपया मेरे मासिक भुगतान में इस बदलाव को स्वीकृत कर खाते में दर्ज करें ताकि मेरा मूलधन तेजी से कम हो सके और ऋण अवधि पर लगने वाला ब्याज बच सके।`;
        break;
      case "extra_emi":
        subject = `${subjectPrefix.en}Addition of Extra Monthly Prepayment of ₹${Number(extraEmiVal).toLocaleString("en-IN")} along with Scheduled EMI \n${subjectPrefix.hi}सामान्य EMI के साथ हर महीने ₹${Number(extraEmiVal).toLocaleString("en-IN")} का अतिरिक्त नियमित भुगतान जोड़ने हेतु`;
        bodyEn = `I request you to kindly configure and append an additional monthly prepayment component of ₹${Number(extraEmiVal).toLocaleString("en-IN")} alongside my standard regular EMI. This extra amount should be debited monthly and credited explicitly towards the principal outstanding amount of my loan account. I understand that this regular partial prepayment strategy will systematically cut down my outstanding liability and reduce the loan's overall interest load in subsequent quarters.`;
        bodyHi = `मैं अनुरोध करता हूँ कि मेरी नियमित मासिक किस्त (EMI) के साथ ₹${Number(extraEmiVal).toLocaleString("en-IN")} का अतिरिक्त अंशदान जोड़ा जाए। यह अतिरिक्त राशि सीधे मेरे बकाया मूलधन (Principal Balance) को समयपूर्व कम करने हेतु जमा की जाए। इस मासिक अतिरिक्त जमा से मेरा बकाया ऋण शीघ्र चुकता हो सकेगा।`;
        break;
      case "prepayment":
        subject = `${subjectPrefix.en}Permission to make Part-Prepayment of ₹${Number(prepaymentVal).toLocaleString("en-IN")} towards Loan Outstanding \n${subjectPrefix.hi}ऋण खाते में ₹${Number(prepaymentVal).toLocaleString("en-IN")} का आंशिक प्री-पेमेंट जमा करने हेतु`;
        bodyEn = `I request permission to deposit a partial prepayment of ₹${Number(prepaymentVal).toLocaleString("en-IN")} against the outstanding principal balance of my above-mentioned loan account. This lump-sum amount is enclosed herewith (via draft/cheque/online transfer). Kindly credit the entire amount directly towards the principal outstanding. I further request that my regular EMI amount remain constant, while the overall remaining tenure is appropriately shortened in alignment with this payment.`;
        bodyHi = `मैं अपने इस ऋण खाते में ₹${Number(prepaymentVal).toLocaleString("en-IN")} की एकमुश्त आंशिक प्री-पेमेंट (Lump-sum Part Prepayment) जमा करना चाहता हूँ। कृपया इस धन को सीधे मेरे मूलधन खाते में क्रेडिट करें तथा आगामी किस्तों को सुचारू रखते हुए ऋण की अंतिम परिपक्वता अवधि (Tenure) को कम करने की कृपा करें।`;
        break;
      case "adjust_tenure":
        subject = `${subjectPrefix.en}Adjustment of Loan Tenure to ${targetYears} Years with Corresponding EMI Recalculation \n${subjectPrefix.hi}ऋण परिपक्वता अवधि को बदलकर ${targetYears} वर्ष करने और EMI पुनर्गठन हेतु`;
        bodyEn = `I request an official recalculation and adjustment of my outstanding loan tenure to a target of ${targetYears} years. I wish to align my financial repayment plan with this designated tenure and am willing to accept the recalculated installment amount calculated by your department. Please provide the updated repayment schedule showing the fast-tracked path to loan closure and the revised EMI metrics at your earliest convenience.`;
        bodyHi = `मैं अपने ऋण के पुनर्भुगतान की कुल अवधि को संशोधित करके ${targetYears} वर्ष पर सेट करवाना चाहता हूँ। तदनुसार मेरी EMI राशि में आवश्यक फेरबदल करें। कृपया मुझे नई संशोधित ब्याज योजना और त्वरित क्लोजर विवरण प्रदान करने का कष्ट करें।`;
        break;
      case "super_save":
        subject = `${subjectPrefix.en}Opting for Super Saver Smart Overdraft Combo Feature Linkage \n${subjectPrefix.hi}सुपर सेवर स्मार्ट ओवरड्राफ्ट (बचत लिंकेज) सुविधा शुरू करने हेतु`;
        bodyEn = `I wish to opt-in and enroll my loan account under your proprietary "Super Saver Smart Loan" / "SBI Maxgain" / "Overdraft Home Saver Linkage" facility. I want to link my secondary surplus saving/current account to the loan account. I understand that any daily/monthly surplus balances kept in this linked account will be offset against the loan's outstanding principal balance, thereby saving me substantial interest costs while maintaining liquidity. Please advise on the setup process and documentation required for this integration.`;
        bodyHi = `मैं अपने चल रहे ऋण खाते को आपके बैंक की "सुपर सेवर स्मार्ट लोन" (Maxgain / Home Saver Overdraft) योजना से लिंक करवाना चाहता हूँ। मैं अपना बचत खाता ऋण खाते से संबद्ध करने के लिए सहमत हूँ, जिससे मेरे खाते में उपलब्ध अतिरिक्त नकद के अनुपात में ब्याज दायित्व कम हो सके और मुझे पैसे की तरलता भी मिलती रहे। कृपया आवश्यक प्रक्रिया स्पष्ट करें।`;
        break;
    }

    return {
      date: todayDate,
      to: `The Branch Manager,\n${bankName || "Your Loan Disbursing Bank"},\nRetail Asset Branch / Home Loan Cell,\nIndia.`,
      subject,
      salutation: "Respected Sir / Madam,",
      salutationHi: "आदरणीय महोदय / महोदया,",
      bodyEn,
      bodyHi,
      footerEn: `Thanking you for your prompt assistance in optimizing my loan liability.\n\nYours sincerely,`,
      footerHi: `आपके सहयोग और त्वरित सहायता के लिए बहुत-बहुत धन्यवाद।\n\nभवदीय/भवदीया,`,
      sender: applicantName || "Valued Customer"
    };
  };

  const letter = getLetterContent();

  const handleCopyText = () => {
    const fullText = `
Date: ${letter.date}

To,
${letter.to}

${letter.subject}

${letter.salutation}
${letter.bodyEn}

${letter.salutationHi}
${letter.bodyHi}

${letter.footerEn}
${letter.footerHi}

Name: ${letter.sender}
Signature: ______________________
    `;
    navigator.clipboard.writeText(fullText.trim());
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-100 dark:border-slate-800/80 p-6 shadow-sm mt-8 relative" id="bank-letter-container">
      
      {/* Decorative gradient blur */}
      <div className="absolute -top-12 -right-12 w-32 h-32 bg-indigo-500/5 dark:bg-indigo-500/5 rounded-full blur-2xl pointer-events-none" />

      {/* Heading */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-slate-50 dark:border-slate-800/30 pb-5 mb-6">
        <div>
          <div className="flex items-center space-x-2 text-indigo-650 dark:text-indigo-400">
            <Mail className="w-5 h-5 animate-pulse" />
            <span className="text-xs font-bold uppercase tracking-widest">
              {lang === "en" ? "Interactive Action Tools" : lang === "hi" ? "त्वरित वित्तीय उपकरण" : "Repayment Actions"}
            </span>
          </div>
          <h3 className="text-lg font-black text-slate-900 dark:text-white tracking-tight mt-1">
            {lang === "en" 
              ? "Official Bank Request Letter Generator" 
              : lang === "hi" 
              ? "बैंक आवेदन पत्र जेनरेटर (त्वरित बदलाव)" 
              : "Bank Request Letter Generator / बैंक पत्र"}
          </h3>
          <p className="text-xs text-slate-400 dark:text-slate-500 font-medium">
            {lang === "en"
              ? "Generate a formal formatted dispatch letter based on your customized payoff logic for your branch."
              : "अपनी वर्तमान बचत योजना और सुविधा के आधार पर तुरंत बैंक हेड को भेजने योग्य आवेदन पत्र तैयार करें।"}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Side: Select Request Options & Interactive Parameter input */}
        <div className="col-span-12 lg:col-span-5 space-y-6">
          <div className="bg-slate-50 dark:bg-slate-800/30 rounded-2xl p-4 border border-slate-100 dark:border-slate-800/50">
            <h4 className="text-xs font-extrabold text-slate-700 dark:text-slate-350 uppercase tracking-wider mb-3 flex items-center gap-1.5">
              <Landmark className="w-3.5 h-3.5 text-indigo-500" />
              <span>{lang === "en" ? "1. Select Request Goal" : "1. अपनी मांग का उद्देश्य चुनें"}</span>
            </h4>
            
            <div className="space-y-2">
              {[
                { id: "prepayment", label: lang === "en" ? "Lump-Sum Prepayment (एकमुश्त जमा)" : "एकमुश्त आंशिक प्री-पेमेंट" },
                { id: "custom_emi", label: lang === "en" ? "Set Custom EMI (कस्टम ईएमआई सेट करें)" : "मासिक EMI अपनी मांग से बदलें" },
                { id: "extra_emi", label: lang === "en" ? "Regular Extra EMI (एक्स्ट्रा ईएमआई जोड़ें)" : "हर महीने एक्स्ट्रा ईएमआई भुगतान" },
                { id: "adjust_tenure", label: lang === "en" ? "Change Tenure Years (ऋण अवधि बदलें)" : "लोन की कुल अवधि घटाएं/बढ़ाएं" },
                { id: "super_save", label: lang === "en" ? "Super Saver Combo (सुपर सेवर योजना)" : "सुपर सेवर बचत लिंकेज योजना" }
              ].map((opt) => (
                <button
                  key={opt.id}
                  onClick={() => setRequestType(opt.id as any)}
                  className={`w-full py-3 px-4 rounded-xl text-left text-xs font-bold transition flex items-center justify-between border cursor-pointer ${
                    requestType === opt.id
                      ? "bg-indigo-650 text-white border-transparent shadow-xs"
                      : "bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-slate-200/60 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50"
                  }`}
                >
                  <span>{opt.label}</span>
                  <ChevronRight className={`w-3.5 h-3.5 ${requestType === opt.id ? "text-white" : "text-slate-400"}`} />
                </button>
              ))}
            </div>
          </div>

          {/* Dynamic adjustments based on active selected type */}
          <div className="bg-slate-550/5 dark:bg-indigo-550/5 rounded-2xl p-5 border border-dashed border-slate-200 dark:border-slate-800">
            <h4 className="text-xs font-extrabold text-slate-800 dark:text-slate-200 uppercase tracking-wider mb-4">
              {lang === "en" ? "2. Customize Parameters" : "2. परिवर्तन मान सेट करें"}
            </h4>

            {requestType === "prepayment" && (
              <div>
                <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-2">
                  {lang === "en" ? "Planned Prepayment Amount (₹)" : "एकमुश्त प्री-पेमेंट राशि (₹)"}
                </label>
                <input
                  type="number"
                  value={prepaymentVal}
                  onChange={(e) => setPrepaymentVal(e.target.value)}
                  className="w-full px-4 py-2.5 bg-white dark:bg-slate-900 border border-slate-250 dark:border-slate-805 rounded-xl font-mono font-bold text-slate-800 dark:text-slate-100 text-sm focus:outline-hidden focus:border-indigo-500"
                />
                <p className="text-[10px] text-slate-400 dark:text-slate-500 font-semibold mt-2 leading-relaxed">
                  {lang === "en" 
                    ? "Tip: Making a prepayment right away helps subtract this amount directly from your pending principal."
                    : "सुझाव: एकमुश्त भुगतान करने से यह सीधे मूलधन में से घट जाता है, जिससे आगे का ब्याज तुरंत कम होता है।"}
                </p>
              </div>
            )}

            {requestType === "custom_emi" && (
              <div>
                <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-2">
                  {lang === "en" ? "New Custom Monthly EMI Target (₹)" : "नई कस्टमाइज्ड मासिक EMI राशि (₹)"}
                </label>
                <input
                  type="number"
                  value={customEmiVal}
                  onChange={(e) => setCustomEmiVal(e.target.value)}
                  className="w-full px-4 py-2.5 bg-white dark:bg-slate-900 border border-slate-250 dark:border-slate-805 rounded-xl font-mono font-bold text-slate-800 dark:text-slate-100 text-sm focus:outline-hidden focus:border-indigo-500"
                />
                <p className="text-[10px] text-slate-400 dark:text-slate-500 font-semibold mt-2 leading-relaxed">
                  Current EMI: <strong className="text-indigo-650 dark:text-indigo-400">{formatCurrency(standardMonthlyEMI)}</strong>. Increasing EMI accelerates principal reduction!
                </p>
              </div>
            )}

            {requestType === "extra_emi" && (
              <div>
                <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-2">
                  {lang === "en" ? "Extra Recurring Prepayment (₹/Month)" : "नियमित एक्स्ट्रा EMI राशि (₹/माह)"}
                </label>
                <input
                  type="number"
                  value={extraEmiVal}
                  onChange={(e) => setExtraEmiVal(e.target.value)}
                  className="w-full px-4 py-2.5 bg-white dark:bg-slate-900 border border-slate-250 dark:border-slate-805 rounded-xl font-mono font-bold text-slate-800 dark:text-slate-100 text-sm focus:outline-hidden focus:border-indigo-500"
                />
                <p className="text-[10px] text-slate-400 dark:text-slate-500 font-semibold mt-2 leading-relaxed">
                  This extra sum is paid on top of your regular EMI each month, continuously eroding the interest basis.
                </p>
              </div>
            )}

            {requestType === "adjust_tenure" && (
              <div>
                <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-2">
                  {lang === "en" ? "Target Revised Tenure (Years)" : "बदली हुई लक्षित अवधि (वर्ष)"}
                </label>
                <input
                  type="number"
                  value={targetYears}
                  onChange={(e) => setTargetYears(e.target.value)}
                  min="1"
                  max="40"
                  className="w-full px-4 py-2.5 bg-white dark:bg-slate-900 border border-slate-250 dark:border-slate-805 rounded-xl font-mono font-bold text-slate-800 dark:text-slate-100 text-sm focus:outline-hidden focus:border-indigo-500"
                />
                <p className="text-[10px] text-slate-400 dark:text-slate-500 font-semibold mt-2 leading-relaxed">
                  Choosing a shorter target tenure results in higher EMIs but massive saving in lifetime aggregate interest.
                </p>
              </div>
            )}

            {requestType === "super_save" && (
              <div>
                <div className="p-3 bg-emerald-500/5 dark:bg-primary-500/5 rounded-xl border border-emerald-500/10 flex items-start space-x-2.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                  <div className="text-[11px] font-semibold text-emerald-800 dark:text-emerald-300 leading-relaxed">
                    {lang === "en" 
                      ? "Super Saver smart plans (like Maxgain) link your savings balance to calculate interest only on (Principal - Surplus Deposit)!" 
                      : "सुपर सेवर प्लान आपके बचत खाते को ऋण से जोड़ता है जिससे ब्याज सिर्फ (कुल मूलधन - अतिरिक्त बचत राशि) पर ही लगता है!"}
                  </div>
                </div>
                <p className="text-[10px] text-slate-400 dark:text-slate-500 font-semibold mt-3">
                  This is the most powerful method used by savvy borrowers to maintain 100% emergency liquidity while enjoying maximum loan optimization.
                </p>
              </div>
            )}
          </div>

          {/* Quick interactive stats banner */}
          <div className="p-4 bg-indigo-50 dark:bg-indigo-950/20 rounded-2xl flex items-center space-x-3">
            <div className="text-xl font-extrabold text-indigo-650 dark:text-indigo-400 shrink-0 font-sans">
              🏆
            </div>
            <div className="text-[11px] font-bold text-indigo-900 dark:text-indigo-300 leading-snug">
              <span>
                {lang === "en"
                  ? `Your Prepayment Plan saves a total of ${formatCurrency(interestSaved)} and cuts ${savedYears} years from the loan!`
                  : `आपकी स्मार्ट प्री-पेमेंट रणनीति से कुल ${formatCurrency(interestSaved)} की भारी बचत और ${savedYears} वर्ष की ऋण अवधि कम होगी!`}
              </span>
            </div>
          </div>
        </div>

        {/* Right Side: Render Printable Structured Letter Dispatch */}
        <div className="col-span-12 lg:col-span-7 flex flex-col h-full">
          
          <div className="flex justify-between items-center mb-3">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
              {lang === "en" ? "📝 Generated Dispatch Ready Draft" : "📝 प्रारूप पत्र ड्राफ्ट"}
            </span>
            <div className="flex space-x-1.5">
              <button
                onClick={handleCopyText}
                className="px-3.5 py-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 font-bold text-[11px] rounded-lg transition duration-150 flex items-center space-x-1.5 cursor-pointer text-slate-700 dark:text-slate-200 hover:scale-102"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-500 animate-bounce" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? (lang === "en" ? "Copied!" : "कॉपी किया!") : (lang === "en" ? "Copy Draft" : "कागज के लिए कॉपी करें")}</span>
              </button>
              
              <button
                onClick={handlePrint}
                className="px-3.5 py-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 font-bold text-[11px] rounded-lg transition duration-150 flex items-center space-x-1.5 cursor-pointer text-slate-700 dark:text-slate-200 hover:scale-102"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>{lang === "en" ? "Print / Save PDF" : "प्रिंट करें"}</span>
              </button>
            </div>
          </div>

          {/* Document container */}
          <div 
            ref={letterRef}
            className="flex-1 bg-slate-50 dark:bg-slate-950 p-6 sm:p-8 rounded-3xl border border-slate-200/60 dark:border-slate-800 text-slate-800 dark:text-slate-200 font-sans shadow-inner max-h-[480px] overflow-y-auto"
          >
            <div className="space-y-4 max-w-full leading-relaxed text-xs">
              <div className="flex justify-between items-start">
                <span className="font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wide font-mono text-[9px] bg-slate-200/50 dark:bg-slate-900 px-2.5 py-1 rounded-md">
                  Official Bank Draft
                </span>
                <span className="text-slate-500 dark:text-slate-450 font-bold font-mono">{letter.date}</span>
              </div>

              <div>
                <p className="font-extrabold text-slate-550 dark:text-slate-400 uppercase tracking-widest text-[9px] mb-1">To,</p>
                <p className="whitespace-pre-line font-bold text-slate-800 dark:text-slate-250 leading-relaxed text-sm">
                  {letter.to}
                </p>
              </div>

              <div className="border-y border-slate-200 dark:border-slate-800/80 py-3 my-2 bg-indigo-500/5 dark:bg-slate-900/60 px-3 rounded-xl">
                <p className="font-black text-slate-900 dark:text-white leading-relaxed whitespace-pre-line">
                  {letter.subject}
                </p>
              </div>

              {/* Bilingual Side-by-side or stacked formatting */}
              <div className="space-y-4">
                
                {/* English section */}
                <div className="border-l-2 border-indigo-500 pl-3.5 py-1">
                  <p className="font-bold text-slate-850 dark:text-slate-200 text-sm mb-1">{letter.salutation}</p>
                  <p className="text-slate-650 dark:text-slate-300 font-medium leading-relaxed">
                    {letter.bodyEn}
                  </p>
                  <p className="text-slate-600 dark:text-slate-400 font-bold whitespace-pre-line mt-4 leading-relaxed">
                    {letter.footerEn}
                  </p>
                </div>

                {/* Hindi section */}
                <div className="border-l-2 border-emerald-500 pl-3.5 py-1 bg-slate-100/50 dark:bg-slate-900/20 p-2.5 rounded-l-none rounded-r-xl">
                  <p className="font-bold text-slate-850 dark:text-slate-200 text-sm mb-1">{letter.salutationHi}</p>
                  <p className="text-slate-650 dark:text-slate-350 font-medium leading-relaxed text-[11px]">
                    {letter.bodyHi}
                  </p>
                  <p className="text-slate-600 dark:text-slate-400 font-bold whitespace-pre-line mt-4 leading-relaxed text-[11px]">
                    {letter.footerHi}
                  </p>
                </div>

              </div>

              <div className="pt-4 border-t border-slate-100 dark:border-slate-800/40 flex justify-between">
                <div>
                  <p className="text-[10px] uppercase font-bold text-slate-400">Applicant Signature</p>
                  <div className="h-9 w-28 border-b border-dashed border-slate-300 mt-2" />
                  <p className="font-black text-slate-800 dark:text-white mt-1 text-sm">{letter.sender}</p>
                </div>
                <div className="text-right">
                  <p className="text-[9px] uppercase font-mono text-slate-400 tracking-wider">Account Reference</p>
                  <p className="font-bold font-mono text-[10px] text-slate-500 mt-1">[Pfx-XXXXX-9351]</p>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
