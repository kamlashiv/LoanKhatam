import { TrendingUp, Award, Flame, PiggyBank, Sparkles, CheckCircle2 } from "lucide-react";
import { translations } from "../utils/translations";

interface EducationalHacksProps {
  regularEMI: number;
  onApplyStrategy: (strategy: {
    monthlyExtra: number;
    yearlyExtra: number;
    yearlyIncreasePercent: number;
    description: string;
    name: string;
  }) => void;
  activeStrategyName: string;
  lang: "en" | "hi" | "bilingual";
}

export default function EducationalHacks({ regularEMI, onApplyStrategy, activeStrategyName, lang }: EducationalHacksProps) {
  const roundedEMI = Math.round(regularEMI) || 15000;
  const t = translations[lang];

  // Configure strategies with localized details depending on chosen lang mode
  const strategies = [
    {
      id: "extra_emi",
      name: lang === "en" 
        ? "1 Extra EMI Rule" 
        : lang === "hi" 
        ? "1 अतिरिक्त EMI नियम" 
        : "1 Extra EMI Rule (हर साल 1 अतिरिक्त किस्त)",
      icon: TrendingUp,
      color: "from-blue-50 to-indigo-100 dark:from-slate-900 dark:to-indigo-950 border-blue-200 dark:border-indigo-900",
      iconColor: "text-blue-600 dark:text-blue-400",
      accentBg: "bg-blue-600",
      description: lang === "en"
        ? "Pay just one extra EMI every 12th month. You can easily do this using annual performance bonuses, tax returns, or festival savings."
        : lang === "hi"
        ? "हर 12वें महीने में केवल एक अतिरिक्त किस्त (EMI) चुकाएं। यह आपके बोनस या त्योहारों की वार्षिक बचत द्वारा आसानी से हो सकता है।"
        : "हर 12वें महीने में केवल एक एक्स्ट्रा EMI चुकाएं। यह आपके बोनस या त्योहारों की बचत से आसानी से हो सकता है (1 Extra EMI).",
      benefit: lang === "en"
        ? "Reduces your overall loan tenure by 4 to 6 full years!"
        : "लोन की अवधि (Tenure) को 4 से 6 साल तक कम कर देता है!",
      setup: {
        monthlyExtra: 0,
        yearlyExtra: roundedEMI,
        yearlyIncreasePercent: 0,
        name: "1 Extra EMI Rule",
        description: `Extra prepayment of ₹${roundedEMI.toLocaleString("en-IN")} annually`,
      }
    },
    {
      id: "emi_topup",
      name: lang === "en"
        ? "Yearly 5% Top-Up"
        : lang === "hi"
        ? "वार्षिक 5% टॉप-अप"
        : "Yearly 5% Top-up (हर साल 5% किस्त बढ़ाएं)",
      icon: Award,
      color: "from-emerald-50 to-teal-100 dark:from-slate-900 dark:to-teal-950 border-emerald-200 dark:border-teal-900",
      iconColor: "text-emerald-600 dark:text-emerald-400",
      accentBg: "bg-emerald-600",
      description: lang === "en"
        ? "Increase your regular monthly EMI payment by just 5% every year. As your annual salary grows, let your payment grow to crush interest."
        : lang === "hi"
        ? "अपने नियमित मासिक EMI भुगतान को हर साल केवल 5% बढ़ाएं। जैसे ही आपकी सालाना आय बढ़ेगी, ये आपकी जेब पर भारी नहीं पड़ेगा।"
        : "जैसे-जैसे आपकी इनकम बढ़ती है, अपने EMI भुगतान को हर साल सिर्फ 5% बढ़ाएं। यह आपकी जेब पर भारी भी नहीं पड़ेगा।",
      benefit: lang === "en"
        ? "Saves up to 40% of the total cumulative compounding interest!"
        : "ब्याज के कुल भुगतान में लगभग 40% तक की भारी बचत होती है!",
      setup: {
        monthlyExtra: 0,
        yearlyExtra: 0,
        yearlyIncreasePercent: 5,
        name: "Yearly 5% Top-up",
        description: "Yearly EMI payment auto-increment of 5%",
      }
    },
    {
      id: "coffee_savings",
      name: lang === "en"
        ? "Micro-Savings Strategy"
        : lang === "hi"
        ? "चाय-कॉफी माइक्रो-सेविंग्स योजना"
        : "Micro-Savings Strategy (चाय-कॉफी सेविंग्स)",
      icon: PiggyBank,
      color: "from-amber-50 to-orange-100 dark:from-slate-900 dark:to-amber-950 border-amber-200 dark:border-amber-900",
      iconColor: "text-amber-600 dark:text-amber-400",
      accentBg: "bg-amber-600",
      description: lang === "en"
        ? "Save just ₹100 daily by substituting non-essential subscriptions or takeout coffee, totaling ₹3,000 extra paid into your loan monthly."
        : lang === "hi"
        ? "गैर-जरूरी खर्चों या सप्ताहांत पार्टी से रोज़ाना केवल ₹100 बचाएं (यानी ₹3,000 प्रत्येक महीना) और उसे अतिरिक्त किस्त में जमा कर दें।"
        : "बाहर के फालतू खर्चों या वीकेंड पार्टी से रोजाना केवल ₹100 की बचत करें (यानी ₹3,000 महीना) और उसे लोन में एक्स्ट्रा जमा करें।",
      benefit: lang === "en"
        ? "Saves thousands in compounding interest with no daily friction!"
        : "चक्रवृद्धि ब्याज के चक्र को तोड़कर लाखों रुपए की बचत करता है!",
      setup: {
        monthlyExtra: 3000,
        yearlyExtra: 0,
        yearlyIncreasePercent: 0,
        name: "Micro-Savings Strategy",
        description: "Save ₹100 daily to pay extra ₹3,000 per month",
      }
    },
    {
      id: "double_impact",
      name: lang === "en"
        ? "Super-Saver Combo Plan"
        : lang === "hi"
        ? "डबल-बचत सुपर कॉम्बो"
        : "Super-Saver Combo (डबल धमाका रणनीति)",
      icon: Flame,
      color: "from-rose-50 to-pink-100 dark:from-slate-900 dark:to-rose-950 border-rose-200 dark:border-rose-900",
      iconColor: "text-rose-600 dark:text-rose-400",
      accentBg: "bg-rose-600",
      description: lang === "en"
        ? `Raise monthly EMI by 5% every year, and simultaneously pay an extra half-EMI (₹${Math.round(roundedEMI / 2).toLocaleString("en-IN")}) once per year.`
        : lang === "hi"
        ? `हर साल 5% नियमित EMI बढ़ाएं और साथ ही साल में केवल एक बार आधी EMI के बराबर (₹${Math.round(roundedEMI / 2).toLocaleString("en-IN")}) का अतिरिक्त एकमुश्त भुगतान करें।`
        : `हर साल 5% EMI भी बढ़ाएं और हर साल केवल आधे EMI के बराबर (₹${Math.round(roundedEMI / 2).toLocaleString("en-IN")}) का अतिरिक्त एकमुश्त भुगतान करें (Super Combo).`,
      benefit: lang === "en"
        ? "Closes and pays off long-term loan periods in less than half the scheduled runtime!"
        : "लोन आधे से भी बहुत कम समय में पूर्ण रूप से समाप्त हो जाएगा!",
      setup: {
        monthlyExtra: 2000,
        yearlyExtra: Math.round(roundedEMI / 2),
        yearlyIncreasePercent: 5,
        name: "Super-Saver Combo",
        description: `₹2,000/mo + ₹${Math.round(roundedEMI/2).toLocaleString("en-IN")} annual extra + 5% compounding annual top-up`,
      }
    }
  ];

  return (
    <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 shadow-sm border border-slate-100 dark:border-slate-800 transition-all duration-250">
      <div className="flex items-center space-x-3 mb-6">
        <div className="p-2.5 bg-indigo-50 dark:bg-indigo-950/50 rounded-xl">
          <Sparkles className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
        </div>
        <div>
          <h2 className="text-xl font-bold text-slate-800 dark:text-slate-100 tracking-tight">
            {t.hacksTitle}
          </h2>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            {t.hacksSubtitle}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {strategies.map((strat) => {
          const IconComponent = strat.icon;
          const isActive = activeStrategyName === strat.setup.name;

          return (
            <div
              key={strat.id}
              id={`strat-card-${strat.id}`}
              className={`flex flex-col justify-between p-5 rounded-2xl border transition-all duration-300 ${strat.color} ${
                isActive 
                  ? "ring-2 ring-indigo-500 ring-offset-2 dark:ring-offset-slate-950 scale-[1.01]" 
                  : "hover:shadow-md hover:scale-[1.005]"
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center space-x-2">
                    <span className={`p-2 rounded-xl bg-white dark:bg-slate-800 shadow-sm ${strat.iconColor}`}>
                      <IconComponent className="w-4 h-4" />
                    </span>
                    <h3 className="font-md font-semibold text-slate-800 dark:text-slate-100 text-sm sm:text-base leading-tight">
                      {strat.name}
                    </h3>
                  </div>
                  {isActive && (
                    <span className="flex items-center text-xs font-semibold bg-emerald-500 text-white px-2 py-0.5 rounded-full shadow-sm animate-pulse">
                      <CheckCircle2 className="w-3.5 h-3.5 mr-1" />
                    </span>
                  )}
                </div>

                <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-350 mb-4 leading-relaxed">
                  {strat.description}
                </p>

                <div className="space-y-1.5 p-3 rounded-xl bg-white/70 dark:bg-slate-950/40 border border-white/50 dark:border-slate-800/50 mb-4">
                  <p className="text-xs font-semibold text-emerald-700 dark:text-emerald-400 flex items-center">
                    <span className="inline-block w-1.5 h-1.5 rounded-full bg-emerald-500 mr-1.5"></span>
                    💡 {strat.benefit}
                  </p>
                </div>
              </div>

              <button
                id={`apply-btn-${strat.id}`}
                onClick={() => onApplyStrategy(strat.setup)}
                className={`w-full py-2.5 px-4 rounded-xl text-xs sm:text-sm font-bold transition-all duration-200 cursor-pointer flex items-center justify-center ${
                  isActive
                    ? "bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm"
                    : "bg-slate-800 hover:bg-slate-900 dark:bg-slate-750 dark:hover:bg-slate-650 text-white shadow-sm"
                }`}
              >
                {isActive 
                  ? (lang === "en" ? "Strategy Active!" : lang === "hi" ? "लागू किया जा चुका है" : "लागू है / Applied Succeeded") 
                  : (lang === "en" ? "Apply to Calculator" : lang === "hi" ? "कैलकुलेटर में सिमुलेशन शुरू करें" : "कैलकुलेटर में लागू करें / Apply to Calculator")}
              </button>
            </div>
          );
        })}
      </div>

      <div className="mt-5 p-4 rounded-xl bg-indigo-50/50 dark:bg-indigo-950/20 border border-indigo-150/50 dark:border-indigo-900/40 text-xs sm:text-sm text-slate-600 dark:text-slate-300">
        <h4 className="font-semibold text-indigo-900 dark:text-indigo-300 mb-1 flex items-center">
          ⚡ {t.magicExplainHeader}
        </h4>
        <p className="leading-relaxed">
          {t.magicExplainText}
        </p>
      </div>
    </div>
  );
}
