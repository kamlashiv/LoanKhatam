import { useState } from "react";
import { Sliders, Eye, EyeOff, ArrowUp, ArrowDown, Sparkles, RefreshCw, Palette, Layout, MessageSquare, Crown, Check } from "lucide-react";

export interface OwnerSettings {
  appNameEn: string;
  appNameHi: string;
  appSubtitleEn: string;
  appSubtitleHi: string;
  primaryColor: "indigo" | "emerald" | "purple" | "rose" | "amber";
  borderStyle: "dashed" | "solid" | "none";
  layoutOrder: string[];
  hiddenSections: Record<string, boolean>;
  announcementEn: string;
  announcementHi: string;
  showAnnouncement: boolean;
  boxThemes?: Record<string, "default" | "emerald" | "amber" | "purple" | "rose" | "dark">;
}

interface FounderStudioProps {
  settings: OwnerSettings;
  onUpdateSettings: (newSettings: OwnerSettings) => void;
  lang: "en" | "hi" | "bilingual";
  onReset: () => void;
}

export default function FounderStudio({ settings, onUpdateSettings, lang, onReset }: FounderStudioProps) {
  const [isOpen, setIsOpen] = useState(false);

  // Layout box names for owner's visual reference
  const sectionNames: Record<string, { en: string; hi: string }> = {
    summary: { en: "💰 Savings Summary Cards", hi: "💰 वित्तीय बचत कार्ड" },
    hacks: { en: "📚 Repayment Hack Strategies", hi: "📚 एक्स्ट्रा भुगतान योजनाएं" },
    inputsAndCharts: { en: "🛠️ Sliders Input Panel & Charts", hi: "🛠️ स्लाइडर्स और ग्राफ़्स पैनल" },
    schedule: { en: "🗄️ Detailed Amortization Table", hi: "🗄️ लोन भुगतान (EMI) तालिका" },
    pieAndLetter: { en: "📬 Official Bank Letter & Chart Pages", hi: "📬 बैंक लेटर और पाई चार्ट" },
  };

  const colors = [
    { id: "indigo", name: "Classic Indigo", class: "bg-indigo-600" },
    { id: "emerald", name: "Growth Emerald", class: "bg-emerald-600" },
    { id: "purple", name: "Royal Purple", class: "bg-purple-600" },
    { id: "rose", name: "Power Rose", class: "bg-rose-600" },
    { id: "amber", name: "Golden Amber", class: "bg-amber-600" },
  ];

  const borders = [
    { id: "solid", name: "Classic Thin" },
    { id: "dashed", name: "Creative Dashed" },
    { id: "none", name: "Border Free (Shadows Only)" },
  ];

  // Logic to shift array element up or down
  const handleShift = (index: number, direction: "up" | "down") => {
    const newOrder = [...settings.layoutOrder];
    const targetIndex = direction === "up" ? index - 1 : index + 1;

    if (targetIndex >= 0 && targetIndex < newOrder.length) {
      // Swap elements
      const temp = newOrder[index];
      newOrder[index] = newOrder[targetIndex];
      newOrder[targetIndex] = temp;
      
      onUpdateSettings({
        ...settings,
        layoutOrder: newOrder,
      });
    }
  };

  const handleToggleVisibility = (key: string) => {
    onUpdateSettings({
      ...settings,
      hiddenSections: {
        ...settings.hiddenSections,
        [key]: !settings.hiddenSections[key],
      },
    });
  };

  return (
    <div id="founder-studio-wrapper" className="bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 border border-slate-800 text-slate-100 rounded-3xl overflow-hidden shadow-xl transition-all duration-300">
      
      {/* HEADER TRIGGER BAR */}
      <div 
        id="founder-studio-trigger"
        onClick={() => setIsOpen(!isOpen)}
        className="px-6 py-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 cursor-pointer hover:bg-white/5 transition select-none"
      >
        <div className="flex items-center space-x-3">
          <div className="p-2.5 bg-amber-500/10 text-amber-400 rounded-xl animate-pulse">
            <Crown className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-[13.5px] font-black uppercase tracking-wider text-amber-300 flex items-center gap-1.5 font-sans">
              👑 APP FOUNDER & OWNER CONFIG WORKSPACE
              <span className="bg-rose-500 text-white font-black px-2 py-0.5 rounded text-[8px] normal-case animate-bounce">
                {lang === "en" ? "Editor Live" : "मैनेजर ऑन"}
              </span>
            </h3>
            <p className="text-[11px] text-slate-400 font-medium mt-0.5">
              {lang === "en" ? "Shift layout blocks, customize translations, write user alerts, and change brand presets in 1-Click!" : "सभी बॉक्स की पोजीशन बदलें, शीर्षकों को अपडेट करें और ब्रांडिंग सेट करें!"}
            </p>
          </div>
        </div>

        <button 
          id="toggle-founder-panel"
          type="button"
          className="px-4 py-2 bg-white/10 hover:bg-white/15 active:scale-95 transition text-[11px] font-black rounded-xl text-slate-200 flex items-center gap-1 cursor-pointer font-sans"
        >
          <Sliders className="w-3.5 h-3.5 text-amber-300" />
          {isOpen ? (lang === "en" ? "COLLAPSE EDITOR" : "एडिटर बंद करें") : (lang === "en" ? "OPEN BRAND MANAGER" : "ब्रांड सेटिंग्स खोलें")}
        </button>
      </div>

      {isOpen && (
        <div id="founder-studio-body" className="px-6 pb-6 pt-2 border-t border-slate-800/60 grid grid-cols-1 lg:grid-cols-12 gap-6 animate-fadeIn text-slate-300">
          
          {/* LEFT SECTION: BOX SHIFTING & VISIBILITY (12 -> 5 spaces) */}
          <div className="lg:col-span-5 space-y-4">
            <div className="flex items-center space-x-2 pb-1 border-b border-white/10">
              <Layout className="w-4 h-4 text-emerald-400" />
              <h4 className="text-xs font-black uppercase tracking-wider text-white">
                {lang === "en" ? "LAYOUT ARCHITECT (DRAG & SHIFT CODES)" : "बॉक्स शिफ्टिंग और दृश्यता प्रबंधन (Position Controls)"}
              </h4>
            </div>

            <p className="text-[11px] text-slate-400">
              {lang === "en" ? "Reorder rows dynamically or hide unnecessary information to perfect the customer funnel." : "यहाँ आप ऊपर/नीचे बटन दबाकर किसी भी कैलकुलेटर ब्लॉक को पूरे स्क्रीन पर स्थानांतरित कर सकते हैं!"}
            </p>

            <div className="space-y-2 max-h-[290px] overflow-y-auto pr-1">
              {settings.layoutOrder.map((sectionKey, index) => {
                const names = sectionNames[sectionKey] || { en: sectionKey, hi: sectionKey };
                const label = lang === "en" ? names.en : names.hi;
                const isHidden = !!settings.hiddenSections[sectionKey];

                return (
                  <div 
                    key={sectionKey} 
                    id={`owner-row-item-${sectionKey}`}
                    className={`flex items-center justify-between p-2.5 rounded-xl border text-xs font-bold transition ${
                      isHidden 
                        ? "bg-slate-900/50 border-slate-800/55 text-slate-500 opacity-60" 
                        : "bg-white/5 border-white/10 text-white"
                    }`}
                  >
                    <div className="flex items-center space-x-2">
                      <button
                        type="button"
                        onClick={() => handleToggleVisibility(sectionKey)}
                        className={`p-1 rounded cursor-pointer transition ${isHidden ? "text-rose-400 hover:bg-rose-500/10" : "text-emerald-400 hover:bg-emerald-500/10"}`}
                        title={isHidden ? "Show Section" : "Hide Section"}
                      >
                        {isHidden ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                      </button>
                      <span className="truncate max-w-[170px] sm:max-w-[210px]">{label}</span>
                    </div>

                    <div className="flex items-center space-x-1.5 shrink-0">
                      <span className="text-[9px] text-slate-500 px-1.5 py-0.5 bg-slate-900 rounded select-none">
                        {lang === "en" ? `Row ${index + 1}` : `पंक्ति ${index + 1}`}
                      </span>
                      
                      <button
                        type="button"
                        onClick={() => handleShift(index, "up")}
                        disabled={index === 0}
                        className="p-1 rounded bg-slate-850 hover:bg-slate-800 disabled:opacity-30 disabled:cursor-not-allowed cursor-pointer transition text-amber-300"
                        title="Move Up"
                      >
                        <ArrowUp className="w-3 h-3" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleShift(index, "down")}
                        disabled={index === settings.layoutOrder.length - 1}
                        className="p-1 rounded bg-slate-850 hover:bg-slate-800 disabled:opacity-30 disabled:cursor-not-allowed cursor-pointer transition text-amber-300"
                        title="Move Down"
                      >
                        <ArrowDown className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* MIDDLE SECTION: BRANDING & COLORS Customizer (12 -> 4 spaces) */}
          <div className="lg:col-span-4 space-y-4">
            <div className="flex items-center space-x-2 pb-1 border-b border-white/10">
              <Palette className="w-4 h-4 text-purple-400" />
              <h4 className="text-xs font-black uppercase tracking-wider text-white">
                {lang === "en" ? "BRAND THEME & BORDERS" : "ब्रांड रंग और स्टाइलिंग्स (Branding Preset)"}
              </h4>
            </div>

            {/* Colors Preset */}
            <div>
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-wide mb-2">
                {lang === "en" ? "Corporate Primary Accent Color" : "मुख्य ब्रांड कॉर्पोरेट कलर"}
              </label>
              <div className="flex flex-wrap gap-2.5">
                {colors.map((color) => {
                  const isSelected = settings.primaryColor === color.id;
                  return (
                    <button
                      key={color.id}
                      type="button"
                      onClick={() => onUpdateSettings({ ...settings, primaryColor: color.id as any })}
                      className={`relative w-8 h-8 rounded-full cursor-pointer border-2 transition transform hover:scale-110 active:scale-95 ${color.class} ${
                        isSelected ? "border-amber-350 scale-105 shadow-md shadow-white/10" : "border-slate-800"
                      }`}
                      title={color.name}
                    >
                      {isSelected && (
                        <div className="absolute inset-0 flex items-center justify-center text-white">
                          <Check className="w-4 h-4 text-white drop-shadow-md" />
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Borders style */}
            <div>
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-wide mb-2">
                {lang === "en" ? "Card Border Style" : "कार्ड की सीमाओं का डिज़ाइन"}
              </label>
              <div className="grid grid-cols-3 gap-2">
                {borders.map((b) => {
                  const isSelected = settings.borderStyle === b.id;
                  return (
                    <button
                      key={b.id}
                      type="button"
                      onClick={() => onUpdateSettings({ ...settings, borderStyle: b.id as any })}
                      className={`text-[10px] py-2 px-1.5 rounded-lg font-bold border transition text-center cursor-pointer ${
                        isSelected 
                          ? "bg-amber-450/15 border-amber-400 text-amber-300" 
                          : "bg-slate-900/60 border-slate-800 text-slate-400 hover:text-white"
                      }`}
                    >
                      {b.name}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* BOX-SPECIFIC REMOTE THEMES */}
            <div id="box-themes-remote-panel" className="p-3.5 bg-slate-900/60 border border-slate-800/80 rounded-2xl space-y-3">
              <label className="block text-[10.5px] font-black text-amber-300 uppercase tracking-wide flex items-center gap-1.5">
                <Palette className="w-4 h-4 text-amber-400 shrink-0" />
                <span>{lang === "en" ? "REMOTE BOX THEME MANAGER" : "बॉक्स-वार कस्टम थीम रिमोट"}</span>
              </label>

              <p className="text-[10px] text-slate-450 dark:text-slate-400 font-medium leading-relaxed">
                {lang === "en" ? "Select custom corporate presets for other individual boxes instantly:" : "ऐप के प्रत्येक मुख्य बॉक्स / कंटेनर के लिए स्वतंत्र कॉर्पोरेट रंग थीम चुनें:"}
              </p>

              {/* Active target selection */}
              <div className="space-y-2">
                {settings.layoutOrder.map((sectionKey) => {
                  const names = sectionNames[sectionKey] || { en: sectionKey, hi: sectionKey };
                  const label = lang === "en" ? names.en.replace(/^[^\s]+\s+/, '') : names.hi.replace(/^[^\s]+\s+/, '');
                  const currentTheme = settings.boxThemes?.[sectionKey] || "default";

                  const themeLabels: Record<string, string> = {
                    default: lang === "en" ? "Classic Slate" : "डिफ़ॉल्ट लाइट",
                    emerald: lang === "en" ? "Mint Emerald" : "एमराल्ड ग्लास",
                    amber: lang === "en" ? "Amber Gold" : "एम्बर गोल्ड",
                    purple: lang === "en" ? "Royal Purple" : "रॉयल पर्पल",
                    rose: lang === "en" ? "Sunset Rose" : "सूर्यास्त रोज़",
                    dark: lang === "en" ? "Sleek Dark Night" : "डार्क चारकोल",
                  };

                  return (
                    <div key={sectionKey} className="flex justify-between items-center p-2 rounded-xl bg-slate-950/45 border border-slate-900/80 gap-2 hover:border-slate-800 transition">
                      <span className="text-[10px] font-bold text-slate-100 truncate pr-1">
                        {label}
                      </span>

                      <select
                        value={currentTheme}
                        id={`theme-select-${sectionKey}`}
                        onChange={(e) => {
                          const val = e.target.value as any;
                          const currentThemes = settings.boxThemes || {};
                          onUpdateSettings({
                            ...settings,
                            boxThemes: {
                              ...currentThemes,
                              [sectionKey]: val
                            }
                          });
                        }}
                        className="bg-slate-900 border border-slate-800 text-white text-[10px] font-black rounded-lg px-2.5 py-1 focus:border-amber-400 outline-none cursor-pointer text-right"
                      >
                        <option value="default">⚪ {themeLabels.default}</option>
                        <option value="emerald">🟢 {themeLabels.emerald}</option>
                        <option value="amber">🟡 {themeLabels.amber}</option>
                        <option value="purple">🟣 {themeLabels.purple}</option>
                        <option value="rose">🔴 {themeLabels.rose}</option>
                        <option value="dark">⚫ {themeLabels.dark}</option>
                      </select>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Live notice alert toggle */}
            <div>
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-wide mb-1 flex justify-between items-center">
                <span>{lang === "en" ? "FOUNDER MARQUEE CAMPAIGN NOTICE" : "संस्थापक लाइव नोटिस (Marquee)"}</span>
                <input
                  type="checkbox"
                  checked={settings.showAnnouncement}
                  onChange={(e) => onUpdateSettings({ ...settings, showAnnouncement: e.target.checked })}
                  className="rounded border-slate-800 text-indigo-500 focus:ring-slate-900 cursor-pointer w-3.5 h-3.5"
                />
              </label>
              <div className="space-y-1.5 mt-1.5">
                <input
                  type="text"
                  placeholder="English alert text..."
                  value={settings.announcementEn}
                  onChange={(e) => onUpdateSettings({ ...settings, announcementEn: e.target.value })}
                  className="w-full bg-slate-900/85 border border-slate-800 focus:border-amber-400 rounded-lg py-1 px-2.5 text-xs text-white"
                />
                <input
                  type="text"
                  placeholder="हिन्दी अलर्ट सुचना..."
                  value={settings.announcementHi}
                  onChange={(e) => onUpdateSettings({ ...settings, announcementHi: e.target.value })}
                  className="w-full bg-slate-900/85 border border-slate-800 focus:border-amber-400 rounded-lg py-1 px-2.5 text-xs text-white"
                />
              </div>
            </div>
          </div>

          {/* RIGHT SECTION: TRANSLATION CODES CONTENT (12 -> 3 spaces) */}
          <div className="lg:col-span-3 space-y-4">
            <div className="flex items-center space-x-2 pb-1 border-b border-white/10">
              <MessageSquare className="w-4 h-4 text-amber-400" />
              <h4 className="text-xs font-black uppercase tracking-wider text-white font-sans">
                {lang === "en" ? "APP HEADERS TEXT CUSTOMIZER" : "ऐप शीर्षक टेक्स्ट संपादक"}
              </h4>
            </div>

            <div className="space-y-3">
              {/* App Names translation fields */}
              <div>
                <label className="block text-[10px] text-slate-400 font-bold mb-1">
                  App Name (English)
                </label>
                <input
                  type="text"
                  value={settings.appNameEn}
                  onChange={(e) => onUpdateSettings({ ...settings, appNameEn: e.target.value })}
                  className="w-full bg-slate-900/90 border border-slate-800 rounded-lg py-1.5 px-2.5 text-xs text-white uppercase font-black"
                />
              </div>

              <div>
                <label className="block text-[10px] text-slate-400 font-bold mb-1">
                  App Name (हिन्दी)
                </label>
                <input
                  type="text"
                  value={settings.appNameHi}
                  onChange={(e) => onUpdateSettings({ ...settings, appNameHi: e.target.value })}
                  className="w-full bg-slate-900/90 border border-slate-800 rounded-lg py-1.5 px-2.5 text-xs text-white font-bold"
                />
              </div>

              {/* Reset layout order to default */}
              <div className="pt-2">
                <button
                  type="button"
                  onClick={onReset}
                  className="w-full py-2 bg-slate-900 hover:bg-slate-850/80 active:scale-97 border border-slate-800/90 text-rose-400 hover:text-rose-300 font-black text-[10.5px] rounded-xl transition duration-155 flex items-center justify-center space-x-1.5"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>RESET TO FACTORY DEFAULTS</span>
                </button>
              </div>
            </div>
          </div>

        </div>
      )}

    </div>
  );
}
