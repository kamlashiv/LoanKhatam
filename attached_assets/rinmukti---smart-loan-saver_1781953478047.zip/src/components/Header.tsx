import { Landmark, PiggyBank, Sparkles } from "lucide-react";
import { translations } from "../utils/translations";

interface HeaderProps {
  lang: "en" | "hi" | "bilingual";
  onLangChange: (newLang: "en" | "hi" | "bilingual") => void;
  ownerSettings?: {
    appNameEn: string;
    appNameHi: string;
    appSubtitleEn: string;
    appSubtitleHi: string;
    primaryColor: string;
  };
  hideLangSelector?: boolean;
}

export default function Header({ lang, onLangChange, ownerSettings, hideLangSelector }: HeaderProps) {
  const t = translations[lang];

  const customAppName = ownerSettings
    ? (lang === "en" 
        ? ownerSettings.appNameEn 
        : lang === "hi" 
        ? ownerSettings.appNameHi 
        : `${ownerSettings.appNameEn} / ${ownerSettings.appNameHi}`)
    : t.appName;

  const customAppSubtitle = ownerSettings
    ? (lang === "en" 
        ? ownerSettings.appSubtitleEn 
        : lang === "hi" 
        ? ownerSettings.appSubtitleHi 
        : `${ownerSettings.appSubtitleEn} / ${ownerSettings.appSubtitleHi}`)
    : t.appSubtitle;

  const logoBgColor = ownerSettings
    ? (ownerSettings.primaryColor === "emerald" ? "bg-emerald-650 dark:bg-emerald-600" :
       ownerSettings.primaryColor === "purple" ? "bg-purple-650 dark:bg-purple-600" :
       ownerSettings.primaryColor === "rose" ? "bg-rose-650 dark:bg-rose-600" :
       ownerSettings.primaryColor === "amber" ? "bg-amber-600 dark:bg-amber-500" :
       "bg-indigo-600 dark:bg-indigo-500")
    : "bg-indigo-600 dark:bg-indigo-500";

  return (
    <header className="bg-white dark:bg-slate-900 border-b border-slate-100 dark:border-slate-800/80 py-5 mb-8 shadow-[0_1px_2px_rgba(0,0,0,0.02)]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* TOP LEVEL ROW: Title & Language Switcher */}
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6">
          
          {/* Logo & Headline */}
          <div className="flex items-start sm:items-center space-x-3.5 w-full lg:w-auto">
            <div className={`p-2.5 ${logoBgColor} text-white rounded-2xl shadow-lg shrink-0 flex items-center justify-center relative group overflow-hidden select-none`}>
              <svg
                id="rinmukti-brand-logo-svg"
                className="w-8 h-8 transition-transform duration-700 group-hover:scale-110"
                viewBox="0 0 100 100"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                {/* Background dash outline */}
                <circle cx="50" cy="50" r="44" stroke="currentColor" strokeWidth="2" strokeDasharray="4 4" className="opacity-50" />
                
                {/* Sparkle representing freedom */}
                <path
                  d="M50 14L53 23L62 26L53 29L50 38L47 29L38 26L47 23L50 14Z"
                  fill="#F59E0B"
                  className="animate-pulse"
                />

                {/* Broken Chain representation of RinnMukti (Freedom from Interest/Debt) */}
                {/* Left curve of broken chain */}
                <path
                  d="M34 56 C28 50 28 38 36 34 C42 31 50 35 52 42"
                  stroke="currentColor"
                  strokeWidth="5"
                  strokeLinecap="round"
                  className="opacity-90"
                />
                
                {/* Right curve of broken chain separated */}
                <path
                  d="M48 58 C50 65 58 69 64 66 C72 62 72 50 66 44"
                  stroke="currentColor"
                  strokeWidth="5"
                  strokeLinecap="round"
                  className="opacity-95"
                />

                {/* Upward growing leaf/arrow of financial prosperity */}
                <path
                  d="M50 82V40M50 40L42 48M50 40L58 48"
                  stroke="#10B981"
                  strokeWidth="6"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-[10px] font-bold text-indigo-700 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/50 px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                  {t.bilingualBadge}
                </span>
                <span className="text-[10px] font-semibold text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/50 px-2 py-0.5 rounded-full flex items-center">
                  <PiggyBank className="w-3.5 h-3.5 mr-1" />
                  {t.safetyBadge}
                </span>
                <span id="founder-owner-badge" className="text-[10px] font-extrabold text-amber-700 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/30 border border-amber-200/30 dark:border-amber-900/20 px-2.5 py-0.5 rounded-full flex items-center select-none">
                  👑 {lang === "en" ? "Founder & Owner: Shiva Chand" : lang === "hi" ? "संस्थापक और स्वामी: शिवा चंद" : "Founder & Owner: Shiva Chand / संस्थापक: शिवा चंद"}
                </span>
              </div>
              <h1 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight mt-1">
                {customAppName}
              </h1>
              <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 font-medium mt-0.5">
                {customAppSubtitle}
              </p>
            </div>
          </div>

          {/* Controls: Region Language Selectors */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 w-full lg:w-auto self-end lg:self-center">
            
            {/* Beautiful Tab/Button Language Selector Group */}
            {!hideLangSelector && (
              <div className="bg-slate-100 dark:bg-slate-800 p-1 rounded-xl flex items-center border border-slate-250 dark:border-slate-700/50">
                <button
                  id="lang-btn-en"
                  type="button"
                  onClick={() => onLangChange("en")}
                  className={`flex-1 sm:flex-none text-center px-4 py-1.5 rounded-lg text-xs font-bold transition duration-150 cursor-pointer ${
                    lang === "en"
                      ? "bg-white dark:bg-slate-700 text-indigo-700 dark:text-indigo-300 shadow-sm"
                      : "text-slate-600 dark:text-slate-400 hover:text-slate-900"
                  }`}
                >
                  🇬🇧 English
                </button>
                <button
                  id="lang-btn-hi"
                  type="button"
                  onClick={() => onLangChange("hi")}
                  className={`flex-1 sm:flex-none text-center px-4 py-1.5 rounded-lg text-xs font-bold transition duration-150 cursor-pointer ${
                    lang === "hi"
                      ? "bg-white dark:bg-slate-700 text-indigo-700 dark:text-indigo-300 shadow-sm"
                      : "text-slate-600 dark:text-slate-400 hover:text-slate-900"
                  }`}
                >
                  🇮🇳 हिन्दी
                </button>
                <button
                  id="lang-btn-bilingual"
                  type="button"
                  onClick={() => onLangChange("bilingual")}
                  className={`flex-1 sm:flex-none text-center px-4 py-1.5 rounded-lg text-xs font-bold transition duration-150 cursor-pointer ${
                    lang === "bilingual"
                      ? "bg-white dark:bg-slate-700 text-indigo-700 dark:text-indigo-300 shadow-sm"
                      : "text-slate-600 dark:text-slate-400 hover:text-slate-900"
                  }`}
                >
                  🗣️ Hinglish / द्विभाषी
                </button>
              </div>
            )}

            {/* Quick Stats Banner inside header */}
            <div className="hidden sm:flex items-center space-x-2 bg-gradient-to-r from-indigo-50 to-emerald-50/60 dark:from-indigo-950/20 dark:to-emerald-950/10 p-2.5 rounded-xl border border-indigo-100/30 dark:border-indigo-900/40 shrink-0 max-w-xs">
              <Sparkles className="w-4 h-4 text-indigo-600 dark:text-indigo-400 shrink-0" />
              <div className="text-[10.5px] text-slate-600 dark:text-slate-300 font-medium leading-relaxed">
                {t.quickBannerText}
              </div>
            </div>

          </div>

        </div>

      </div>
    </header>
  );
}
