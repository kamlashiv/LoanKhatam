import React, { useState } from "react";
import { LoanInput, PrepaymentInput, LumpSumPayment, SavedProfile } from "../types";
import { Plus, Trash2, Save, Sparkles, FileText, Upload } from "lucide-react";
import { translations } from "../utils/translations";
import { calculateEMI } from "../utils/loanCalculator";

interface LoanCalculatorFormProps {
  input: LoanInput;
  prepayments: PrepaymentInput;
  onChangeInput: (newInput: LoanInput) => void;
  onChangePrepayments: (newPrepayment: PrepaymentInput) => void;
  savedProfiles: SavedProfile[];
  onSaveProfile: (name: string) => void;
  onSelectProfile: (id: string) => void;
  onDeleteProfile: (id: string) => void;
  onFileUpload: (event: React.ChangeEvent<HTMLInputElement>) => void;
  lang: "en" | "hi" | "bilingual";
}

export default function LoanCalculatorForm({
  input,
  prepayments,
  onChangeInput,
  onChangePrepayments,
  savedProfiles,
  onSaveProfile,
  onSelectProfile,
  onDeleteProfile,
  onFileUpload,
  lang,
}: LoanCalculatorFormProps) {
  const [profileName, setProfileName] = useState("");
  const [lumpSumAmt, setLumpSumAmt] = useState<number | "">("");
  const [lumpSumMonth, setLumpSumMonth] = useState<number | "">("");
  const [lumpSumLabel, setLumpSumLabel] = useState("");
  const [showProfileSaver, setShowProfileSaver] = useState(false);

  // States to toggle tenure unit between Years and Months & manage raw input
  const [tenureUnit, setTenureUnit] = useState<"years" | "months">("years");
  const [localTenureVal, setLocalTenureVal] = useState<string>(input.tenureYears.toString());

  // State to manage target EMI calculation
  const [targetEmiInput, setTargetEmiInput] = useState<string>("");

  React.useEffect(() => {
    if (tenureUnit === "years") {
      setLocalTenureVal(input.tenureYears.toString());
    } else {
      setLocalTenureVal(Math.round(input.tenureYears * 12).toString());
    }
  }, [input.tenureYears, tenureUnit]);

  const t = translations[lang];

  // Quick limits
  const maxAmount = 100000000; // 10 Crores
  const maxRate = 30; // 30%
  const maxTenure = 40; // 40 Years

  const handleInputChange = (field: keyof LoanInput, val: string | number) => {
    let numericVal = typeof val === "string" ? parseFloat(val) : val;
    if (isNaN(numericVal)) {
      numericVal = 0;
    }

    if (field === "amount" && numericVal > maxAmount) numericVal = maxAmount;
    if (field === "rate" && numericVal > maxRate) numericVal = maxRate;
    if (field === "tenureYears" && numericVal > maxTenure) numericVal = maxTenure;

    onChangeInput({
      ...input,
      [field]: numericVal,
    });
  };

  const handleToggleUnit = (unit: "years" | "months") => {
    setTenureUnit(unit);
    if (unit === "years") {
      setLocalTenureVal(input.tenureYears.toString());
    } else {
      setLocalTenureVal(Math.round(input.tenureYears * 12).toString());
    }
  };

  const handleTenureInputRawChange = (valStr: string) => {
    setLocalTenureVal(valStr);
    let numericVal = parseFloat(valStr);
    if (isNaN(numericVal) || numericVal <= 0) {
      return; // Let user type raw content
    }

    if (tenureUnit === "years") {
      if (numericVal > maxTenure) numericVal = maxTenure;
      onChangeInput({
        ...input,
        tenureYears: numericVal,
      });
    } else {
      const maxMonths = maxTenure * 12;
      if (numericVal > maxMonths) numericVal = maxMonths;
      onChangeInput({
        ...input,
        tenureYears: numericVal / 12,
      });
    }
  };

  const handleSliderTenureChange = (val: string) => {
    const numericVal = parseFloat(val);
    if (tenureUnit === "years") {
      onChangeInput({ ...input, tenureYears: numericVal });
      setLocalTenureVal(numericVal.toString());
    } else {
      onChangeInput({ ...input, tenureYears: numericVal / 12 });
      setLocalTenureVal(Math.round(numericVal).toString());
    }
  };

  const handlePrepaymentChange = (field: keyof PrepaymentInput, val: string | number) => {
    let numericVal = typeof val === "string" ? parseFloat(val) : val;
    if (isNaN(numericVal)) {
      numericVal = 0;
    }

    onChangePrepayments({
      ...prepayments,
      [field]: numericVal,
    });
  };

  const addLumpSum = (e: React.FormEvent) => {
    e.preventDefault();
    if (!lumpSumAmt || !lumpSumMonth) return;

    const amt = Number(lumpSumAmt);
    const mth = Number(lumpSumMonth);

    if (amt <= 0 || mth <= 0 || mth > input.tenureYears * 12) {
      alert(lang === "en" 
        ? "Please enter valid amount and month (within loan tenure limits)!"
        : "कृपया मान्य राशि और महीना दर्ज करें (लोन की कुल अवधि के अंदर)!");
      return;
    }

    const labelText = lumpSumLabel.trim();
    const fallbackText = lang === "en" ? `Lump-sum (Month ${mth})` : `एकमुश्त (माह ${mth})`;

    const newPayment: LumpSumPayment = {
      id: Math.random().toString(36).substr(2, 9),
      amount: amt,
      atMonth: mth,
      label: labelText || fallbackText
    };

    onChangePrepayments({
      ...prepayments,
      lumpSums: [...prepayments.lumpSums, newPayment].sort((a, b) => a.atMonth - b.atMonth),
    });

    setLumpSumAmt("");
    setLumpSumMonth("");
    setLumpSumLabel("");
  };

  const removeLumpSum = (id: string) => {
    onChangePrepayments({
      ...prepayments,
      lumpSums: prepayments.lumpSums.filter((item) => item.id !== id),
    });
  };

  const saveProfileHandler = (e: React.FormEvent) => {
    e.preventDefault();
    if (!profileName.trim()) return;
    onSaveProfile(profileName.trim());
    setProfileName("");
    setShowProfileSaver(false);
  };

  return (
    <div className="space-y-6">
      {/* 📥 SECTION A: PROFILE MANAGER & FILE UPLOADER */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-100 dark:border-slate-800">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-4">
          <div>
            <h3 className="font-bold text-slate-800 dark:text-slate-150 text-base">
              {t.profileTitle}
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              {t.profileSubtitle}
            </p>
          </div>
          <div className="flex flex-wrap gap-2 w-full sm:w-auto">
            <button
              id="btn-show-saver"
              onClick={() => setShowProfileSaver(!showProfileSaver)}
              className="px-3.5 py-1.5 bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/40 dark:hover:bg-indigo-900/60 text-indigo-700 dark:text-indigo-300 text-xs font-semibold rounded-xl transition duration-200 cursor-pointer flex items-center space-x-1"
            >
              <Save className="w-3.5 h-3.5" />
              <span>{t.saveCurrentBtn}</span>
            </button>

            {/* Hidden File input */}
            <label className="px-3.5 py-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-semibold rounded-xl transition duration-200 cursor-pointer flex items-center space-x-1.5">
              <Upload className="w-3.5 h-3.5" />
              <span>{t.uploadFileBtn}</span>
              <input
                id="loan-file-upload-input"
                type="file"
                accept=".csv,.json,.txt,.pdf,.jpg,.jpeg,.png,.webp"
                onChange={onFileUpload}
                className="hidden"
              />
            </label>
          </div>
        </div>

        {showProfileSaver && (
          <form id="form-save-profile" onSubmit={saveProfileHandler} className="mb-4 p-3 bg-indigo-50/50 dark:bg-indigo-950/20 rounded-xl border border-indigo-100/50 dark:border-indigo-900/40 flex flex-col sm:flex-row gap-2 transition duration-200 animate-fadeIn">
            <input
              id="input-profile-name"
              type="text"
              placeholder={t.saveProfilePlaceholder}
              value={profileName}
              onChange={(e) => setProfileName(e.target.value)}
              className="flex-grow px-3 py-1.5 text-xs sm:text-sm rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              maxLength={25}
              required
            />
            <div className="flex gap-2">
              <button
                id="btn-submit-profile-save"
                type="submit"
                className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold cursor-pointer"
              >
                {t.saveBtn}
              </button>
              <button
                id="btn-cancel-profile-save"
                type="button"
                onClick={() => {
                  setShowProfileSaver(false);
                  setProfileName("");
                }}
                className="px-3 py-1.5 bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-lg text-xs font-semibold cursor-pointer"
              >
                {t.cancelBtn}
              </button>
            </div>
          </form>
        )}

        {savedProfiles.length > 0 ? (
          <div className="flex flex-wrap gap-2 pt-2">
            {savedProfiles.map((prof, idx) => (
              <div
                key={`${prof.id || 'prof'}-${idx}`}
                id={`profile-item-${prof.id}`}
                className="flex items-center space-x-1.5 bg-slate-50 dark:bg-slate-800/80 pr-2 pl-3 py-1 rounded-full border border-slate-200 dark:border-slate-700/60 transition hover:border-slate-300 dark:hover:border-slate-600"
              >
                <button
                  id={`btn-select-profile-${prof.id}`}
                  onClick={() => onSelectProfile(prof.id)}
                  className="text-xs font-bold text-slate-700 dark:text-slate-300 hover:text-indigo-600 dark:hover:text-indigo-400 transition cursor-pointer"
                >
                  {prof.name}
                </button>
                <button
                  id={`btn-delete-profile-${prof.id}`}
                  onClick={() => onDeleteProfile(prof.id)}
                  title={lang === "en" ? "Delete Profile" : "हटाएं"}
                  className="p-0.5 text-slate-400 hover:text-rose-500 rounded transition cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-xs text-slate-400 dark:text-slate-500 italic pt-1">
            {t.noProfilesItem}
          </p>
        )}
      </div>

      {/* 🏡 SECTION B: MAIN LOAN PARAMETERS */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-100 dark:border-slate-800">
        <div className="flex items-center space-x-2.5 mb-5">
          <div className="p-2 bg-indigo-50 dark:bg-indigo-950/40 rounded-xl">
            <FileText className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
          </div>
          <h3 className="font-bold text-slate-800 dark:text-slate-150 text-base">
            {t.loanDetailsTitle}
          </h3>
        </div>

        <div className="space-y-4">
          {/* 1. Loan Amount */}
          <div>
            <div className="flex justify-between items-center mb-1">
              <label htmlFor="input-loan-amount" className="text-xs sm:text-sm font-semibold text-slate-700 dark:text-slate-300">
                {t.principalLabel}
              </label>
              <input
                id="input-loan-amount"
                type="number"
                min={10000}
                max={maxAmount}
                step={50000}
                value={input.amount || ""}
                onChange={(e) => handleInputChange("amount", e.target.value)}
                className="w-32 px-2 py-1 text-right text-xs sm:text-sm font-bold rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-indigo-650 dark:text-indigo-400 focus:outline-none"
              />
            </div>
            <input
              id="slider-loan-amount"
              type="range"
              min={100000}
              max={25000000} // Up to 2.5 Crore slider
              step={10000}
              value={input.amount}
              onChange={(e) => handleInputChange("amount", e.target.value)}
              className="w-full h-1.5 bg-slate-150 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-600"
            />
            <div className="flex justify-between text-[10px] text-slate-400 mt-1 font-mono">
              <span>₹1 L</span>
              <span>₹50 L</span>
              <span>₹1.5 Cr</span>
              <span>₹2.5 Cr</span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* 2. Interest Rate */}
            <div>
              <div className="flex justify-between items-center mb-1">
                <label htmlFor="input-loan-rate" className="text-xs sm:text-sm font-semibold text-slate-700 dark:text-slate-300">
                  {t.interestRateLabel}
                </label>
                <input
                  id="input-loan-rate"
                  type="number"
                  min={1}
                  max={maxRate}
                  step={0.1}
                  value={input.rate || ""}
                  onChange={(e) => handleInputChange("rate", e.target.value)}
                  className="w-20 px-2 py-1 text-right text-xs sm:text-sm font-bold rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                />
              </div>
              <input
                id="slider-loan-rate"
                type="range"
                min={3}
                max={20}
                step={0.1}
                value={input.rate}
                onChange={(e) => handleInputChange("rate", e.target.value)}
                className="w-full h-1.5 bg-slate-150 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-600"
              />
              <div className="flex justify-between text-[10px] text-slate-400 mt-1 font-mono">
                <span>3%</span>
                <span>10%</span>
                <span>20%</span>
              </div>
            </div>

            {/* 3. Tenure Unit toggle and Input */}
            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 bg-indigo-600 rounded-full animate-pulse" />
                  {lang === "en" ? "Tenure Unit" : lang === "hi" ? "लोन अवधि का विकल्प" : "Tenure Unit/अवधि विकल्प"}
                </span>
                
                {/* Years / Months Pill Toggle */}
                <div className="bg-slate-100 dark:bg-slate-800/80 p-0.5 rounded-lg flex items-center shadow-inner border border-slate-200/20">
                  <button
                    id="toggle-unit-years-btn"
                    type="button"
                    onClick={() => handleToggleUnit("years")}
                    className={`px-3 py-1 text-[10px] font-black rounded-md transition select-none cursor-pointer ${
                      tenureUnit === "years"
                        ? "bg-white dark:bg-slate-700 text-indigo-650 dark:text-indigo-300 shadow-xs"
                        : "text-slate-500 hover:text-slate-700 dark:hover:text-slate-300"
                    }`}
                  >
                    {lang === "en" ? "Years" : lang === "hi" ? "वर्ष" : "Years / वर्ष"}
                  </button>
                  <button
                    id="toggle-unit-months-btn"
                    type="button"
                    onClick={() => handleToggleUnit("months")}
                    className={`px-3 py-1 text-[10px] font-black rounded-md transition select-none cursor-pointer ${
                      tenureUnit === "months"
                        ? "bg-white dark:bg-slate-700 text-indigo-650 dark:text-indigo-300 shadow-xs"
                        : "text-slate-500 hover:text-slate-700 dark:hover:text-slate-300"
                    }`}
                  >
                    {lang === "en" ? "Months" : lang === "hi" ? "महीने" : "Months / महीने"}
                  </button>
                </div>
              </div>

              <div className="flex justify-between items-center mb-1.5">
                <label htmlFor="input-loan-tenure" className="text-xs text-slate-500 dark:text-slate-400 font-medium select-none">
                  {tenureUnit === "years"
                    ? (lang === "en" ? "Tenure in Years:" : "लोन अवधि (वर्ष):")
                    : (lang === "en" ? "Tenure in Months:" : "लोन अवधि (महीने):")}
                </label>
                <div className="flex items-center space-x-1.5">
                  <input
                    id="input-loan-tenure"
                    type="number"
                    min={tenureUnit === "years" ? 1 : 12}
                    max={tenureUnit === "years" ? maxTenure : maxTenure * 12}
                    step={1}
                    value={localTenureVal}
                    onChange={(e) => handleTenureInputRawChange(e.target.value)}
                    className="w-24 px-2 py-1 text-right text-xs sm:text-sm font-black rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-indigo-650 dark:text-indigo-400"
                  />
                  <span className="text-xs font-bold text-slate-400">
                    {tenureUnit === "years"
                      ? (lang === "en" ? "Yrs" : "वर्ष")
                      : (lang === "en" ? "Months" : "महीने")}
                  </span>
                </div>
              </div>

              <input
                id="slider-loan-tenure"
                type="range"
                min={tenureUnit === "years" ? 1 : 12}
                max={tenureUnit === "years" ? maxTenure : maxTenure * 12}
                step={1}
                value={tenureUnit === "years" ? input.tenureYears : Math.round(input.tenureYears * 12)}
                onChange={(e) => handleSliderTenureChange(e.target.value)}
                className="w-full h-1.5 bg-slate-150 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-600"
              />
              
              <div className="flex justify-between text-[9px] text-slate-400 mt-1 font-mono">
                {tenureUnit === "years" ? (
                  <>
                    <span>1 Yr (12 Mo)</span>
                    <span>15 Yrs (180 Mo)</span>
                    <span>30 Yrs (360 Mo)</span>
                    <span>40 Yrs (480 Mo)</span>
                  </>
                ) : (
                  <>
                    <span>12 Months (1 Yr)</span>
                    <span>180 Months (15 Yrs)</span>
                    <span>360 Months (30 Yrs)</span>
                    <span>480 Months (40 Yrs)</span>
                  </>
                )}
              </div>
            </div>
          </div>

          {/* 4. Start Date */}
          <div>
            <label htmlFor="input-start-date" className="block text-xs sm:text-sm font-semibold text-slate-700 dark:text-slate-300 mb-1">
              {t.startDateLabel}
            </label>
            <input
              id="input-start-date"
              type="month"
              value={input.startDate}
              onChange={(e) => onChangeInput({ ...input, startDate: e.target.value })}
              className="w-full px-3 py-1.5 text-xs sm:text-sm rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            />
          </div>

          {/* 🌟 🦸‍♂️ KID-FRIENDLY TOP-UP LOAN BLOCK (क्या आपने कोई टॉप-अप लोन लिया है?) 🦸‍♂️ 🌟 */}
          <div className="p-4 bg-amber-50/40 dark:bg-amber-950/15 rounded-2xl border border-amber-300/60 dark:border-amber-500/20 space-y-3">
            <div className="flex items-center space-x-2">
              <span className="text-xl">🦸‍♂️</span>
              <div>
                <h4 className="text-xs sm:text-sm font-black text-amber-900 dark:text-amber-200 uppercase tracking-tight">
                  {lang === "en" ? "Do you have a Top-up Loan?" : "क्या आपके पास कोई टॉप-अप लोन है?"}
                </h4>
                <p className="text-[10px] text-amber-700/80 dark:text-amber-400">
                  {lang === "en" ? "Calculate additional topup amount and its impact!" : "बैंक से ऊपर से लिया एक्स्ट्रा कर्ज और उसकी गणना!"}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {/* Top-up principal */}
              <div>
                <label className="block text-[10px] font-black text-slate-500 dark:text-slate-400 mb-1">
                  {lang === "en" ? "Topup Amount (₹)" : "टॉपअप राशि (₹)"}
                </label>
                <input
                  id="topup-amount-input"
                  type="number"
                  placeholder="0"
                  value={input.topUpAmount || ""}
                  onChange={(e) => {
                    const val = parseFloat(e.target.value);
                    onChangeInput({
                      ...input,
                      topUpAmount: isNaN(val) ? undefined : val
                    });
                  }}
                  className="w-full px-2.5 py-1.5 text-xs font-bold rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-1 focus:ring-amber-400"
                />
              </div>

              {/* Top-up Interest rate */}
              <div>
                <label className="block text-[10px] font-black text-slate-500 dark:text-slate-400 mb-1">
                  {lang === "en" ? "Topup Rate (% yr)" : "टॉपअप ब्याज दर (% वर्ष)"}
                </label>
                <input
                  id="topup-rate-input"
                  type="number"
                  placeholder={input.rate.toString()}
                  value={input.topUpRate || ""}
                  onChange={(e) => {
                    const val = parseFloat(e.target.value);
                    onChangeInput({
                      ...input,
                      topUpRate: isNaN(val) ? undefined : val
                    });
                  }}
                  className="w-full px-2.5 py-1.5 text-xs font-bold rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-1 focus:ring-amber-400"
                />
              </div>

              {/* Month tag */}
              <div>
                <label className="block text-[10px] font-black text-slate-500 dark:text-slate-400 mb-1">
                  {lang === "en" ? "Month taken" : "किस महीने में लिया (महीना नं)"}
                </label>
                <input
                  id="topup-month-input"
                  type="number"
                  min={1}
                  max={input.tenureYears * 12}
                  placeholder="24"
                  value={input.topUpMonth || ""}
                  onChange={(e) => {
                    const val = parseInt(e.target.value, 10);
                    onChangeInput({
                      ...input,
                      topUpMonth: isNaN(val) ? undefined : val
                    });
                  }}
                  className="w-full px-2.5 py-1.5 text-xs font-bold rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-1 focus:ring-amber-400"
                />
              </div>
            </div>
          </div>

          {/* 🌟 GORGEOUS REAL-TIME GENERATED EMI PRESENTATION */}
          {(() => {
            const currentEMI = calculateEMI(input.amount, input.rate, input.tenureYears);
            
            // Reverse target EMI variables evaluation 
            const targetEmiNum = parseFloat(targetEmiInput);
            let resolvedTenureText = "";
            let isErrorEmi = false;
            
            if (targetEmiNum && targetEmiNum > 0) {
              const r = input.rate / 12 / 100;
              const monthlyAccruedInterest = input.amount * r;
              if (targetEmiNum <= monthlyAccruedInterest) {
                isErrorEmi = true;
                resolvedTenureText = lang === "en" 
                  ? `⚠️ Must exceed interest of ₹${Math.round(monthlyAccruedInterest).toLocaleString("en-IN")}/mo`
                  : `⚠️ ब्याज राशि ₹${Math.round(monthlyAccruedInterest).toLocaleString("en-IN")}/माह से अधिक लिखें`;
              } else {
                const totMonthsRaw = r === 0 
                  ? input.amount / targetEmiNum 
                  : Math.log(targetEmiNum / (targetEmiNum - monthlyAccruedInterest)) / Math.log(1 + r);
                
                const totMonths = Math.round(totMonthsRaw);
                const yrs = (totMonths / 12).toFixed(1);
                resolvedTenureText = lang === "en"
                  ? `⏱️ Pays off loan in ${totMonths} Months (~${yrs} Years)`
                  : `⏱️ लोन भुगतान ${totMonths} महीनों (~${yrs} वर्ष) में संपूर्ण होगा!`;
              }
            }

            return (
              <div className="space-y-3.5 pt-2">
                <div className="p-4 bg-slate-50 dark:bg-slate-950/40 rounded-2xl border border-slate-100 dark:border-slate-800/80 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 shadow-inner">
                  <div>
                    <span className="text-[10px] font-black uppercase tracking-widest text-indigo-650 dark:text-indigo-400">
                      {lang === "en" ? "How much EMI is generated?" : lang === "hi" ? "कितनी EMI बनती है?" : "Generated Monthly EMI"}
                    </span>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                      {lang === "en" ? "Instantaneous Equated Instalment" : lang === "hi" ? "आपके पैरामीटर के आधार पर किस्त" : "Scheduled EMI Payment"}
                    </p>
                  </div>
                  <div className="sm:text-right flex items-baseline sm:flex-col gap-1.5 sm:gap-0">
                    <span className="text-xl sm:text-2xl font-black text-slate-900 dark:text-indigo-300 font-sans">
                      ₹{Math.round(currentEMI).toLocaleString("en-IN")}
                    </span>
                    <span className="text-[10px] text-slate-400 font-extrabold tracking-wider uppercase">
                      {lang === "en" ? "per month" : lang === "hi" ? "प्रति महीना" : "per month"}
                    </span>
                  </div>
                </div>

                {/* 🎯 REVERSE CALCULATOR: ENTER DESIRED EMI TO RE-CALCULATE TENURE */}
                <div className="p-4 bg-indigo-50/20 dark:bg-indigo-950/10 rounded-2xl border border-indigo-500/10 flex flex-col gap-2.5">
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-1.5">
                    <div>
                      <span className="text-[10.5px] font-bold text-indigo-700 dark:text-indigo-300 uppercase tracking-wide flex items-center gap-1">
                        <Sparkles className="w-3 h-3 text-amber-500" />
                        {lang === "en" ? "Reverse Calculator: EMI Target" : "रिवर्स कैलकुलेटर: मनपसंद EMI"}
                      </span>
                      <p className="text-[10px] text-slate-500 dark:text-slate-400">
                        {lang === "en" ? "Type how much EMI you WANT to pay to find the tenure:" : "यह देखने के लिए बजट लिखें कि लोन कितने समय में पूरा हो जाएगा:"}
                      </p>
                    </div>
                    
                    <div className="relative rounded-lg shadow-sm w-full sm:w-auto">
                      <span className="absolute inset-y-0 left-0 pl-2.5 flex items-center text-xs font-bold text-slate-400 pointer-events-none">₹</span>
                      <input
                        id="user-target-emi-recount"
                        type="number"
                        placeholder={Math.round(currentEMI + 5000).toString()}
                        value={targetEmiInput}
                        onChange={(e) => setTargetEmiInput(e.target.value)}
                        className="w-full sm:w-28 pl-6 pr-2 py-1 text-xs font-bold border border-slate-205 dark:border-slate-800/80 bg-white dark:bg-slate-900 rounded-lg text-slate-800 dark:text-slate-200 focus:ring-1 focus:ring-indigo-500 focus:outline-none focus:border-indigo-500"
                      />
                    </div>
                  </div>

                  {targetEmiInput && (
                    <div className={`p-2.5 rounded-xl text-xs font-bold ${
                      isErrorEmi 
                        ? "bg-rose-50 dark:bg-rose-950/20 text-rose-650 dark:text-rose-400 border border-rose-100" 
                        : "bg-emerald-50 dark:bg-emerald-950/30 text-emerald-700 dark:text-emerald-405 border border-emerald-100/40"
                    }`}>
                      {resolvedTenureText}
                    </div>
                  )}
                </div>
              </div>
            );
          })()}
        </div>
      </div>

      {/* 🚀 SECTION C: EXTRA PAYMENTS PLANNING */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-100 dark:border-slate-800">
        <div className="flex items-center space-x-2.5 mb-5">
          <div className="p-2 bg-emerald-50 dark:bg-emerald-950/40 rounded-xl">
            <Sparkles className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
          </div>
          <h3 className="font-bold text-slate-800 dark:text-slate-150 text-base">
            {t.plannerTitle}
          </h3>
        </div>

        <div className="space-y-4">
          {/* 1. Monthly Extra Prepayment */}
          <div>
            <div className="flex justify-between items-center mb-1">
              <label htmlFor="input-monthly-extra" className="text-xs sm:text-sm font-semibold text-slate-700 dark:text-slate-300">
                {t.monthlyExtraLabel}
              </label>
              <input
                id="input-monthly-extra"
                type="number"
                min={0}
                step={500}
                value={prepayments.monthlyExtra || ""}
                onChange={(e) => handlePrepaymentChange("monthlyExtra", e.target.value)}
                className="w-24 px-2 py-1 text-right text-xs sm:text-sm font-bold rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-emerald-600 dark:text-emerald-400 focus:outline-none"
              />
            </div>
            <input
              id="slider-monthly-extra"
              type="range"
              min={0}
              max={50000}
              step={500}
              value={prepayments.monthlyExtra}
              onChange={(e) => handlePrepaymentChange("monthlyExtra", e.target.value)}
              className="w-full h-1.5 bg-slate-150 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-600"
            />
            <div className="flex justify-between text-[10px] text-slate-400 mt-1 font-mono">
              <span>₹0</span>
              <span>₹10,000</span>
              <span>₹30,000</span>
              <span>₹50,000</span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* 2. Yearly Extra Prepayment */}
            <div>
              <div className="flex justify-between items-center mb-1">
                <label htmlFor="input-yearly-extra" className="text-xs sm:text-sm font-semibold text-slate-700 dark:text-slate-300">
                  {t.yearlyExtraLabel}
                </label>
                <input
                  id="input-yearly-extra"
                  type="number"
                  min={0}
                  step={1000}
                  value={prepayments.yearlyExtra || ""}
                  onChange={(e) => handlePrepaymentChange("yearlyExtra", e.target.value)}
                  className="w-24 px-2 py-1 text-right text-xs sm:text-sm font-bold rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                />
              </div>
              <input
                id="slider-yearly-extra"
                type="range"
                min={0}
                max={200000}
                step={2000}
                value={prepayments.yearlyExtra}
                onChange={(e) => handlePrepaymentChange("yearlyExtra", e.target.value)}
                className="w-full h-1.5 bg-slate-150 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-600"
              />
              <div className="relative inline-block group/tooltip mt-2">
                <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-100/80 dark:bg-slate-800/80 hover:bg-indigo-55 dark:hover:bg-indigo-950/40 text-[10px] font-bold text-indigo-600 dark:text-indigo-400 cursor-help select-none transition-all border border-slate-200/40 dark:border-slate-700/40">
                  <span>💡 {lang === "en" ? "Important Note" : lang === "hi" ? "महत्वपूर्ण नोट" : "Important Note / नोट"}</span>
                  <span className="text-[8px] text-indigo-400">&#9662;</span>
                </div>
                
                {/* TOOLTIP BUBBLE */}
                <div className="absolute bottom-full left-0 md:left-1/2 md:-translate-x-1/2 mb-2 w-72 p-3 bg-slate-950 text-white dark:bg-white dark:text-slate-900 rounded-xl shadow-xl border border-slate-800 dark:border-slate-200 text-[11px] leading-relaxed font-semibold transition-all duration-200 origin-bottom opacity-0 pointer-events-none scale-95 translate-y-1 group-hover/tooltip:opacity-100 group-hover/tooltip:pointer-events-auto group-hover/tooltip:scale-100 group-hover/tooltip:translate-y-0 z-[100]">
                  <div className="font-extrabold text-[9px] uppercase text-indigo-400 dark:text-indigo-600 mb-1 tracking-wider">
                    {lang === "en" ? "Prepayment Guideline" : "अतिरिक्त भुगतान निर्देश"}
                  </div>
                  <p>{t.yearlyExtraNote}</p>
                  <div className="absolute top-full left-5 md:left-1/2 md:-translate-x-1/2 -mt-1 border-4 border-transparent border-t-slate-950 dark:border-t-white" />
                </div>
              </div>
            </div>

            {/* 3. EMI Top-Up Annual % */}
            <div>
              <div className="flex justify-between items-center mb-1">
                <label htmlFor="input-emi-increase" className="text-xs sm:text-sm font-semibold text-slate-700 dark:text-slate-300">
                  {t.topupLabel}
                </label>
                <input
                  id="input-emi-increase"
                  type="number"
                  min={0}
                  max={25}
                  step={0.5}
                  value={prepayments.yearlyIncreasePercent || ""}
                  onChange={(e) => handlePrepaymentChange("yearlyIncreasePercent", e.target.value)}
                  className="w-16 px-2 py-1 text-right text-xs sm:text-sm font-bold rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                />
              </div>
              <input
                id="slider-emi-increase"
                type="range"
                min={0}
                max={20}
                step={1}
                value={prepayments.yearlyIncreasePercent}
                onChange={(e) => handlePrepaymentChange("yearlyIncreasePercent", e.target.value)}
                className="w-full h-1.5 bg-slate-150 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-600"
              />
              <div className="relative inline-block group/tooltip mt-2">
                <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-100/80 dark:bg-slate-800/80 hover:bg-indigo-55 dark:hover:bg-indigo-950/40 text-[10px] font-bold text-indigo-600 dark:text-indigo-400 cursor-help select-none transition-all border border-slate-200/40 dark:border-slate-700/40">
                  <span>💡 {lang === "en" ? "Important Note" : lang === "hi" ? "महत्वपूर्ण नोट" : "Important Note / नोट"}</span>
                  <span className="text-[8px] text-indigo-400">&#9662;</span>
                </div>
                
                {/* TOOLTIP BUBBLE */}
                <div className="absolute bottom-full left-0 md:left-1/2 md:-translate-x-1/2 mb-2 w-72 p-3 bg-slate-950 text-white dark:bg-white dark:text-slate-900 rounded-xl shadow-xl border border-slate-800 dark:border-slate-200 text-[11px] leading-relaxed font-semibold transition-all duration-200 origin-bottom opacity-0 pointer-events-none scale-95 translate-y-1 group-hover/tooltip:opacity-100 group-hover/tooltip:pointer-events-auto group-hover/tooltip:scale-100 group-hover/tooltip:translate-y-0 z-[100]">
                  <div className="font-extrabold text-[9px] uppercase text-indigo-400 dark:text-indigo-600 mb-1 tracking-wider">
                    {lang === "en" ? "Top-Up Strategy" : "कमिटमेंट रणनीति"}
                  </div>
                  <p>{t.topupNote}</p>
                  <div className="absolute top-full left-5 md:left-1/2 md:-translate-x-1/2 -mt-1 border-4 border-transparent border-t-slate-950 dark:border-t-white" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 🔮 SECTION D: ONCE-IN-A-WHILE LUMPSUM MILESTONES */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-100 dark:border-slate-800">
        <h3 className="font-bold text-slate-800 dark:text-slate-150 text-base mb-2">
          {t.lumpsumTitle}
        </h3>
        <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
          {t.lumpsumSubtitle}
        </p>

        {/* Form to Add Lump Sum */}
        <form id="form-add-lumpsum" onSubmit={addLumpSum} className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-4 p-3.5 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200/50 dark:border-slate-800">
          <div>
            <label htmlFor="input-lumpsum-amt" className="block text-[11px] font-bold text-slate-600 dark:text-slate-400 mb-1">
              {t.amtLabel}
            </label>
            <input
              id="input-lumpsum-amt"
              type="number"
              min={100}
              placeholder="e.g. 50000"
              value={lumpSumAmt}
              onChange={(e) => setLumpSumAmt(e.target.value === "" ? "" : Number(e.target.value))}
              className="w-full px-3 py-1.5 text-xs sm:text-sm rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-805 dark:text-slate-100"
              required
            />
          </div>

          <div>
            <label htmlFor="input-lumpsum-month" className="block text-[11px] font-bold text-slate-600 dark:text-slate-400 mb-1">
              {t.monthIndexLabel} (1 - {input.tenureYears * 12})
            </label>
            <input
              id="input-lumpsum-month"
              type="number"
              min={1}
              max={input.tenureYears * 12}
              placeholder="e.g. 15"
              value={lumpSumMonth}
              onChange={(e) => setLumpSumMonth(e.target.value === "" ? "" : Number(e.target.value))}
              className="w-full px-3 py-1.5 text-xs sm:text-sm rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-805 dark:text-slate-100"
              required
            />
          </div>

          <div>
            <label htmlFor="input-lumpsum-label" className="block text-[11px] font-bold text-slate-600 dark:text-slate-400 mb-1">
              {t.lumpNoteLabel}
            </label>
            <div className="flex gap-1.5">
              <input
                id="input-lumpsum-label"
                type="text"
                placeholder={t.lumpPlaceholder}
                value={lumpSumLabel}
                onChange={(e) => setLumpSumLabel(e.target.value)}
                style={{ width: "144.234px" }}
                className="px-3 py-1.5 text-xs sm:text-sm rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-805 dark:text-slate-100"
              />
              <button
                id="btn-add-lumpsum"
                type="submit"
                className="p-1 px-3 bg-indigo-600 hover:bg-slate-900 dark:bg-indigo-600 dark:hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold cursor-pointer flex items-center shrink-0"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>
          </div>
        </form>

        {/* Existing Lump Sums list */}
        {prepayments.lumpSums.length > 0 ? (
          <div className="space-y-2">
            <h4 className="text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              {t.addedMilestonesHeader}
            </h4>
            <div className="max-h-36 overflow-y-auto space-y-1.5 pr-1">
              {prepayments.lumpSums.map((lump, idx) => (
                <div
                  key={`${lump.id || 'lump'}-${idx}`}
                  id={`lumpsum-row-${lump.id}`}
                  className="flex justify-between items-center bg-indigo-50/40 dark:bg-indigo-950/20 text-xs p-2.5 rounded-lg border border-indigo-100/40 dark:border-indigo-900/30"
                >
                  <div className="flex flex-col">
                    <span className="font-semibold text-slate-800 dark:text-slate-200">
                      ₹{lump.amount.toLocaleString("en-IN")}
                    </span>
                    <span className="text-[10px] text-slate-500 dark:text-slate-400 font-mono">
                      {lang === "en" ? "Month" : "महीना"} {lump.atMonth} &bull; {lump.label}
                    </span>
                  </div>
                  <button
                    id={`delete-lumpsum-${lump.id}`}
                    type="button"
                    onClick={() => removeLumpSum(lump.id)}
                    className="p-1 text-slate-400 hover:text-rose-500 transition cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <p className="text-xs text-slate-400 dark:text-slate-500 italic">
            {t.noLumpsumLabel}
          </p>
        )}
      </div>
    </div>
  );
}
