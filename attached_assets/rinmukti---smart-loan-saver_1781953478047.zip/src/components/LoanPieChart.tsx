import { useState } from "react";
import { LoanReport } from "../types";
import { translations } from "../utils/translations";
import { 
  UserCheck, 
  Landmark, 
  Percent, 
  CalendarRange, 
  Scale, 
  AlertTriangle, 
  Coins, 
  ShieldCheck, 
  TrendingUp, 
  Clock, 
  Zap, 
  Award, 
  HeartHandshake
} from "lucide-react";

interface LoanPieChartProps {
  report: LoanReport;
  applicantName: string;
  bankName: string;
  lang: "en" | "hi" | "bilingual";
}

export default function LoanPieChart({ report, applicantName, bankName, lang }: LoanPieChartProps) {
  const t = translations[lang];
  const [activeTab, setActiveTab] = useState<"standard" | "accelerated">("accelerated");
  const [hoveredSlice, setHoveredSlice] = useState<string | null>(null);

  const {
    standardTotalInterest,
    standardTotalPaid,
    acceleratedTotalInterest,
    acceleratedTotalPaid,
    interestSaved,
    tenureSavedMonths
  } = report;

  const principal = report.input.amount;

  // Decide values based on tab
  const showStandard = activeTab === "standard";
  const interestVal = showStandard ? standardTotalInterest : acceleratedTotalInterest;
  const totalVal = showStandard ? standardTotalPaid : acceleratedTotalPaid;

  // Calculate percentage of principal and interest
  const principalPct = totalVal > 0 ? (principal / totalVal) * 100 : 0;
  const interestPct = totalVal > 0 ? (interestVal / totalVal) * 100 : 0;

  // Standard Plan percentages
  const stdInterestPct = standardTotalPaid > 0 ? (standardTotalInterest / standardTotalPaid) * 100 : 0;
  const stdPrincipalPct = standardTotalPaid > 0 ? (principal / standardTotalPaid) * 100 : 0;

  // Prepayment Plan percentages  
  const accInterestPct = acceleratedTotalPaid > 0 ? (acceleratedTotalInterest / acceleratedTotalPaid) * 100 : 0;
  const accPrincipalPct = acceleratedTotalPaid > 0 ? (principal / acceleratedTotalPaid) * 100 : 0;

  // SVG Pie chart calculation helper
  const r = 70;
  const cx = 100;
  const cy = 100;

  const polarToCartesian = (centerX: number, centerY: number, radius: number, angleInDegrees: number) => {
    const angleInRadians = ((angleInDegrees - 90) * Math.PI) / 180.0;
    return {
      x: centerX + radius * Math.cos(angleInRadians),
      y: centerY + radius * Math.sin(angleInRadians)
    };
  };

  const getSlicePath = (startAngle: number, endAngle: number) => {
    const start = polarToCartesian(cx, cy, r, startAngle);
    const end = polarToCartesian(cx, cy, r, endAngle);
    const largeArcFlag = endAngle - startAngle <= 180 ? "0" : "1";
    return `M ${cx} ${cy} L ${start.x} ${start.y} A ${r} ${r} 0 ${largeArcFlag} 1 ${end.x} ${end.y} Z`;
  };

  // Format currency
  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
      maximumFractionDigits: 0
    }).format(val);
  };

  // Prepayment speeds
  const originalMonths = report.input.tenureYears * 12;
  const acceleratedMonths = originalMonths - tenureSavedMonths;
  const speedRatio = acceleratedMonths > 0 ? (originalMonths / acceleratedMonths).toFixed(2) : "1.00";

  // Future potential investment compounding of of saved interest money at 11% CAGR over saved years duration
  const savedYears = tenureSavedMonths / 12;
  const compoundMultiplier = Math.pow(1 + 0.11, savedYears || 1);
  const potentialGrowValue = interestSaved * compoundMultiplier;

  return (
    <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-100 dark:border-slate-800/80 p-6 shadow-sm mt-8">
      
      {/* Title Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-slate-50 dark:border-slate-800/40 pb-5 mb-6">
        <div>
          <h3 className="text-base font-black text-slate-900 dark:text-slate-100 tracking-tight flex items-center space-x-2">
            <Coins className="w-5 h-5 text-emerald-500" />
            <span>
              {lang === "en" 
                ? "Standard Plan vs. New Prepayment Benefit Comparison" 
                : lang === "hi" 
                ? "साधारण बनाम प्री-पेमेंट बचत और अनुपात तुलना" 
                : "Standard vs. Prepayment Plan Comparison"}
            </span>
          </h3>
          <p className="text-xs text-slate-400 dark:text-slate-500 font-medium">
            {lang === "en"
              ? `Dynamic ratio analysis of Loan elements with absolute benefits for: ${applicantName}`
              : `उपयोगकर्ता ${applicantName} के लिए मूलधन-ब्याज अनुपात और बचत का विश्लेषण:`}
          </p>
        </div>

        {/* Plan Switcher */}
        <div className="bg-slate-100 dark:bg-slate-800 p-0.5 rounded-xl border border-slate-200/50 dark:border-slate-700/50 flex">
          <button
            onClick={() => setActiveTab("standard")}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
              activeTab === "standard"
                ? "bg-white dark:bg-slate-700 text-slate-850 dark:text-slate-200 shadow-xs"
                : "text-slate-500 dark:text-slate-400 hover:text-slate-800"
            }`}
          >
            {lang === "en" ? "Standard Plan" : "साधारण योजना (अधिकतम ब्याज)"}
          </button>
          <button
            onClick={() => setActiveTab("accelerated")}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center space-x-1 ${
              activeTab === "accelerated"
                ? "bg-indigo-650 text-white shadow-xs"
                : "text-slate-500 dark:text-slate-400 hover:text-slate-800"
            }`}
          >
            <span>{lang === "en" ? "Prepayment Plan" : "प्री-पेमेंट योजना (अधिक बचत)"}</span>
          </button>
        </div>
      </div>

      {/* 🎈 KID-FRIENDLY VISUAL COMPARISON METAPHOR: OLD VS NEW (बच्चा भी समझे: पुराने और नए का महा-मुकाबला) 🎈 */}
      <div className="mb-8 p-6 bg-gradient-to-br from-amber-50 to-orange-50/50 dark:from-slate-900/60 dark:to-indigo-950/20 rounded-3xl border-2 border-amber-200/60 dark:border-indigo-500/20 shadow-xs relative overflow-hidden">
        
        {/* Playful top banner badge */}
        <div className="absolute top-0 right-0 bg-amber-400 dark:bg-indigo-600 text-slate-950 dark:text-white text-[10px] font-black uppercase tracking-widest px-4 py-1.5 rounded-bl-2xl">
          🎪 {lang === "en" ? "KID-SIMPLE METAPHOR" : "बच्चा भी समझे: सबसे आसान तुलना"}
        </div>

        <div className="mb-4">
          <span className="text-xl">🎒</span>
          <h4 className="text-sm font-black text-amber-900 dark:text-amber-200 uppercase tracking-tight mt-1">
            {lang === "en" ? "How Much Difference Did the Prepayment Method Make?" : "तरीका बदलने का जादू: आसान शब्दों में देखें कितना अंतर आया?"}
          </h4>
          <p className="text-xs text-slate-600 dark:text-slate-400 mt-1 font-semibold">
            {lang === "en" 
              ? "See exactly how much initial money you borrowed versus what you pay in both plans, and the magical saved fortune!" 
              : "नीचे एकदम सरलता से देखें कि आपने कितना उधार लिया था, और दोनों तरीकों में कितना एक्स्ट्रा पैसा बैंक के पास जाने से बच गया!"}
          </p>
        </div>

        {/* 1. Net Principal borrowed bar */}
        <div className="bg-white/80 dark:bg-slate-900/80 p-4 rounded-2xl border border-amber-200/40 dark:border-slate-800/80 mb-6 shadow-2xs">
          <div className="flex justify-between items-center flex-wrap gap-2">
            <div>
              <span className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider block">
                {lang === "en" ? "Original Money Borrowed (Principal / Net Amount)" : "बचपन की शुरुआत: आपने बैंक से उधार लिया था (मूलधन)"}
              </span>
              <span className="text-lg font-black text-indigo-650 dark:text-indigo-400 font-sans">
                {formatCurrency(principal)}
              </span>
            </div>
            <div className="flex items-center space-x-1.5 bg-amber-100/60 dark:bg-slate-800/80 px-3 py-1.5 rounded-xl border border-amber-200/50 dark:border-slate-700/50">
              <span className="text-xs">💼</span>
              <span className="text-[10.5px] font-black text-amber-900 dark:text-amber-300">
                {lang === "en" ? "Starting Debt Sack" : "उधारी की शुरुआती पोटली"}
              </span>
            </div>
          </div>
        </div>

        {/* 2. Comparative Side-by-Side tracks */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-stretch mb-6">
          
          {/* Track A: Old Boring Plan */}
          <div className="bg-rose-50/55 dark:bg-rose-950/10 p-5 rounded-3xl border border-rose-200/80 dark:border-rose-950/40 flex flex-col justify-between relative overflow-hidden transition-all hover:scale-[1.01]">
            <div className="absolute -top-3 -right-3 text-7xl opacity-10 select-none pointer-events-none">🐌</div>
            <div>
              <div className="flex items-center space-x-2 text-rose-650 dark:text-rose-400 mb-3">
                <span className="text-lg">🥵</span>
                <span className="text-xs font-black uppercase tracking-wider">
                  {lang === "en" ? "OLD WAY (No Prepayment)" : "पुराना तरीका (कछुआ चाल - कोई प्री-पेमेंट नहीं)"}
                </span>
              </div>
              <p className="text-[11px] text-slate-600 dark:text-slate-400 leading-relaxed font-semibold mb-4">
                {lang === "en" 
                  ? "Boring and heavy! You pay standard bills for the full tenure. The interest builds a massive mountain of cash for the bank." 
                  : "यह उबाऊ और भारी पड़ता है। आप चुपचाप बैंक की सामान्य किस्तें लंबे समय तक देते रहते हैं, और आपका ब्याज बैंक की तिजोरी भर देता है।"}
              </p>
              
              <div className="space-y-2.5 border-t border-rose-100 dark:border-rose-950/30 pt-3">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-500 font-bold">{lang === "en" ? "Total You Pay to Bank" : "कुल भुगतान (मूलधन + ब्याज)"}:</span>
                  <span className="font-extrabold text-slate-800 dark:text-slate-350 font-mono">{formatCurrency(standardTotalPaid)}</span>
                </div>
                <div className="flex justify-between items-center text-xs text-rose-600 dark:text-rose-400 font-bold">
                  <span>{lang === "en" ? "Extra Interest Paid (Boring Waste)" : "बोरिंग बर्बादी (अतिरिक्त ब्याज ढेला)"}:</span>
                  <span className="font-sans font-black">{formatCurrency(standardTotalInterest)}</span>
                </div>
              </div>
            </div>

            <div className="mt-4 p-2 bg-rose-100/40 dark:bg-rose-950/30 rounded-xl text-center text-[10px] text-rose-700 dark:text-rose-400 font-bold">
              🐢 {lang === "en" ? `Takes full long duration: ${report.input.tenureYears} Years` : `पूरे लंबे समय तक बंधे रहें: ${report.input.tenureYears} वर्ष`}
            </div>
          </div>

          {/* Track B: New Smart Prepayment Plan */}
          <div className="bg-emerald-50/50 dark:bg-emerald-950/10 p-5 rounded-3xl border border-emerald-200/80 dark:border-emerald-950/40 flex flex-col justify-between relative overflow-hidden transition-all hover:scale-[1.01]">
            <div className="absolute -top-3 -right-3 text-7xl opacity-10 select-none pointer-events-none">🚀</div>
            <div>
              <div className="flex items-center space-x-2 text-emerald-650 dark:text-emerald-400 mb-3">
                <span className="text-lg">🦸</span>
                <span className="text-xs font-black uppercase tracking-wider">
                  {lang === "en" ? "NEW WAY (Magic Prepayment)" : "नया जादुई तरीका (सुपर हीरो - प्री-पेमेंट चालू!)"}
                </span>
              </div>
              <p className="text-[11px] text-slate-600 dark:text-slate-400 leading-relaxed font-semibold mb-4">
                {lang === "en" 
                  ? "Flying Rocket! You pay a tiny bit extra cash directly towards your borrowed money, destroying the bank's interest load!" 
                  : "हवा में उड़ने वाला रॉकेट! जैसे ही आप थोड़ा अतिरिक्त पैसा बैंक को देते हैं, वह चक्रवृद्धीय ब्याज की मोटी रस्सी को सीधे काट देता है!"}
              </p>
              
              <div className="space-y-2.5 border-t border-emerald-100 dark:border-emerald-950/30 pt-3">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-500 font-bold">{lang === "en" ? "Reduced Total to Pay" : "नया घटकर कुल भुगतान"}:</span>
                  <span className="font-extrabold text-slate-800 dark:text-slate-350 font-mono">{formatCurrency(acceleratedTotalPaid)}</span>
                </div>
                <div className="flex justify-between items-center text-xs text-emerald-600 dark:text-emerald-400 font-bold font-sans">
                  <span>{lang === "en" ? "Tiny Interest Paid" : "अत्यंत न्यूनतम बचा हुआ ब्याज"}:</span>
                  <span className="font-sans font-black">{formatCurrency(acceleratedTotalInterest)}</span>
                </div>
              </div>
            </div>

            <div className="mt-4 p-2 bg-emerald-100/40 dark:bg-emerald-950/30 rounded-xl text-center text-[10px] text-emerald-700 dark:text-emerald-400 font-bold">
              🚀 {lang === "en" ? `Paid off in just: ${(acceleratedMonths / 12).toFixed(1)} Years` : `तेज़ी से पूरा हुआ: सिर्फ ${(acceleratedMonths / 12).toFixed(1)} वर्ष में!`}
            </div>
          </div>

        </div>

        {/* 3. The Grand Treasure Difference Saved Badge */}
        <div className="bg-gradient-to-r from-amber-400 to-orange-450 dark:from-indigo-900 dark:to-indigo-850 p-5 rounded-3xl text-slate-900 dark:text-white shadow-sm border border-amber-300 dark:border-indigo-700 flex flex-col sm:flex-row justify-between items-center gap-4">
          <div className="flex items-center space-x-3 text-center sm:text-left">
            <span className="text-3xl">🎁</span>
            <div>
              <span className="text-[10px] font-black uppercase tracking-widest text-slate-950 dark:text-amber-200">
                {lang === "en" ? "YOUR MAGIC SAVINGS (Remaining Cash Saved!)" : "आपकी जेब में बची हुई शुद्ध नकद की जादुई तिजोरी!"}
              </span>
              <p className="text-[11px] text-slate-800 dark:text-indigo-200 leading-relaxed font-semibold">
                {lang === "en"
                  ? "This is the massive chunk of cash you did NOT give to the bank! It stays inside your family pocket."
                  : "यह वह विशाल पैसा है जो बैंक के पास जाने से बच गया! अब यह सीधे आपके खुद के घर के सपनों को साकार करने के काम आएगा।"}
              </p>
            </div>
          </div>

          <div className="text-center sm:text-right shrink-0">
            <span className="block text-2xl sm:text-3xl font-black font-sans tracking-tight text-slate-950 dark:text-white drop-shadow-xs">
              {formatCurrency(interestSaved)}
            </span>
            <span className="inline-block text-[10px] font-black uppercase bg-white/40 dark:bg-indigo-950/50 px-2.5 py-0.5 rounded-full mt-1">
              🎉 {lang === "en" ? `${savedYears.toFixed(1)} Years of Life Saved!` : `${savedYears.toFixed(1)} साल पहले ही गुलामी से मुक्ति!`}
            </span>
          </div>
        </div>

        {/* 4. Simple Visual progress bar / race track */}
        <div className="mt-6 bg-white/60 dark:bg-slate-950/30 p-4 rounded-2xl border border-dashed border-amber-200/50 dark:border-slate-800">
          <span className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest block mb-4 text-center">
            🚦 {lang === "en" ? "RACE TRACK TO LAND OF DEBT-FREE FREEDOM" : "ऋण चुकता करने की रेस का महा-मुकाबला (कछुआ बनाम रॉकेट)"}
          </span>
          
          <div className="space-y-4">
            {/* Turtle lane */}
            <div className="space-y-1">
              <div className="flex justify-between items-center text-[10px] font-bold text-slate-500">
                <span>{lang === "en" ? "🐢 Old Slow Way" : "🐢 सुस्त कछुए जैसा पुराना तरीका"}</span>
                <span>{lang === "en" ? "Takes full years" : "पूरा समय लिया"}</span>
              </div>
              <div className="w-full h-8 bg-slate-100 dark:bg-slate-850 rounded-full overflow-hidden relative border border-slate-200/40 dark:border-slate-800">
                <div 
                  className="h-full bg-rose-400 dark:bg-rose-900 text-slate-900 dark:text-white font-black text-[10px] flex items-center justify-end pr-4 rounded-full transition-all duration-1000" 
                  style={{ width: "100%" }}
                >
                  <span>{report.input.tenureYears} Yrs ({originalMonths} Mo)</span>
                </div>
              </div>
            </div>

            {/* Rocket lane */}
            <div className="space-y-1">
              <div className="flex justify-between items-center text-[10px] font-bold text-emerald-600 dark:text-emerald-400">
                <span>{lang === "en" ? "🚀 New Magic Prepayment Way" : "🚀 रॉकेट जैसा नया जादुई सुपर तरीका"}</span>
                <span className="animate-pulse">{lang === "en" ? `RESCUED ${savedYears.toFixed(1)} YEARS! 🎉` : `बचाए गए शानदार ${savedYears.toFixed(1)} साल! 🎉`}</span>
              </div>
              <div className="w-full h-8 bg-slate-100 dark:bg-slate-850 rounded-full overflow-hidden relative border border-slate-200/40 dark:border-slate-800">
                <div 
                  className="h-full bg-gradient-to-r from-emerald-500 to-teal-500 text-white font-black text-[10px] flex items-center justify-end pr-3 rounded-full transition-all duration-1000" 
                  style={{ width: `${Math.max(25, (acceleratedMonths / originalMonths) * 100)}%` }}
                >
                  <span>{(acceleratedMonths / 12).toFixed(1)} Yrs ({acceleratedMonths} Mo)</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* NEW SIDE-BY-SIDE DIFFERENTIAL VALUE COMPARISON PANEL */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch mb-8">
        
        {/* Col 1: Graphic SVGs comparison (OLD vs NEW side-by-side!) */}
        <div className="col-span-12 lg:col-span-7 bg-slate-50/50 dark:bg-slate-900/40 p-6 rounded-3xl border border-dashed border-slate-200 dark:border-slate-850 flex flex-col justify-between">
          <div className="text-center mb-5">
            <span className="text-xs font-extrabold uppercase tracking-widest text-indigo-650 dark:text-indigo-400">
              📊 {lang === "en" ? "Interactive Ratio Comparison (Old vs. New)" : "अंतर स्पष्ट करने वाली पाई चार्ट तुलना (पुराना बनाम नया)"}
            </span>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-8 sm:gap-12 pb-5 border-b border-slate-100 dark:border-slate-800/40">
            
            {/* Pie Chart 1: OLD Plan */}
            <div className="flex flex-col items-center bg-white dark:bg-slate-900/80 p-4 rounded-2xl border border-rose-100 dark:border-rose-950/20 shadow-xs flex-1 max-w-[220px]">
              <span className="text-[11px] font-black uppercase tracking-widest text-rose-600 dark:text-rose-400 mb-3 text-center">
                {lang === "en" ? "Standard Plan (Old)" : "साधारण तरीका (Old)"}
              </span>
              <div className="relative w-32 h-32 hover:scale-105 transition-transform duration-300">
                <svg viewBox="0 0 200 200" className="w-full h-full transform -rotate-12">
                  <g>
                    {/* Principal slice (Emerald green) */}
                    <path
                      d={getSlicePath(0, (stdPrincipalPct / 100) * 360)}
                      fill="url(#emeraldGrad)"
                      className="opacity-100 hover:opacity-90 cursor-pointer transition"
                    />
                    {/* Interest slice (Rose red) */}
                    <path
                      d={getSlicePath((stdPrincipalPct / 100) * 360, 360)}
                      fill="url(#roseGrad)"
                      className="opacity-100 hover:opacity-90 cursor-pointer transition"
                    />
                  </g>
                  {/* Defs inside SVG */}
                  <defs>
                    <linearGradient id="emeraldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#10b981" />
                      <stop offset="100%" stopColor="#059669" />
                    </linearGradient>
                    <linearGradient id="roseGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#f43f5e" />
                      <stop offset="100%" stopColor="#e11d48" />
                    </linearGradient>
                    <linearGradient id="indigoGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#6366f1" />
                      <stop offset="100%" stopColor="#4f46e5" />
                    </linearGradient>
                  </defs>
                </svg>

                <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none text-center">
                  <span className="text-[8px] font-bold text-slate-400 dark:text-slate-500 uppercase">
                    {lang === "en" ? "Principal" : "मूलधन"}
                  </span>
                  <span className="text-sm font-black text-slate-800 dark:text-slate-150">
                    {stdPrincipalPct.toFixed(0)}%
                  </span>
                </div>
              </div>

              {/* Legend with absolute amounts & percentages */}
              <div className="w-full mt-4 space-y-1 text-center border-t border-slate-100 dark:border-slate-800/60 pt-2.5">
                <div className="flex justify-between items-center text-[9px] font-bold text-slate-500">
                  <span className="flex items-center gap-1">
                    <span className="w-1.5 h-1.5 bg-emerald-500 rounded-sm inline-block" />
                    {lang === "en" ? "Principal" : "मूलधन"}
                  </span>
                  <span>{stdPrincipalPct.toFixed(0)}%</span>
                </div>
                <div className="flex justify-between items-center text-[9px] font-bold text-rose-600 dark:text-rose-400">
                  <span className="flex items-center gap-1">
                    <span className="w-1.5 h-1.5 bg-rose-500 rounded-sm inline-block" />
                    {lang === "en" ? "Interest" : "ब्याज"}
                  </span>
                  <span>{stdInterestPct.toFixed(0)}%</span>
                </div>
              </div>
            </div>

            {/* Pie Chart 2: NEW Plan */}
            <div className="flex flex-col items-center bg-white dark:bg-slate-900/80 p-4 rounded-2xl border border-indigo-100 dark:border-indigo-950/20 shadow-xs flex-1 max-w-[220px]">
              <span className="text-[11px] font-black uppercase tracking-widest text-indigo-650 dark:text-indigo-400 mb-3 text-center">
                {lang === "en" ? "Prepayment Plan (New)" : "नया बचत तरीका (New)"}
              </span>
              <div className="relative w-32 h-32 hover:scale-105 transition-transform duration-300">
                <svg viewBox="0 0 200 200" className="w-full h-full transform -rotate-12">
                  <g>
                    {/* Principal slice (Emerald green) */}
                    <path
                      d={getSlicePath(0, (accPrincipalPct / 100) * 360)}
                      fill="url(#emeraldGrad)"
                      className="opacity-100 hover:opacity-90 cursor-pointer transition"
                    />
                    {/* Interest slice (Indigo blue) */}
                    <path
                      d={getSlicePath((accPrincipalPct / 100) * 360, 360)}
                      fill="url(#indigoGrad)"
                      className="opacity-100 hover:opacity-90 cursor-pointer transition"
                    />
                  </g>
                </svg>

                <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none text-center">
                  <span className="text-[8px] font-bold text-slate-400 dark:text-slate-500 uppercase">
                    {lang === "en" ? "Principal" : "मूलधन"}
                  </span>
                  <span className="text-sm font-black text-slate-800 dark:text-slate-150">
                    {accPrincipalPct.toFixed(0)}%
                  </span>
                </div>
              </div>

              {/* Legend with absolute amounts & percentages */}
              <div className="w-full mt-4 space-y-1 text-center border-t border-slate-100 dark:border-slate-800/60 pt-2.5">
                <div className="flex justify-between items-center text-[9px] font-bold text-slate-500">
                  <span className="flex items-center gap-1">
                    <span className="w-1.5 h-1.5 bg-emerald-500 rounded-sm inline-block" />
                    {lang === "en" ? "Principal" : "मूलधन"}
                  </span>
                  <span>{accPrincipalPct.toFixed(0)}%</span>
                </div>
                <div className="flex justify-between items-center text-[9px] font-bold text-indigo-650 dark:text-indigo-400">
                  <span className="flex items-center gap-1">
                    <span className="w-1.5 h-1.5 bg-indigo-505 rounded-sm inline-block" />
                    {lang === "en" ? "Interest" : "ब्याज"}
                  </span>
                  <span>{accInterestPct.toFixed(0)}%</span>
                </div>
              </div>
            </div>

          </div>

          {/* Combined Insight Text below charts */}
          <div className="space-y-3.5 mt-3 pt-1">
            <h4 className="text-xs font-black text-slate-800 dark:text-slate-200 uppercase tracking-tight">
              {lang === "en" ? "Why is there such a massive difference?" : "दोनों के बीच इतना बड़ा अंतर क्यों है?"}
            </h4>
            
            <p className="text-[11px] text-slate-600 dark:text-slate-400 leading-relaxed font-semibold">
              {lang === "en"
                ? "In the Old Plan, you pay a mountain of interest (red slice) because the principal amount outstanding remains high for a long time. In the New Plan, early active prepayments directly erode the principal, causing the bank interest portion (blue slice) to shrink dramatically!"
                : "पुराने प्लान में आप ब्याज (लाल भाग) का एक भारी पहाड़ चुकाते हैं क्योंकि मूलधन काफी लंबे समय तक पूरा बना रहता है। नए प्लान में, समय से पहले किया गया अतिरिक्त भुगतान सीधे आपके मूलधन को काट देता है, जिससे चक्रवृद्धि ब्याज (नीला भाग) अत्यंत कम हो जाता है!"}
            </p>

            <div className="p-3 bg-emerald-500/5 border border-emerald-500/10 rounded-xl flex items-center space-x-2 text-emerald-600 dark:text-emerald-400">
              <Award className="w-4 h-4 shrink-0" />
              <span className="text-[10px] font-black uppercase tracking-wider">
                {lang === "en" ? "Best Selection: Prepayment Plan (Maximum Wealth Protection)" : "सर्वोत्तम चुनना: प्री-पेमेंट तरीका (अधिकतम पूंजी सुरक्षा!)"}
              </span>
            </div>
          </div>

        </div>

        {/* Col 2: Comparative Metric Board */}
        <div className="col-span-12 lg:col-span-5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-4">
          
          {/* Metric 1: Total Interest side by side */}
          <div className="p-4 bg-slate-50 dark:bg-slate-850/40 rounded-2xl border border-slate-100 dark:border-slate-800 flex flex-col justify-between">
            <div>
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-1">
                {lang === "en" ? "Aggregate Bank Interest Cost" : "कुल चुकाया जाने वाला बैंक ब्याज"}
              </span>
              <div className="space-y-1.5 mt-2">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-500 font-bold">{lang === "en" ? "Standard Plan" : "साधारण तरीका"}:</span>
                  <span className="font-extrabold text-slate-700 dark:text-slate-300 font-mono">{formatCurrency(standardTotalInterest)}</span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-indigo-650 dark:text-indigo-400 font-extrabold">{lang === "en" ? "Prepayment" : "प्री-पेमेंट तरीका"}:</span>
                  <span className="font-black text-indigo-650 dark:text-indigo-400 font-mono">{formatCurrency(acceleratedTotalInterest)}</span>
                </div>
              </div>
            </div>
            
            <div className="mt-3 pt-3 border-t border-slate-200/50 dark:border-slate-800 flex items-center space-x-2 text-[11px] text-emerald-600 dark:text-emerald-400 font-black">
              <TrendingUp className="w-3.5 h-3.5" />
              <span>{lang === "en" ? `Save ${formatCurrency(interestSaved)} overall!` : `कुल ₹${(interestSaved).toLocaleString("en-IN")} सीधा नकद बचेगा!`}</span>
            </div>
          </div>

          {/* Metric 2: Payoff Timeline details */}
          <div className="p-4 bg-slate-50 dark:bg-slate-850/40 rounded-2xl border border-slate-100 dark:border-slate-800 flex flex-col justify-between">
            <div>
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-1">
                {lang === "en" ? "Debt-Free Payoff Timeline" : "ऋण चुकता करने की कुल अवधि"}
              </span>
              <div className="space-y-1.5 mt-2">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-500 font-bold">{lang === "en" ? "Standard tenure" : "सामान्य अवधि"}:</span>
                  <span className="font-bold text-slate-700 dark:text-slate-300">{report.input.tenureYears} {lang === "en" ? "Years" : "वर्ष"}</span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-indigo-650 dark:text-indigo-400 font-extrabold">{lang === "en" ? "With Prepayment" : "प्री-पेमेंट से"}:</span>
                  <span className="font-black text-indigo-650 dark:text-indigo-400 font-mono">{(acceleratedMonths / 12).toFixed(1)} {lang === "en" ? "Years" : "वर्ष"}</span>
                </div>
              </div>
            </div>
            
            <div className="mt-3 pt-3 border-t border-slate-200/50 dark:border-slate-800 flex items-center space-x-2 text-[11px] text-indigo-600 dark:text-indigo-450 font-black">
              <Clock className="w-3.5 h-3.5 text-indigo-500" />
              <span>{lang === "en" ? `Complete ${savedYears} Years Sooner!` : `${savedYears} वर्ष पहले ही ऋणमुक्त आज़ाद जीवन!`}</span>
            </div>
          </div>

          {/* Metric 3: Payoff Speed */}
          <div className="p-4 bg-slate-50 dark:bg-slate-850/40 rounded-2xl border border-slate-100 dark:border-slate-800 flex flex-col justify-between">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-1">
                  {lang === "en" ? "Amortization Velocity" : "ऋण चुकाने की रफ़्तार"}
                </span>
                <p className="text-sm font-black text-slate-800 dark:text-slate-100 mt-1 flex items-center gap-1">
                  <Zap className="w-4 h-4 text-amber-500" />
                  <span>{speedRatio}x {lang === "en" ? "Faster Payoff" : "गतिमान पुनर्भुगतान"}</span>
                </p>
              </div>
            </div>
            <p className="text-[10px] text-slate-400 dark:text-slate-500 font-semibold mt-2.5 leading-relaxed">
              {lang === "en"
                ? "Every regular prepayment increases the multiplier and accelerates principal digestion."
                : "नियमित आंशिक प्री-पेमेंट आपके मूलधन पर चक्रवृद्धीय बोझ को अत्यंत तीव्रता से नष्ट करता है।"}
            </p>
          </div>

          {/* Metric 4: Investment Wealth Gain (Financial Hack!) */}
          <div className="p-4 bg-emerald-500/5 dark:bg-emerald-950/20 rounded-2xl border border-emerald-500/10 flex flex-col justify-between">
            <div>
              <span className="text-[10px] font-black text-emerald-600 dark:text-emerald-400 uppercase tracking-widest block mb-1">
                {lang === "en" ? "Compounded Wealth Multiplier" : "बचत का चक्रवृद्धीय जादुई असर"}
              </span>
              <p className="text-sm font-black text-emerald-800 dark:text-emerald-300 mt-1">
                {formatCurrency(potentialGrowValue)}
              </p>
            </div>
            <p className="text-[10px] text-slate-500 dark:text-slate-400 font-semibold mt-2.5 leading-relaxed">
              {lang === "en"
                ? `If the saved interest of ${formatCurrency(interestSaved)} grows in an average index fund at 11% CAGR over those ${savedYears} saved years, it turns into this massive surplus!`
                : `यदि बचाए गए ${formatCurrency(interestSaved)} ब्याज के पैसों को 11% औसत ब्याज पर उसी अवधि तक निवेश करते हैं, तो वह इस विशाल अतिरिक्त फंड में बदल जायेगा!`}
            </p>
          </div>

        </div>

      </div>

      {/* HIGHLIGHT COMPREHENSIVE REPAYMENT BENEFITS CHECKLIST */}
      <div className="pt-6 border-t border-slate-100 dark:border-slate-800/50">
        <h4 className="text-xs font-black text-slate-800 dark:text-slate-200 uppercase tracking-widest mb-4 flex items-center gap-2">
          <HeartHandshake className="w-4 h-4 text-indigo-500" />
          <span>{lang === "en" ? "Core Financial Lifeline Benefits of Prepayment" : "नियमित पुनर्भुगतान व प्री-पेमेंट के मुख्य जीवनदायिनी लाभ"}</span>
        </h4>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 bg-indigo-50/40 dark:bg-indigo-950/20 rounded-2xl border border-indigo-500/5">
            <p className="text-xs font-black text-indigo-900 dark:text-indigo-300 mb-1">
              💰 {lang === "en" ? "Interest Drain Ceased" : "ब्याज के बहते पैसे पर रोक"}
            </p>
            <p className="text-[10.5px] text-slate-500 dark:text-slate-400 leading-relaxed font-semibold">
              {lang === "en" 
                ? "Every extra payment cuts future recurring interest burden down permanently. The saved cash stays inside your pocket."
                : "प्रत्येक एक्स्ट्रा भुगतान भविष्य के ब्याज दायित्व को स्थायी रूप से नष्ट कर देता है। सारा ब्याज का पैसा बैंक की तिजोरी के बजाय आपकी जेब में सुरक्षित बच जाता है।"}
            </p>
          </div>

          <div className="p-4 bg-emerald-50/45 dark:bg-emerald-950/20 rounded-2xl border border-emerald-500/5">
            <p className="text-xs font-black text-emerald-900 dark:text-emerald-300 mb-1">
              ⏳ {lang === "en" ? "Time Compression" : "अनुबंध अवधि में भारी संकुचन"}
            </p>
            <p className="text-[10.5px] text-slate-500 dark:text-slate-400 leading-relaxed font-semibold">
              {lang === "en"
                ? "Instead of paying bank liability for decades, compress your loan life. Become free to pursue retirement or luxury goals earlier."
                : "दशकों तक गुलामी करने के बजाय अपने लोन कार्यकाल को छोटा करें। अपने लक्ष्यों, बच्चों की उच्च शिक्षा और सेवानिवृत्ति के सपनों को बिना कर्ज पूरा करें।"}
            </p>
          </div>

          <div className="p-4 bg-amber-50/45 dark:bg-amber-950/20 rounded-2xl border border-amber-500/5">
            <p className="text-xs font-black text-amber-950 dark:text-amber-300 mb-1">
              🛡️ {lang === "en" ? "Psychological Relief" : "मानसिक शांति और सुरक्षा कवच"}
            </p>
            <p className="text-[10.5px] text-slate-500 dark:text-slate-400 leading-relaxed font-semibold">
              {lang === "en"
                ? "Owning 100% equity in your home or asset gives unbeatable psychological relief, reducing systemic domestic financial risks."
                : "अचल संपत्ति पर बिना किसी बैंक बंधक के 100% पूर्ण मालिकाना हक होने से उच्चतम मानसिक शांति मिलती है, जो जीवन के सभी वित्तीय गृह-जोखिमों को समाप्त कर देती है।"}
            </p>
          </div>
        </div>
      </div>

    </div>
  );
}
