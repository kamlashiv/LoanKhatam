import { useState } from "react";
import { LoanReport } from "../types";
import { PiggyBank, CalendarRange, Scale, AlertCircle, ArrowUpRight, CheckCircle, FileDown, Coins, Zap, ShieldAlert, TrendingUp } from "lucide-react";
import { translations } from "../utils/translations";
import { generateReportPDF } from "../utils/pdfGenerator";

interface LoanSummaryCardsProps {
  report: LoanReport;
  lang: "en" | "hi" | "bilingual";
}

export default function LoanSummaryCards({ report, lang }: LoanSummaryCardsProps) {
  const t = translations[lang];

  const {
    standardMonthlyEMI,
    standardTotalInterest,
    standardTotalPaid,
    standardTenureMonths,
    acceleratedTotalInterest,
    acceleratedTotalPaid,
    acceleratedTenureMonths,
    interestSaved,
    tenureSavedMonths
  } = report;

  const maxYearsAllowed = report.input.tenureYears;
  const [forecastYears, setForecastYears] = useState<number>(Math.max(1, Math.min(5, Math.ceil(maxYearsAllowed / 2))));

  // Dynamic Simulation of stopping prepayments after N years
  const simulateStopPrepayment = (yearsMaintained: number) => {
    const { amount, rate, tenureYears, startDate, topUpAmount = 0, topUpRate, topUpMonth = 0 } = report.input;
    const { monthlyExtra, yearlyExtra, yearlyIncreasePercent, lumpSums } = report.prepayments;

    const monthlyRate = rate / 12 / 100;
    const topUpMonthlyRate = (topUpRate || rate) / 12 / 100;
    const totalMonths = tenureYears * 12;
    const monthsMaintained = yearsMaintained * 12;

    const baseEMI = calculateEMI(amount, rate, tenureYears);
    const remainingMonthsTopUp = Math.max(1, totalMonths - topUpMonth + 1);
    const topUpEMI = topUpAmount > 0 && topUpMonth > 0 
      ? calculateEMI(topUpAmount, topUpRate || rate, remainingMonthsTopUp / 12) 
      : 0;

    let baseRemainingBalance = amount;
    let topUpRemainingBalance = 0;
    let totalInterestSpent = 0;

    let m = 1;
    const maxSafeMonths = totalMonths * 3;
    while (m <= maxSafeMonths) {
      if (topUpAmount > 0 && topUpMonth > 0 && m === topUpMonth) {
        topUpRemainingBalance += topUpAmount;
      }

      const currentTotalBalance = baseRemainingBalance + topUpRemainingBalance;
      if (currentTotalBalance <= 0.01) {
        if (topUpAmount > 0 && topUpMonth > m) {
          // Wait till topup triggers
          m++;
          continue;
        } else {
          break;
        }
      }

      const yearNumber = Math.ceil(m / 12);
      const monthInYear = m % 12 === 0 ? 12 : m % 12;

      let currentRegularBaseEMI = baseEMI;
      if (yearlyIncreasePercent > 0 && yearNumber > 1) {
        currentRegularBaseEMI = baseEMI * Math.pow(1 + yearlyIncreasePercent / 100, yearNumber - 1);
      }

      let currentRegularEMI = currentRegularBaseEMI;
      if (topUpAmount > 0 && topUpMonth > 0 && m >= topUpMonth) {
        currentRegularEMI = currentRegularBaseEMI + topUpEMI;
      }

      const baseInterest = baseRemainingBalance * monthlyRate;
      const topUpInterest = topUpRemainingBalance * topUpMonthlyRate;
      const interest = baseInterest + topUpInterest;

      let extra = 0;
      // Prepayments are only active if month is within the commitment duration
      if (m <= monthsMaintained) {
        if (monthlyExtra > 0) {
          extra += monthlyExtra;
        }
        if (yearlyExtra > 0 && monthInYear === 12) {
          extra += yearlyExtra;
        }
        const applicableLumpSums = lumpSums.filter(l => l.atMonth === m);
        applicableLumpSums.forEach(l => {
          extra += l.amount;
        });
      }

      let regularPrincipal = currentRegularEMI - interest;
      if (regularPrincipal < 0) {
        regularPrincipal = 0;
      }

      let totalPrincipalPaid = regularPrincipal + extra;
      if (totalPrincipalPaid > currentTotalBalance) {
        totalPrincipalPaid = currentTotalBalance;
      }

      let remainingPrincipalToPay = totalPrincipalPaid;
      let paidToTopUp = 0;
      if (topUpRemainingBalance > 0) {
        paidToTopUp = Math.min(remainingPrincipalToPay, topUpRemainingBalance);
        topUpRemainingBalance = Math.max(0, topUpRemainingBalance - paidToTopUp);
        remainingPrincipalToPay -= paidToTopUp;
      }
      let paidToBase = 0;
      if (baseRemainingBalance > 0) {
        paidToBase = Math.min(remainingPrincipalToPay, baseRemainingBalance);
        baseRemainingBalance = Math.max(0, baseRemainingBalance - paidToBase);
        remainingPrincipalToPay -= paidToBase;
      }

      totalInterestSpent += interest;
      m++;
    }

    const finishedMonth = m - 1;
    const interestSavedVal = Math.max(0, standardTotalInterest - totalInterestSpent);
    
    // Resolve date label
    const dateLabel = report.standardSchedule[Math.min(finishedMonth, report.standardSchedule.length - 1)]?.dateLabel || "-";

    return {
      interestSaved: interestSavedVal,
      monthsToClose: finishedMonth,
      dateLabel,
    };
  };

  function calculateEMI(principal: number, annualRate: number, tenureYears: number): number {
    const r = annualRate / 12 / 100;
    const n = tenureYears * 12;
    if (r === 0) return principal / n;
    return (principal * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
  }

  // Format tenure saved in Years & Months
  const yearsSaved = Math.floor(tenureSavedMonths / 12);
  const remainingMonthsSaved = tenureSavedMonths % 12;

  let savedTimeLabel = "";
  if (yearsSaved > 0 && remainingMonthsSaved > 0) {
    savedTimeLabel = lang === "en"
      ? `${yearsSaved} Yr(s), ${remainingMonthsSaved} Mo(s)`
      : lang === "hi"
      ? `${yearsSaved} साल, ${remainingMonthsSaved} महीने`
      : `${yearsSaved} साल (Years), ${remainingMonthsSaved} महीने`;
  } else if (yearsSaved > 0) {
    savedTimeLabel = lang === "en"
      ? `${yearsSaved} Yr(s)`
      : `${yearsSaved} साल (Years)`;
  } else if (remainingMonthsSaved > 0) {
    savedTimeLabel = lang === "en"
      ? `${remainingMonthsSaved} Mo(s)`
      : `${remainingMonthsSaved} महीने (Months)`;
  } else {
    savedTimeLabel = lang === "en" ? "0 Months" : "0 महीने";
  }

  // Calculate percentage savings
  const interestSavingPct = standardTotalInterest > 0 
    ? (interestSaved / standardTotalInterest) * 100 
    : 0;

  const timeSavingPct = standardTenureMonths > 0
    ? (tenureSavedMonths / standardTenureMonths) * 100
    : 0;

  // Expected end dates
  const regularEndDate = report.standardSchedule.length > 0 
    ? report.standardSchedule[report.standardSchedule.length - 1].dateLabel 
    : "-";

  const acceleratedEndDate = report.schedule.length > 0
    ? report.schedule[report.schedule.length - 1].dateLabel
    : "-";

  const handleDownloadPDF = () => {
    generateReportPDF(report, lang);
  };

  return (
    <div className="space-y-4">
      {/* 📥 TOP ACTION ROW: PDF DOWNLOAD AT THE CORNER */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center p-4 bg-indigo-50/50 dark:bg-indigo-950/10 border border-indigo-100/30 dark:border-indigo-900/30 rounded-2xl gap-3">
        <div className="flex items-center space-x-2">
          <div className="p-1.5 bg-indigo-600 rounded-lg text-white">
            <FileDown className="w-4 h-4" />
          </div>
          <div>
            <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
              {lang === "en" ? "Print-Ready Client PDF Report" : lang === "hi" ? "प्रिंट-फ्रेंडली पीडीएफ रिपोर्ट" : "प्रिंट-फ्रेंडली रिपोर्ट (Print PDF Summary)"}
            </span>
            <p className="text-[10px] text-slate-500 dark:text-slate-400">
              {lang === "en" ? "Includes payoff roadmap and comparative graphs" : "सभी ब्याज बचत एवं समय सीमा की विस्तृत जानकारी के साथ"}
            </p>
          </div>
        </div>

        <button
          id="download-summary-pdf-btn"
          onClick={handleDownloadPDF}
          className="w-full sm:w-auto px-5 py-2.5 bg-indigo-600 hover:bg-slate-900 dark:bg-indigo-600 dark:hover:bg-indigo-500 text-white text-xs font-bold rounded-xl transition duration-200 shadow-sm cursor-pointer flex items-center justify-center space-x-2 shrink-0 active:scale-95"
        >
          <FileDown className="w-4 h-4" />
          <span>{lang === "en" ? "Download PDF Summary" : lang === "hi" ? "पीडीएफ सारांश डाउनलोड करें" : "पीडीएफ सारांश डाउनलोड (Download PDF)"}</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
        {/* 💰 CARD 1: TOTAL INTEREST SAVED (कुल ब्याज बचत) */}
        <div 
          id="summary-card-interest-saved" 
          className="relative overflow-hidden bg-gradient-to-br from-emerald-500 to-teal-600 dark:from-emerald-600 dark:to-teal-700 rounded-2xl p-6 text-white shadow-md transition duration-250 hover:shadow-lg"
        >
          <div className="absolute right-0 top-0 translate-x-4 -translate-y-4 opacity-10">
            <PiggyBank className="w-36 h-36 text-white" />
          </div>
          <div className="flex items-center space-x-2 bg-white/10 w-fit px-3 py-1 rounded-full text-xs font-semibold mb-4 backdrop-blur-sm">
            <PiggyBank className="w-4 h-4 text-emerald-100" />
            <span>{t.interestSavedTitle}</span>
          </div>
          <p className="text-sm text-emerald-100 font-medium">{t.pureNetSavingsLabel}</p>
          <h3 className="text-3xl sm:text-4xl font-extrabold tracking-tight mt-1 mb-1 font-sans">
            ₹{Math.round(interestSaved).toLocaleString("en-IN")}
          </h3>
          {interestSaved > 0 ? (
            <p className="text-xs text-emerald-50 font-medium flex items-center">
              <ArrowUpRight className="w-4 h-4 mr-1 shrink-0" />
              {t.heavyInterestSavingsNote} {interestSavingPct.toFixed(1)}%!
            </p>
          ) : (
            <p className="text-xs text-emerald-100 opacity-90">
              {t.prepaymentHelpNote}
            </p>
          )}

          <div className="mt-5 pt-4 border-t border-white/20 grid grid-cols-2 gap-2 text-xs">
            <div>
              <span className="block opacity-75">{t.standardCostLabel}</span>
              <span className="font-semibold text-[13px]">₹{Math.round(standardTotalInterest).toLocaleString("en-IN")}</span>
            </div>
            <div>
              <span className="block opacity-75">{t.newCostLabel}</span>
              <span className="font-semibold text-[13px]">₹{Math.round(acceleratedTotalInterest).toLocaleString("en-IN")}</span>
            </div>
          </div>
        </div>

        {/* ⏱️ CARD 2: TENURE SAVED (समय की बचत / कर्जमुक्ति) */}
        <div 
          id="summary-card-time-saved" 
          className="relative overflow-hidden bg-gradient-to-br from-indigo-500 to-blue-600 dark:from-indigo-600 dark:to-blue-700 rounded-2xl p-6 text-white shadow-md transition duration-250 hover:shadow-lg"
        >
          <div className="absolute right-0 top-0 translate-x-4 -translate-y-4 opacity-10">
            <CalendarRange className="w-36 h-36 text-white" />
          </div>
          <div className="flex items-center space-x-2 bg-white/10 w-fit px-3 py-1 rounded-full text-xs font-semibold mb-4 backdrop-blur-sm">
            <CalendarRange className="w-4 h-4 text-indigo-100" />
            <span>{t.tenureSavedTitle}</span>
          </div>
          <p className="text-sm text-indigo-100 font-medium">{t.debtFreeLabel}</p>
          <h3 className="text-2xl sm:text-3xl font-extrabold tracking-tight mt-1 mb-1 font-sans leading-snug">
            {tenureSavedMonths > 0 ? savedTimeLabel : lang === "en" ? "0 Months" : "0 महीने"}
          </h3>
          {tenureSavedMonths > 0 ? (
            <p className="text-xs text-indigo-50 font-medium flex items-center">
              <CheckCircle className="w-4 h-4 mr-1 shrink-0" />
              {t.timeSavingPctNote} {timeSavingPct.toFixed(1)}%!
            </p>
          ) : (
            <p className="text-xs text-indigo-100 opacity-90">
              {lang === "en" ? "Repaying on time as scheduled" : "तय समय पर सामान्य भुगतान"}
            </p>
          )}

          <div className="mt-5 pt-4 border-t border-white/20 grid grid-cols-2 gap-2 text-xs">
            <div>
              <span className="block opacity-75">{t.regularEndDateLabel}</span>
              <span className="font-semibold text-[13px]">{regularEndDate}</span>
            </div>
            <div>
              <span className="block opacity-75">{t.newEndDateLabel}</span>
              <span className="font-semibold text-[13px] text-emerald-250 font-bold">{acceleratedEndDate}</span>
            </div>
          </div>
        </div>

        {/* 🪙 CARD 3: NET PRINCIPAL VALUE (कुल मूलधन राशि) (NEW) */}
        <div 
          id="summary-card-net-principal" 
          className="relative overflow-hidden bg-gradient-to-br from-rose-500 to-amber-600 dark:from-rose-600 dark:to-amber-700 rounded-2xl p-6 text-white shadow-md transition duration-250 hover:shadow-lg"
        >
          <div className="absolute right-0 top-0 translate-x-4 -translate-y-4 opacity-10">
            <Coins className="w-36 h-36 text-white" />
          </div>
          <div className="flex items-center space-x-2 bg-white/10 w-fit px-3 py-1 rounded-full text-xs font-semibold mb-4 backdrop-blur-sm">
            <Coins className="w-4 h-4 text-rose-100" />
            <span>{lang === "en" ? "Net Principal (Total)" : lang === "hi" ? "कुल मूलधन राशि" : "Net Principal Value (कुल मूलधन)"}</span>
          </div>
          <p className="text-sm text-rose-100 font-medium">
            {lang === "en" ? "Total actual loan amount borrowed" : "बैंक से लिया कुल मूलधन कर्ज"}
          </p>
          <h3 className="text-2xl sm:text-3xl font-extrabold tracking-tight mt-1 mb-1 font-sans">
            ₹{Math.round(report.input.amount + (report.input.topUpAmount || 0)).toLocaleString("en-IN")}
          </h3>
          
          <div className="mt-5 pt-4 border-t border-white/20 space-y-1 text-xs">
            <div className="flex justify-between">
              <span className="opacity-75">{lang === "en" ? "Base Principal" : "मुख्य लोन (Base)"}</span>
              <span className="font-semibold text-[13px]">₹{Math.round(report.input.amount).toLocaleString("en-IN")}</span>
            </div>
            {report.input.topUpAmount && report.input.topUpAmount > 0 ? (
              <div className="flex justify-between text-amber-200 font-bold">
                <span className="opacity-90">{lang === "en" ? "Top-Up Loan" : "टॉप-अप लोन राशि"}</span>
                <span className="text-[13px]">+ ₹{Math.round(report.input.topUpAmount).toLocaleString("en-IN")}</span>
              </div>
            ) : (
              <div className="flex justify-between text-rose-200">
                <span className="opacity-75">{lang === "en" ? "Top-Up Loan" : "टॉप-अप लोन विकल्प"}</span>
                <span className="italic text-[11px] opacity-85">{lang === "en" ? "No Active Top-up" : "सक्रिय नहीं है"}</span>
              </div>
            )}
          </div>
        </div>

        {/* 📊 CARD 4: COMPARATIVE ANALYSIS SUMMARY */}
        <div 
          id="summary-card-comparison" 
          className="bg-white dark:bg-slate-900 rounded-2xl p-6 shadow-sm border border-slate-100 dark:border-slate-800 flex flex-col justify-between transition duration-250 hover:shadow-md"
        >
          <div>
            <div className="flex items-center space-x-2 bg-slate-50 dark:bg-slate-800 w-fit px-3 py-1 rounded-full text-xs font-semibold text-slate-600 dark:text-slate-355 mb-4 border border-slate-100 dark:border-slate-700/60">
              <Scale className="w-4 h-4 text-indigo-500" />
              <span>{t.emiDetailsTitle}</span>
            </div>
            
            <div className="space-y-3">
              <div className="flex justify-between items-center text-xs sm:text-sm">
                <span className="text-slate-500 dark:text-slate-400">{t.regularEMIItem}</span>
                <span className="font-bold text-slate-800 dark:text-slate-100 text-[15px]">
                  ₹{Math.round(standardMonthlyEMI).toLocaleString("en-IN")}
                </span>
              </div>

              {report.prepayments.monthlyExtra > 0 && (
                <div className="flex justify-between items-center text-xs sm:text-sm">
                  <span className="text-slate-500 dark:text-slate-400">{t.monthlyExtraItem}</span>
                  <span className="font-bold text-emerald-600 dark:text-emerald-400 text-[14px]">
                    + ₹{report.prepayments.monthlyExtra.toLocaleString("en-IN")}
                  </span>
                </div>
              )}

              {report.prepayments.yearlyIncreasePercent > 0 && (
                <div className="flex justify-between items-center text-xs sm:text-sm">
                  <span className="text-slate-500 dark:text-slate-400">{t.yearlyTopupItem}</span>
                  <span className="font-bold text-cyan-600 dark:text-cyan-400 text-[14px]">
                    + {report.prepayments.yearlyIncreasePercent}%
                  </span>
                </div>
              )}

              <div className="border-t border-slate-100 dark:border-slate-800/60 pt-3 flex justify-between items-center text-xs sm:text-sm">
                <span className="text-slate-500 dark:text-slate-400">{t.totalPaidStandardItem}</span>
                <span className="font-semibold text-slate-700 dark:text-slate-300">
                  ₹{Math.round(standardTotalPaid).toLocaleString("en-IN")}
                </span>
              </div>

              <div className="flex justify-between items-center text-xs sm:text-sm">
                <span className="text-slate-500 dark:text-slate-400">{t.totalPaidSavingsItem}</span>
                <span className="font-bold text-emerald-600 dark:text-emerald-400">
                  ₹{Math.round(acceleratedTotalPaid).toLocaleString("en-IN")}
                </span>
              </div>
            </div>
          </div>

          {interestSaved > 0 && (
            <div className="mt-4 relative inline-block group/tooltip">
              <div className="inline-flex items-center gap-1.5 bg-emerald-50/60 dark:bg-emerald-950/20 px-3 py-1.5 rounded-lg border border-emerald-100/45 dark:border-emerald-900/30 text-[10px] font-bold cursor-help select-none transition hover:bg-emerald-100/50 dark:hover:bg-emerald-950/45">
                <AlertCircle className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 shrink-0" />
                <span className="text-[9px] font-black uppercase text-emerald-700 dark:text-emerald-300">
                  {lang === "en" ? "Bonus Insight" : lang === "hi" ? "अतिरिक्त लाभ" : "Bonus Insight / लाभ"}
                </span>
                <span className="text-emerald-500 font-bold">&#9662;</span>
              </div>
              {/* STYLISH ABSOLUTE FLOATING TOOLTIP */}
              <div className="absolute bottom-full left-0 mb-2 w-72 p-3 bg-emerald-950 text-emerald-100 dark:bg-emerald-50 dark:text-emerald-900 rounded-xl shadow-2xl border border-emerald-900/35 dark:border-emerald-150 text-[10.5px] leading-relaxed font-semibold transition-all duration-200 origin-bottom opacity-0 pointer-events-none scale-95 translate-y-1 group-hover/tooltip:opacity-100 group-hover/tooltip:pointer-events-auto group-hover/tooltip:scale-100 group-hover/tooltip:translate-y-0 z-50">
                <div className="font-extrabold text-[8.5px] uppercase text-emerald-300 dark:text-emerald-700 mb-1 tracking-wider">
                  {lang === "en" ? "Wealth Integration Fact" : "बचत का उपयोग विचार"}
                </div>
                <p>{t.motivationalCarNote}</p>
                <div className="absolute top-full left-5 -mt-1 border-4 border-transparent border-t-emerald-950 dark:border-t-emerald-50" />
              </div>
            </div>
          )}
        </div>
      </div>

      {/* 🔮 INTERACTIVE PREPAYMENT COMMITMENT FORECASTING BOX */}
      {report.prepayments.monthlyExtra > 0 || report.prepayments.yearlyExtra > 0 || (report.prepayments.lumpSums && report.prepayments.lumpSums.length > 0) ? (
        (() => {
          const simulatedData = simulateStopPrepayment(forecastYears);
          return (
            <div 
              id="prepayment-forecast-card"
              className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl p-6 mt-6 relative overflow-hidden transition-all duration-200 shadow-sm"
            >
              <div className="absolute right-0 top-0 translate-x-12 -translate-y-12 opacity-[0.03] pointer-events-none">
                <Zap className="w-56 h-56 text-indigo-505" />
              </div>

              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-slate-100 dark:border-slate-800/80 pb-4 mb-6">
                <div className="space-y-1">
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-indigo-50 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-400 border border-indigo-100/60 dark:border-indigo-900/30">
                    <Zap className="w-3 h-3 text-amber-500 shrink-0" />
                    {lang === "en" ? "Interactive Scenario Modeler" : "इंटरएक्टिव बचत अनुमानक"}
                  </span>
                  <h4 className="text-base font-black text-slate-800 dark:text-white leading-tight">
                    {lang === "en" ? "Prepayment Commitment & Interest Saved Forecast" : "प्रीपेमेंट प्रतिबद्धता एवं ब्याज बचत का अनुमान"}
                  </h4>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    {lang === "en"
                      ? "Compare maintaining your current behavior versus stopping early to see how much of your savings stay locked-in."
                      : "तुलना करें: यदि आप आज अतिरिक्त भुगतान रोक देते हैं बनाम यदि आप इसे कुछ वर्षों तक जारी रखते हैं।"}
                  </p>
                </div>
              </div>

              {/* Dynamic State Slider */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
                <div className="lg:col-span-5 space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                        {lang === "en" ? "Years of prepayment commitment:" : "आप कब तक प्रीपेमेंट जारी रखेंगे?"}
                      </label>
                      <span className="text-xs font-black text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-1050/30 px-2.5 py-1 rounded-lg">
                        {forecastYears === 0 
                          ? (lang === "en" ? "Stop Today (0 Yrs)" : "आज ही रोकें (0 वर्ष)")
                          : forecastYears === maxYearsAllowed 
                          ? (lang === "en" ? `To the End (${forecastYears} Yrs)` : `अंत तक (${forecastYears} वर्ष)`)
                          : (lang === "en" ? `${forecastYears} Yr(s)` : `${forecastYears} वर्ष`)}
                      </span>
                    </div>
                    
                    <input
                      id="prepayment-commitment-slider"
                      type="range"
                      min="0"
                      max={maxYearsAllowed}
                      step="1"
                      value={forecastYears}
                      onChange={(e) => setForecastYears(Number(e.target.value))}
                      className="w-full h-2 bg-slate-200 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-600"
                    />
                    
                    <div className="flex justify-between text-[9px] text-slate-400 dark:text-slate-505 font-bold px-1 uppercase tracking-wider">
                      <span>{lang === "en" ? "Stopped Today" : "आज ही रोकें"}</span>
                      <span>{lang === "en" ? `${Math.round(maxYearsAllowed / 2)} Yrs` : `${Math.round(maxYearsAllowed / 2)} वर्ष`}</span>
                      <span>{lang === "en" ? "Maintain forever" : "हमेशा जारी रखें"}</span>
                    </div>
                  </div>

                  <div className="p-3.5 bg-slate-50 dark:bg-slate-850/40 rounded-xl border border-slate-100 dark:border-slate-800 text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                    {forecastYears === 0 ? (
                      <p className="text-rose-600 dark:text-rose-400 font-extrabold flex items-start gap-1.5">
                        <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                        <span>
                          {lang === "en"
                            ? "Stopping prepayments completely today means you forfeit the entire savings pool. You return to standard bank contract parameters immediately."
                            : "आज ही अतिरिक्त भुगतान रोकने का अर्थ है कि आप अपनी सभी बची हुई ब्याज बचत खो देंगे। आप तुरंत बैंक के सामान्य नियम पर आ जाएंगे।"}
                        </span>
                      </p>
                    ) : forecastYears === maxYearsAllowed ? (
                      <p className="text-emerald-600 dark:text-emerald-400 font-extrabold flex items-start gap-1.5">
                        <CheckCircle className="w-4 h-4 shrink-0 mt-0.5 text-emerald-550" />
                        <span>
                          {lang === "en"
                            ? "Outstanding strategy! Fully maintaining this behavior unlocks your absolute maximum interest savings & cuts years off your debt timeline."
                            : "शानदार योजना! इस रणनीति को पूर्ण रूप से बनाए रखने से आपको अधिकतम ब्याज बचत मिलती है और ऋण मुक्ति बहुत पहले मिल जाएगी।"}
                        </span>
                      </p>
                    ) : (
                      <p className="flex items-start gap-1.5 text-indigo-700 dark:text-indigo-400 font-semibold">
                        <TrendingUp className="w-4 h-4 shrink-0 text-indigo-500 mt-0.5" />
                        <span>
                          {lang === "en"
                            ? `Commitment ROI: Extra repayments for just ${forecastYears} year(s) secures ₹${Math.round(simulatedData.interestSaved).toLocaleString("en-IN")} in cumulative interest saved before reverting.`
                            : `बचत का परिदृश्य: केवल ${forecastYears} वर्ष तक अत्यधिक भुगतान करने पर भी आप ₹${Math.round(simulatedData.interestSaved).toLocaleString("en-IN")} की संचित बचत सुरक्षित कर लेंगे।`}
                        </span>
                      </p>
                    )}
                  </div>
                </div>

                {/* Comparative Blocks Grid */}
                <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-3 gap-4">
                  
                  {/* OPTION 1: STOP TODAY */}
                  <div className="p-4 rounded-xl border border-rose-100 dark:border-rose-950/20 bg-rose-50/10 dark:bg-rose-950/5 flex flex-col justify-between">
                    <div>
                      <span className="text-[9px] font-black uppercase text-rose-500 block tracking-wider mb-1">
                        {lang === "en" ? "If Stopped Today" : "यदि आज बंद करें"}
                      </span>
                      <strong className="text-lg font-black text-slate-850 dark:text-slate-100 block">
                        ₹0
                      </strong>
                      <p className="text-[10px] text-slate-400 dark:text-slate-500 mt-1">
                        {lang === "en" ? "No extra interest saved." : "कोई अतिरिक्त ब्याज नहीं बचेगा।"}
                      </p>
                    </div>
                    <div className="border-t border-slate-100 dark:border-rose-950/20 pt-2.5 mt-3 text-[10px] text-slate-500">
                      <span>{lang === "en" ? "Payoff Date:" : "चुकाने की तिथि:"}</span>
                      <span className="block font-bold mt-0.5 text-rose-500">{regularEndDate}</span>
                    </div>
                  </div>

                  {/* OPTION 2: DYNAMIC PREPAY COMMITMENT */}
                  <div className="p-4 rounded-xl border border-indigo-200 dark:border-indigo-850/60 bg-indigo-500/[0.02] dark:bg-indigo-950/20 flex flex-col justify-between shadow-xs">
                    <div>
                      <span className="text-[9px] font-black uppercase text-indigo-600 dark:text-indigo-400 block tracking-wider mb-1">
                        {lang === "en" ? `Commitment Goal` : `आपका लघु बचत लक्ष्य`}
                      </span>
                      <strong className="text-lg font-black text-indigo-600 dark:text-indigo-400 block transition-all font-sans">
                        ₹{Math.round(simulatedData.interestSaved).toLocaleString("en-IN")}
                      </strong>
                      <p className="text-[10px] text-indigo-550 dark:text-indigo-450 font-bold mt-1">
                        {lang === "en" ? `Prepaying for ${forecastYears} Yrs` : `${forecastYears} वर्ष भरने पर बचत`}
                      </p>
                    </div>
                    <div className="border-t border-slate-100 dark:border-indigo-950/20 pt-2.5 mt-3 text-[10px] text-slate-500">
                      <span>{lang === "en" ? "New Payoff Date:" : "चुकाने की तिथि:"}</span>
                      <span className="block font-bold mt-0.5 text-indigo-600 dark:text-indigo-400">
                        {simulatedData.dateLabel}
                      </span>
                    </div>
                  </div>

                  {/* OPTION 3: FULLY MAINTAINED */}
                  <div className="p-4 rounded-xl border border-emerald-100 dark:border-emerald-950 bg-emerald-50/10 dark:bg-emerald-950/5 flex flex-col justify-between">
                    <div>
                      <span className="text-[9px] font-black uppercase text-emerald-600 dark:text-emerald-400 block tracking-wider mb-1">
                        {lang === "en" ? "Maintain to End" : "पूर्ण भुगतान योजना"}
                      </span>
                      <strong className="text-lg font-black text-emerald-500 block font-sans">
                        ₹{Math.round(interestSaved).toLocaleString("en-IN")}
                      </strong>
                      <p className="text-[10px] text-emerald-600 dark:text-emerald-500 font-bold mt-1">
                        {lang === "en" ? "Absolute Max Savings" : "अधिकतम संभावित शुद्ध बचत"}
                      </p>
                    </div>
                    <div className="border-t border-slate-100 dark:border-emerald-900/30 pt-2.5 mt-3 text-[10px] text-slate-500">
                      <span>{lang === "en" ? "Fastest Payoff:" : "शीघ्रतम चुकाने की तिथि:"}</span>
                      <span className="block font-extrabold mt-0.5 text-emerald-500">{acceleratedEndDate}</span>
                    </div>
                  </div>

                </div>
              </div>
            </div>
          );
        })()
      ) : null}
    </div>
  );
}
