import { useState } from "react";
import { LoanReport } from "../types";
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from "recharts";
import { BarChart3, TrendingDown, Info } from "lucide-react";
import { translations } from "../utils/translations";

interface SavingsChartsProps {
  report: LoanReport;
  lang: "en" | "hi" | "bilingual";
}

export default function SavingsCharts({ report, lang }: SavingsChartsProps) {
  const [activeTab, setActiveTab] = useState<"balance" | "costs">("balance");
  const t = translations[lang];

  const { schedule, standardSchedule } = report;

  // Aggregate schedule data year-by-year for cleaner visualization
  const maxYears = Math.max(
    standardSchedule.length > 0 ? Math.ceil(standardSchedule.length / 12) : 0,
    schedule.length > 0 ? Math.ceil(schedule.length / 12) : 0
  );

  const chartDataYearly = [];

  const stdKey = lang === "en" 
    ? "Standard Balance" 
    : lang === "hi" 
    ? "सामान्य ऋण बकाया" 
    : "Standard Balance (साधारण कर्ज)";

  const accKey = lang === "en"
    ? "Accelerated Balance"
    : lang === "hi"
    ? "त्वरित योजना बकाया"
    : "Accelerated Balance (बचत योजना)";

  for (let yr = 0; yr <= maxYears; yr++) {
    // Standard loan balance at end of this year (or month 0)
    let standardBalance = report.input.amount;
    if (yr > 0) {
      const idx = Math.min(yr * 12 - 1, standardSchedule.length - 1);
      standardBalance = standardSchedule[idx] ? standardSchedule[idx].closingBalance : 0;
    }

    // Accelerated loan balance at end of this year
    let acceleratedBalance = report.input.amount;
    if (yr > 0) {
      const idx = Math.min(yr * 12 - 1, schedule.length - 1);
      acceleratedBalance = schedule[idx] ? schedule[idx].closingBalance : 0;
    }

    chartDataYearly.push({
      year: yr === 0 ? (lang === "en" ? "Start" : "प्रारंभ") : `${lang === "en" ? "Year" : "वर्ष"} ${yr}`,
      [stdKey]: Math.round(standardBalance),
      [accKey]: Math.round(acceleratedBalance),
    });

    // If both reached 0, stop adding further years
    if (standardBalance === 0 && acceleratedBalance === 0) {
      break;
    }
  }

  const pKey = lang === "en" ? "Principal Loan Capital" : lang === "hi" ? "वास्तविक मूलधन" : "Principal (मूलधन)";
  const iKey = lang === "en" ? "Total Interest Cost" : lang === "hi" ? "कुल चक्रवृद्धि ब्याज" : "Interest (कुल ब्याज)";

  const path1 = lang === "en" ? "Standard Path" : lang === "hi" ? "साधारण भुगतान" : "Standard Path (बिना एक्स्ट्रा)";
  const path2 = lang === "en" ? "Savings Plan" : lang === "hi" ? "त्वरित बचत प्लान" : "Savings Plan (बचत के साथ)";

  // Costs comparison data
  const costComparisonData = [
    {
      name: path1,
      [pKey]: Math.round(report.input.amount),
      [iKey]: Math.round(report.standardTotalInterest),
    },
    {
      name: path2,
      [pKey]: Math.round(report.input.amount),
      [iKey]: Math.round(report.acceleratedTotalInterest),
    },
  ];

  // Formatting helpers
  const formatCurrency = (val: number) => {
    if (val >= 10000000) return `₹${(val / 10000000).toFixed(2)} Cr`;
    if (val >= 100000) return `₹${(val / 100000).toFixed(1)} L`;
    return `₹${val.toLocaleString("en-IN")}`;
  };

  const CustomTooltipContent = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-slate-900 border border-slate-800 text-white p-3 rounded-lg shadow-md text-xs font-sans">
          <p className="font-semibold mb-1 text-slate-300">{label}</p>
          {payload.map((entry: any, i: number) => (
            <p key={i} className="flex justify-between gap-4 py-0.5" style={{ color: entry.color }}>
              <span>{entry.name}:</span>
              <span className="font-black">₹{entry.value.toLocaleString("en-IN")}</span>
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-100 dark:border-slate-800 transition-all">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6 border-b border-slate-100 dark:border-slate-800 pb-4">
        <div>
          <h3 className="font-bold text-slate-800 dark:text-slate-150 text-base">
            {t.chartsTitle}
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            {t.chartsSubtitle}
          </p>
        </div>

        {/* Tab buttons */}
        <div className="flex bg-slate-100 dark:bg-slate-800/80 p-1 rounded-xl w-full sm:w-auto border border-slate-200/40 dark:border-slate-700/40">
          <button
            id="tab-btn-balance"
            onClick={() => setActiveTab("balance")}
            className={`flex items-center justify-center space-x-1.5 flex-1 sm:flex-initial px-4 py-1.5 rounded-lg text-xs font-semibold transition duration-150 cursor-pointer ${
              activeTab === "balance"
                ? "bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-300 shadow-sm"
                : "text-slate-600 dark:text-slate-400 hover:text-slate-900"
            }`}
          >
            <TrendingDown className="w-3.5 h-3.5" />
            <span>{t.tabBalanceTrend}</span>
          </button>
          <button
            id="tab-btn-costs"
            onClick={() => setActiveTab("costs")}
            className={`flex items-center justify-center space-x-1.5 flex-1 sm:flex-initial px-4 py-1.5 rounded-lg text-xs font-semibold transition duration-150 cursor-pointer ${
              activeTab === "costs"
                ? "bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-300 shadow-sm"
                : "text-slate-600 dark:text-slate-400 hover:text-slate-900"
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5" />
            <span>{t.tabCostSave}</span>
          </button>
        </div>
      </div>

      <div className="h-72 w-full">
        {activeTab === "balance" ? (
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartDataYearly} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="colorStandard" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#ef4444" stopOpacity={0.1}/>
                  <stop offset="95%" stopColor="#ef4444" stopOpacity={0.0}/>
                </linearGradient>
                <linearGradient id="colorAccelerated" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.25}/>
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0.0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" className="stroke-slate-100 dark:stroke-slate-800/60" />
              <XAxis 
                dataKey="year" 
                tick={{ fill: "#64748b", fontSize: 10 }}
                tickLine={{ stroke: "#e2e8f0" }}
              />
              <YAxis 
                tick={{ fill: "#64748b", fontSize: 10 }}
                tickFormatter={formatCurrency}
                tickLine={{ stroke: "#e2e8f0" }}
              />
              <Tooltip content={<CustomTooltipContent />} />
              <Legend verticalAlign="top" height={36} wrapperStyle={{ fontSize: "11px" }} />
              <Area
                name={stdKey}
                type="monotone"
                dataKey={stdKey}
                stroke="#f43f5e"
                strokeWidth={2}
                fillOpacity={1}
                fill="url(#colorStandard)"
              />
              <Area
                name={accKey}
                type="monotone"
                dataKey={accKey}
                stroke="#10b981"
                strokeWidth={2.5}
                fillOpacity={1}
                fill="url(#colorAccelerated)"
              />
            </AreaChart>
          </ResponsiveContainer>
        ) : (
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={costComparisonData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" className="stroke-slate-100 dark:stroke-slate-800/60" />
              <XAxis 
                dataKey="name" 
                tick={{ fill: "#64748b", fontSize: 11, fontWeight: 550 }}
                tickLine={{ stroke: "#e2e8f0" }}
              />
              <YAxis 
                tick={{ fill: "#64748b", fontSize: 10 }}
                tickFormatter={formatCurrency}
                tickLine={{ stroke: "#e2e8f0" }}
              />
              <Tooltip content={<CustomTooltipContent />} />
              <Legend verticalAlign="top" height={36} wrapperStyle={{ fontSize: "11px" }} />
              <Bar name={pKey} dataKey={pKey} stackId="a" fill="#6366f1" radius={[0, 0, 0, 0]} />
              <Bar name={iKey} dataKey={iKey} stackId="a" fill="#f59e0b" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        )}
      </div>

      <div className="mt-4 relative inline-block group/tooltip">
        <div className="inline-flex items-center gap-1.5 bg-slate-50 dark:bg-slate-850 border border-slate-150 dark:border-slate-800 px-3 py-1.5 rounded-xl text-xs font-bold cursor-help select-none transition hover:bg-slate-100 dark:hover:bg-slate-800">
          <Info className="w-3.5 h-3.5 text-indigo-500 shrink-0" />
          <span className="text-[10px] font-black uppercase text-indigo-600 dark:text-indigo-400">
            {lang === "en" ? "Chart Guide" : lang === "hi" ? "ग्राफ मार्गदर्शिका" : "Chart Guide / गाइड"}
          </span>
          <span className="text-amber-500 font-bold">&#9662;</span>
        </div>
        {/* FLOATING ABSOLUTE TOOLTIP */}
        <div className="absolute bottom-full left-0 mb-2 w-72 p-3 bg-slate-950 text-white dark:bg-white dark:text-slate-900 rounded-xl shadow-2xl border border-slate-800 dark:border-slate-200 text-xs leading-relaxed font-semibold transition-all duration-200 origin-bottom opacity-0 pointer-events-none scale-95 translate-y-1 group-hover/tooltip:opacity-100 group-hover/tooltip:pointer-events-auto group-hover/tooltip:scale-100 group-hover/tooltip:translate-y-0 z-50">
          <div className="font-extrabold text-[9px] uppercase text-indigo-400 dark:text-indigo-600 mb-1 tracking-wider">
            {lang === "en" ? "Interactive Chart Help" : "चार्ट विवरण"}
          </div>
          <p>{activeTab === "balance" ? t.chartInfoTextBalance : t.chartInfoTextCost}</p>
          <div className="absolute top-full left-5 -mt-1 border-4 border-transparent border-t-slate-950 dark:border-t-white" />
        </div>
      </div>
    </div>
  );
}
