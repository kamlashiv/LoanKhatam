import React, { useState } from "react";
import { LoanReport } from "../types";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  AreaChart,
  Area
} from "recharts";
import { 
  TrendingDown, 
  Coins, 
  Calendar, 
  ShieldAlert, 
  Zap, 
  ArrowRight,
  Info
} from "lucide-react";
import { translations } from "../utils/translations";

interface ScheduleComparisonChartProps {
  report: LoanReport;
  lang: "en" | "hi" | "bilingual";
}

export default function ScheduleComparisonChart({ report, lang }: ScheduleComparisonChartProps) {
  const [viewMode, setViewMode] = useState<"cumulative_interest" | "balance_runoff">("cumulative_interest");
  const [timeScale, setTimeScale] = useState<"yearly" | "monthly">("yearly");

  const t = translations[lang];

  const { schedule, standardSchedule, interestSaved, standardTotalInterest, acceleratedTotalInterest } = report;
  const standardTotalCost = report.input.amount + standardTotalInterest;
  const acceleratedTotalCost = report.input.amount + acceleratedTotalInterest;
  const totalCostSaved = standardTotalCost - acceleratedTotalCost;

  // Formatting helpers
  const formatCurrency = (val: number) => {
    if (val >= 10000000) return `₹${(val / 10000000).toFixed(2)} Cr`;
    if (val >= 100000) return `₹${(val / 100000).toFixed(1)} L`;
    return `₹${val.toLocaleString("en-IN")}`;
  };

  const formatMonthYearLabel = (monthNum: number) => {
    const years = Math.floor(monthNum / 12);
    const months = monthNum % 12;
    if (years === 0) return `${months} m`;
    if (months === 0) return `Yr ${years}`;
    return `Y${years} M${months}`;
  };

  // Generate comparison data points
  const maxMonth = Math.max(standardSchedule.length, schedule.length);
  const rawChartData = [];

  // Define keys for charting to avoid dynamic object layout discrepancies
  const oldLabel = lang === "en" ? "Old Schedule (Standard)" : "पुराना शेड्यूल (साधारण)";
  const newLabel = lang === "en" ? "New Schedule (Prepayment)" : "नया शेड्यूल (प्रीपेमेंट)";
  const savingsLabel = lang === "en" ? "Accrued Savings" : "कुल संचित बचत";

  if (timeScale === "monthly") {
    for (let m = 0; m <= maxMonth; m += Math.max(1, Math.floor(maxMonth / 24))) {
      // Find standard schedule at month m (or closing state)
      const stdRow = standardSchedule[Math.min(m, standardSchedule.length - 1)];
      const stdInterest = stdRow && m <= standardSchedule.length ? stdRow.cumulativeInterest : standardTotalInterest;
      const stdBalance = stdRow && m <= standardSchedule.length ? stdRow.closingBalance : 0;

      // Find accelerated schedule at month m (or closing state)
      const accRow = schedule[Math.min(m, schedule.length - 1)];
      const accInterest = accRow && m <= schedule.length ? accRow.cumulativeInterest : acceleratedTotalInterest;
      const accBalance = accRow && m <= schedule.length ? accRow.closingBalance : 0;

      rawChartData.push({
        label: formatMonthYearLabel(m),
        monthIndex: m,
        [oldLabel]: viewMode === "cumulative_interest" ? Math.round(stdInterest) : Math.round(stdBalance),
        [newLabel]: viewMode === "cumulative_interest" ? Math.round(accInterest) : Math.round(accBalance),
        [savingsLabel]: viewMode === "cumulative_interest" ? Math.round(Math.max(0, stdInterest - accInterest)) : Math.round(Math.max(0, stdBalance - accBalance)),
      });
    }
  } else {
    // Yearly data aggregation
    const maxYears = Math.ceil(maxMonth / 12);
    for (let y = 0; y <= maxYears; y++) {
      const m = y * 12;
      
      const stdRow = standardSchedule[Math.min(m, standardSchedule.length - 1)];
      const stdInterest = stdRow && m <= standardSchedule.length ? stdRow.cumulativeInterest : standardTotalInterest;
      const stdBalance = stdRow && m <= standardSchedule.length ? stdRow.closingBalance : 0;

      const accRow = schedule[Math.min(m, schedule.length - 1)];
      const accInterest = accRow && m <= schedule.length ? accRow.cumulativeInterest : acceleratedTotalInterest;
      const accBalance = accRow && m <= schedule.length ? accRow.closingBalance : 0;

      rawChartData.push({
        label: y === 0 ? (lang === "en" ? "Start" : "प्रारंभ") : `${lang === "en" ? "Year" : "वर्ष"} ${y}`,
        monthIndex: m,
        [oldLabel]: viewMode === "cumulative_interest" ? Math.round(stdInterest) : Math.round(stdBalance),
        [newLabel]: viewMode === "cumulative_interest" ? Math.round(accInterest) : Math.round(accBalance),
        [savingsLabel]: viewMode === "cumulative_interest" ? Math.round(Math.max(0, stdInterest - accInterest)) : Math.round(Math.max(0, stdBalance - accBalance)),
      });
    }
  }

  // Custom tooltips
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-slate-900 border border-slate-800 text-white p-3 rounded-xl shadow-xl text-xs font-sans space-y-1.5 min-w-[200px]">
          <p className="font-bold border-b border-slate-800 pb-1 text-slate-300">{label}</p>
          {payload.map((entry: any, idx: number) => (
            <div key={idx} className="flex justify-between items-center gap-4">
              <span className="flex items-center gap-1">
                <span className="w-2.5 h-2.5 rounded-full inline-block" style={{ backgroundColor: entry.color }} />
                <span className="text-slate-305">{entry.name}:</span>
              </span>
              <span className="font-black" style={{ color: entry.color }}>
                ₹{entry.value.toLocaleString("en-IN")}
              </span>
            </div>
          ))}
          {/* Direct difference summary to provide high satisfaction */}
          {payload.length >= 2 && (
            <div className="border-t border-slate-800 pt-1.5 flex justify-between items-center text-[10px] text-emerald-400 font-extrabold uppercase">
              <span>{lang === "en" ? "Difference Saved" : "बचत का अंतर"}:</span>
              <span>₹{Math.abs(payload[0].value - payload[1].value).toLocaleString("en-IN")}</span>
            </div>
          )}
        </div>
      );
    }
    return null;
  };

  return (
    <div id="schedule-comparison-container" className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-100 dark:border-slate-800 transition-all space-y-6">
      
      {/* HEADER SECTION */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="space-y-1">
          <span className="inline-flex items-center gap-1 bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-150 dark:border-indigo-900/40 text-indigo-700 dark:text-indigo-400 text-[10px] font-black uppercase px-2.5 py-0.5 rounded-full">
            <Zap className="w-3.5 h-3.5 text-amber-500 animate-pulse" />
            {lang === "en" ? "PROVEN COMPARATIVE RUNOFF" : "द्विपक्षीय भुगतान विवरण चार्ट"}
          </span>
          <h3 className="text-base font-extrabold text-slate-900 dark:text-white tracking-tight">
            {lang === "en" ? "Old vs. New Payment Schedule" : "पुराने बनाम नए भुगतान चक्र की तुलना"}
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            {lang === "en" 
              ? "See how standard slow-compounding compares with your active prepayment design."
              : "विलोपन की गति को देखें: बिना बदलाव के बैंक लागत और एक्स्ट्रा भुगतान योजना की तुलना।"}
          </p>
        </div>

        {/* CONTROLS */}
        <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
          {/* Metric Toggle */}
          <div className="flex bg-slate-50 dark:bg-slate-800 border border-slate-200/40 dark:border-slate-700/40 p-1 rounded-xl">
            <button
              onClick={() => setViewMode("cumulative_interest")}
              className={`px-3 py-1 rounded-lg text-[11px] font-black uppercase transition cursor-pointer ${
                viewMode === "cumulative_interest"
                  ? "bg-indigo-650 text-white shadow-xs"
                  : "text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-750"
              }`}
            >
              {lang === "en" ? "Interest Savings" : "ब्याज बचत"}
            </button>
            <button
              onClick={() => setViewMode("balance_runoff")}
              className={`px-3 py-1 rounded-lg text-[11px] font-black uppercase transition cursor-pointer ${
                viewMode === "balance_runoff"
                  ? "bg-indigo-650 text-white shadow-xs"
                  : "text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-750"
              }`}
            >
              {lang === "en" ? "Balance Runoff" : "लोन विलोपन"}
            </button>
          </div>

          {/* Time Resolution Toggle */}
          <div className="flex bg-slate-50 dark:bg-slate-800 border border-slate-200/40 dark:border-slate-700/40 p-1 rounded-xl">
            <button
              onClick={() => setTimeScale("yearly")}
              className={`px-2.5 py-1 rounded-lg text-[10px] font-bold uppercase transition cursor-pointer ${
                timeScale === "yearly"
                  ? "bg-slate-800 text-white dark:bg-slate-700"
                  : "text-slate-500 hover:text-slate-900 dark:text-slate-400"
              }`}
            >
              {lang === "en" ? "Yearly" : "वार्षिक"}
            </button>
            <button
              onClick={() => setTimeScale("monthly")}
              className={`px-2.5 py-1 rounded-lg text-[10px] font-bold uppercase transition cursor-pointer ${
                timeScale === "monthly"
                  ? "bg-slate-800 text-white dark:bg-slate-700"
                  : "text-slate-500 hover:text-slate-900 dark:text-slate-400"
              }`}
            >
              {lang === "en" ? "Monthly" : "मासिक"}
            </button>
          </div>
        </div>
      </div>

      {/* COMPARED FINANCIAL TOTALS CALLOUTS */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        
        {/* Old Path */}
        <div className="p-4 bg-slate-50/60 dark:bg-slate-800/20 border border-slate-100 dark:border-slate-800/80 rounded-2xl">
          <span className="text-[10px] font-black text-rose-500 uppercase tracking-widest block mb-0.5">
            {lang === "en" ? "Traditional Bank Contract" : "साधारण पुराना नियम"}
          </span>
          <strong className="text-base font-black text-slate-800 dark:text-slate-200 block">
            {formatCurrency(standardTotalCost)}
          </strong>
          <div className="flex justify-between items-center text-[10.5px] text-slate-500 mt-1 font-semibold">
            <span>Interest: ₹{standardTotalInterest.toLocaleString("en-IN")}</span>
            <span className="text-slate-400">&bull;&nbsp; {Math.ceil(standardSchedule.length / 12)} Yrs</span>
          </div>
        </div>

        {/* Prepaid Path */}
        <div className="p-4 bg-emerald-500/5 border border-emerald-500/20 rounded-2xl relative overflow-hidden">
          <div className="absolute right-2 top-2 w-1.5 h-1.5 bg-emerald-500 rounded-full animate-ping" />
          <span className="text-[10px] font-black text-emerald-600 dark:text-emerald-400 uppercase tracking-widest block mb-0.5">
            {lang === "en" ? "Accelerated Prepayout" : "नया बचत प्लान"}
          </span>
          <strong className="text-base font-black text-emerald-500 block">
            {formatCurrency(acceleratedTotalCost)}
          </strong>
          <div className="flex justify-between items-center text-[10.5px] text-slate-500 dark:text-slate-400 mt-1 font-semibold">
            <span>Interest: ₹{acceleratedTotalInterest.toLocaleString("en-IN")}</span>
            <span className="text-emerald-600 font-extrabold">{Math.round(schedule.length / 12)} Yrs</span>
          </div>
        </div>

        {/* Savings Focus */}
        <div className="p-4 bg-indigo-500/5 border border-indigo-500/20 rounded-2xl">
          <span className="text-[10px] font-black text-indigo-700 dark:text-indigo-400 uppercase tracking-widest block mb-0.5">
            {lang === "en" ? "COMPACTED SAVINGS VALUE" : "आपकी कुल वित्तीय बचत"}
          </span>
          <strong className="text-base font-black text-indigo-600 dark:text-indigo-400 block">
            {formatCurrency(totalCostSaved)}
          </strong>
          <div className="flex justify-between items-center text-[10.5px] text-indigo-650 dark:text-indigo-400 mt-1 font-black uppercase">
            <span>SAVED: {formatCurrency(interestSaved)} INTEREST</span>
            <span className="bg-indigo-600 text-white text-[8px] font-black px-1.5 py-0.5 rounded-sm">
              SUCCESS
            </span>
          </div>
        </div>

      </div>

      {/* GRAPH CANVAS SPACE */}
      <div className="h-80 w-full">
        <ResponsiveContainer width="100%" height="100%">
          {viewMode === "cumulative_interest" ? (
            <AreaChart data={rawChartData} margin={{ top: 10, right: 10, left: -15, bottom: 0 }}>
              <defs>
                <linearGradient id="colorOldInterest" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#ef4444" stopOpacity={0.12}/>
                  <stop offset="95%" stopColor="#ef4444" stopOpacity={0.0}/>
                </linearGradient>
                <linearGradient id="colorNewInterest" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#6366f1" stopOpacity={0.25}/>
                  <stop offset="95%" stopColor="#6366f1" stopOpacity={0.0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" className="stroke-slate-100 dark:stroke-slate-800/80" />
              <XAxis 
                dataKey="label" 
                tick={{ fill: "#64748b", fontSize: 10, fontWeight: 500 }}
                tickLine={{ stroke: "#e2e8f0" }}
              />
              <YAxis 
                tick={{ fill: "#64748b", fontSize: 10 }}
                tickFormatter={formatCurrency}
                tickLine={{ stroke: "#e2e8f0" }}
              />
              <Tooltip content={<CustomTooltip />} />
              <Legend verticalAlign="top" height={36} wrapperStyle={{ fontSize: "11px", fontWeight: "700" }} />
              
              <Area
                name={oldLabel}
                type="monotone"
                dataKey={oldLabel}
                stroke="#f43f5e"
                strokeWidth={2}
                fillOpacity={1}
                fill="url(#colorOldInterest)"
              />
              <Area
                name={newLabel}
                type="monotone"
                dataKey={newLabel}
                stroke="#6366f1"
                strokeWidth={3}
                fillOpacity={1}
                fill="url(#colorNewInterest)"
              />
            </AreaChart>
          ) : (
            <LineChart data={rawChartData} margin={{ top: 10, right: 10, left: -15, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" className="stroke-slate-100 dark:stroke-slate-800/80" />
              <XAxis 
                dataKey="label" 
                tick={{ fill: "#64748b", fontSize: 10, fontWeight: 500 }}
                tickLine={{ stroke: "#e2e8f0" }}
              />
              <YAxis 
                tick={{ fill: "#64748b", fontSize: 10 }}
                tickFormatter={formatCurrency}
                tickLine={{ stroke: "#e2e8f0" }}
              />
              <Tooltip content={<CustomTooltip />} />
              <Legend verticalAlign="top" height={36} wrapperStyle={{ fontSize: "11px", fontWeight: "700" }} />
              
              <Line
                name={oldLabel}
                type="monotone"
                dataKey={oldLabel}
                stroke="#f43f5e"
                strokeWidth={2}
                strokeDasharray="4 4"
                dot={false}
              />
              <Line
                name={newLabel}
                type="monotone"
                dataKey={newLabel}
                stroke="#10b981"
                strokeWidth={3}
                dot={false}
              />
            </LineChart>
          )}
        </ResponsiveContainer>
      </div>

      {/* EXPLANATORY INFORMATION TAG */}
      <div className="mt-4 relative inline-block group/tooltip">
        <div className="inline-flex items-center gap-1.5 bg-slate-50 dark:bg-slate-850 border border-slate-150 dark:border-slate-800 px-3 py-1.5 rounded-xl text-xs font-bold cursor-help select-none transition hover:bg-slate-100 dark:hover:bg-slate-800">
          <Info className="w-3.5 h-3.5 text-indigo-500 shrink-0" />
          <span className="text-[10px] font-black uppercase text-indigo-600 dark:text-indigo-400">
            {lang === "en" ? "Analysis Guide" : lang === "hi" ? "विश्लेषण मार्गदर्शिका" : "Analysis Guide / विश्लेषण"}
          </span>
          <span className="text-amber-500 font-bold">&#9662;</span>
        </div>
        {/* ABSOLUTE FLOATING TOOLTIP */}
        <div className="absolute bottom-full left-0 mb-2 w-80 p-3.5 bg-slate-950 text-white dark:bg-white dark:text-slate-900 rounded-xl shadow-2xl border border-slate-800 dark:border-slate-200 text-xs leading-relaxed font-semibold transition-all duration-200 origin-bottom opacity-0 pointer-events-none scale-95 translate-y-1 group-hover/tooltip:opacity-100 group-hover/tooltip:pointer-events-auto group-hover/tooltip:scale-100 group-hover/tooltip:translate-y-0 z-50">
          <div className="font-extrabold text-[9px] uppercase text-indigo-400 dark:text-indigo-600 mb-1.5 tracking-wider">
            {lang === "en" ? "Curve Analysis Guideline" : "वक्र विश्लेषण निष्कर्ष"}
          </div>
          <p>
            {viewMode === "cumulative_interest" 
              ? (lang === "en" 
                  ? `Note how the Traditional interest curve grows unchecked at standard EMIs. The Prepaid schedule curve flattens rapidly — capping the maximum interest paid and saving total expense.`
                  : `ध्यान दें कि पुराना परंपरागत ब्याज ग्राफ बढ़ता रहता है। आपका नया प्रीपेमेंट प्लान कुल संचित ब्याज के वक्र को चपटा कर देता है, जिससे लाखों रुपये की बचत होती है।`)
              : (lang === "en"
                  ? `The Balance Runoff compares how principal decreases over time. The gap demonstrates the principal lead you establish: paying off the debt completely by Year ${Math.round(schedule.length / 12)} instead of Year ${Math.round(standardSchedule.length / 12)}.`
                  : `यह ग्राफ दिखाता है कि मूलधन कितनी तेजी से कम होता है। नए शेड्यूल का वक्र बहुत तेजी से नीचे गिरता है। साधारण ग्राफ से उसकी चौड़ाई आपका अर्जित सुरक्षा मार्जिन है।`)}
          </p>
          <div className="absolute top-full left-5 -mt-1 border-4 border-transparent border-t-slate-950 dark:border-t-white" />
        </div>
      </div>

    </div>
  );
}
