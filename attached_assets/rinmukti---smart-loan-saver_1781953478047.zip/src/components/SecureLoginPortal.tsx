import React, { useState, useEffect } from "react";
import { 
  Landmark, User, Lock, KeyRound, AlertCircle, Sparkles, 
  Building2, Eye, EyeOff, ShieldCheck, ShieldAlert, 
  RefreshCw, Ban, Mail, Phone, Cpu, Fingerprint 
} from "lucide-react";

interface SecureLoginPortalProps {
  onLogin: (username: string, pin: string, bank: string) => void;
  lang: "en" | "hi" | "bilingual";
}

export default function SecureLoginPortal({ onLogin, lang }: SecureLoginPortalProps) {
  const [activeTab, setActiveTab] = useState<"login" | "register">("login");
  
  // Login Form States
  const [loginId, setLoginId] = useState(""); // Username, Email or Phone Number
  const [loginPassword, setLoginPassword] = useState("");
  
  // Registration Form States
  const [regUsername, setRegUsername] = useState("");
  const [regEmail, setRegEmail] = useState("");
  const [regPhone, setRegPhone] = useState("");
  const [regPassword, setRegPassword] = useState("");
  const [regBank, setRegBank] = useState("State Bank of India (SBI)");

  // Shared UI States
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Anti-Bot/Brute Force variables
  const generateCaptcha = () => {
    const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; 
    let code = "";
    for (let i = 0; i < 4; i++) {
      code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return code;
  };

  const [captchaCode, setCaptchaCode] = useState(() => generateCaptcha());
  const [userCaptcha, setUserCaptcha] = useState("");
  const [failedAttempts, setFailedAttempts] = useState(0);
  const [lockoutTimer, setLockoutTimer] = useState(0);

  // Countdown for lockout safety
  useEffect(() => {
    if (lockoutTimer > 0) {
      const timer = setInterval(() => {
        setLockoutTimer((t) => t - 1);
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [lockoutTimer]);

  const handleRefreshCaptcha = () => {
    setCaptchaCode(generateCaptcha());
    setUserCaptcha("");
  };

  // 1. SECURE LOGIN SUBMIT (Calls API)
  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMessage(null);

    if (lockoutTimer > 0) {
      setError(
        lang === "hi"
          ? `सुरक्षा लॉकडाउन: बहुत अधिक असफल प्रयास। कृपया ${lockoutTimer} सेकंड प्रतीक्षा करें।`
          : `Security Cooldown: Too many failed attempt signatures. Please wait ${lockoutTimer} seconds.`
      );
      return;
    }

    if (!loginId.trim()) {
      setError(lang === "hi" ? "कृपया उपयोगकर्ता नाम, ईमेल या फ़ोन नंबर दर्ज करें।" : "Please provide your username, email or phone number.");
      return;
    }
    if (!loginPassword.trim()) {
      setError(lang === "hi" ? "कृपया अपना गोपनीय पासवर्ड दर्ज करें।" : "Please provide your private access password.");
      return;
    }

    // Capture anti-bot confirmation
    if (userCaptcha.trim().toUpperCase() !== captchaCode) {
      setError(lang === "hi" ? "अमान्य या पुराना कैप्चा सत्यापन कोड।" : "CAPTCHA verification code is incorrect.");
      handleRefreshCaptcha();
      return;
    }

    setIsLoading(true);
    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ loginId: loginId.trim(), password: loginPassword }),
      });

      const result = await response.json();
      setIsLoading(false);

      if (!response.ok || !result.success) {
        throw new Error(result.error || "Authentication mismatched credentials.");
      }

      // Successful authenticating via high tech DB validation
      setSuccessMessage(lang === "hi" ? "लॉगिन सफल! तिजोरी डिक्रिप्ट की जा रही है..." : "Access authorized! Vault dencrypted successfully...");
      setFailedAttempts(0);
      
      // Delay briefly to allow nice loading effect
      setTimeout(() => {
        onLogin(result.user.username, loginPassword, result.user.bank);
      }, 1000);

    } catch (err: any) {
      setIsLoading(false);
      handleRefreshCaptcha();
      setError(err.message || "Failed to establish a secure link to the authentication chamber.");
      
      setFailedAttempts((prev) => {
        const next = prev + 1;
        if (next >= 3) {
          setLockoutTimer(45); // Lock down for 45s on brute attempt
        }
        return next;
      });
    }
  };

  // 2. SECURE ENROLL REGISTRATION SUBMIT (Calls API)
  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMessage(null);

    const trimmedUser = regUsername.trim();
    const trimmedEmail = regEmail.trim();
    const trimmedPhone = regPhone.trim().replace(/\D/g, ""); // Clean formatting
    const trimmedPass = regPassword;

    // Strict Validations
    if (!trimmedUser || trimmedUser.length < 3) {
      setError(lang === "hi" ? "उपयोगकर्ता नाम कम से कम 3 अक्षरों का होना चाहिए।" : "Username must be at least 3 characters.");
      return;
    }

    // Threat Check: Automated Injection prevention
    const dangerousPattern = /['"%;\-+=\(\)\{\}<>]/g;
    const injectionPattern = /<script|javascript:|onerror|onload|eval|select|union|update|delete/gi;
    if (dangerousPattern.test(trimmedUser) || injectionPattern.test(trimmedUser) || dangerousPattern.test(trimmedEmail)) {
      setError(lang === "hi" ? "सुरक्षा अलर्ट: अनाधिकृत स्क्रिप्ट कैरेक्टर ब्लॉक किए गए।" : "Security Shield active: Special code patterns blocked.");
      return;
    }

    if (!trimmedEmail || !trimmedEmail.includes("@")) {
      setError(lang === "hi" ? "कृपया एक मान्य ईमेल आईडी दर्ज करें।" : "Please enter a valid electronic email address.");
      return;
    }

    // Mandatory phone validation ("phone number is important")
    if (!regPhone || trimmedPhone.length < 10) {
      setError(lang === "hi" ? "अति महत्वपूर्ण: कृपया 10 अंकों का सक्रिय भारतीय मोबाइल नंबर दर्ज करें!" : "Primary Priority: A valid 10-digit primary phone number is mandatory!");
      return;
    }

    if (!trimmedPass || trimmedPass.length < 4) {
      setError(lang === "hi" ? "सुरक्षा के लिए पासवर्ड कम से कम 4 अक्षरों का होना चाहिए।" : "Password must be at least 4 characters.");
      return;
    }

    if (trimmedUser !== "Guest User" && (trimmedPass === "1234" || trimmedPass === "0000" || trimmedPass === "1111")) {
      setError(lang === "hi" ? "कमजोर पिन त्रुटि: '1234' या '0000' सुरक्षा कारणों से वर्जित है!" : "Vulnerability Alarm: Simplistic keys like '1234' are blocked.");
      return;
    }

    if (userCaptcha.trim().toUpperCase() !== captchaCode) {
      setError(lang === "hi" ? "अमान्य या पुराना कैप्चा सत्यापन कोड।" : "CAPTCHA verification is incorrect.");
      handleRefreshCaptcha();
      return;
    }

    setIsLoading(true);
    try {
      const response = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username: trimmedUser,
          email: trimmedEmail,
          phone: regPhone.trim(),
          password: trimmedPass,
          bank: regBank,
        }),
      });

      const result = await response.json();
      setIsLoading(false);

      if (!response.ok || !result.success) {
        throw new Error(result.error || "Database registration rejected.");
      }

      setSuccessMessage(lang === "hi" ? "ऋणमुक्ति बायोमेट्रिक वॉलेट पंजीकृत! कृपया अब लॉगिन करें।" : "Vault deploy initialized! Registration confirmed. You can now login.");
      
      // Reset registration forms and slide to login
      setLoginId(trimmedUser);
      setLoginPassword(trimmedPass);
      setActiveTab("login");
      handleRefreshCaptcha();

    } catch (err: any) {
      setIsLoading(false);
      handleRefreshCaptcha();
      setError(err.message || "Credential block rejected by cloud database server.");
    }
  };

  // Custom Guest Auto Simulator
  const setDemoAccount = () => {
    setLoginId("Guest User");
    setLoginPassword("1234");
    // Pre-match CAPTCHA code so user doesn't have to type it during testing
    const dummyCode = generateCaptcha();
    setCaptchaCode(dummyCode);
    setUserCaptcha(dummyCode);
    setError(null);
    setSuccessMessage(null);
  };

  return (
    <div className="min-h-[75vh] flex items-center justify-center py-10 px-4">
      <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-[0_0_50px_rgba(99,102,241,0.06)] relative">
        
        {/* Futuristic Grid Line Decorators */}
        <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-32 h-32 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-teal-500 via-indigo-500 to-amber-500" />

        <div className="px-6 py-8 sm:px-8 relative z-10">
          
          {/* Centered Futuristic Brand Logo & Title */}
          <div className="flex flex-col items-center text-center mb-8">
            <div className="w-16 h-16 bg-slate-950 border border-slate-800 rounded-2xl p-2.5 shadow-[0_0_20px_rgba(99,102,241,0.15)] flex items-center justify-center relative group select-none">
              <div className="absolute inset-0 bg-indigo-500/5 rounded-2xl group-hover:bg-indigo-500/15 transition-all duration-500 animate-pulse" />
              <svg
                id="login-brand-logo-cyber-svg"
                className="w-11 h-11 text-indigo-400 drop-shadow-[0_0_6px_rgba(129,140,248,0.5)] transition-transform duration-700"
                viewBox="0 0 100 100"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <circle cx="50" cy="50" r="44" stroke="currentColor" strokeWidth="2.5" strokeDasharray="5 5" className="opacity-40" />
                <path d="M50 12L54 22L64 25L54 28L50 38L46 28L36 25L46 22L50 12Z" fill="#F59E0B" className="animate-bounce" />
                
                {/* Broken Chain representation of RinMukti */}
                <path d="M34 56 C28 50 28 38 36 34 C42 31 50 35 52 42" stroke="currentColor" strokeWidth="6" strokeLinecap="round" />
                <path d="M48 58 C50 65 58 69 64 66 C72 62 72 50 66 44" stroke="currentColor" strokeWidth="6" strokeLinecap="round" />

                {/* Vertical prosperity indicator */}
                <path d="M50 82V42M50 42L41 51M50 42L59 51" stroke="#10B981" strokeWidth="7" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </div>

            <div className="mt-3.5">
              <h1 className="text-xl sm:text-2xl font-black text-white tracking-widest uppercase bg-clip-text text-transparent bg-gradient-to-r from-white via-indigo-100 to-slate-400">
                {lang === "hi" ? "ऋणमुक्ति सुरक्षा चैंबर" : "RINMUKTI SECURE CHAMBER"}
              </h1>
              <p className="text-[10px] sm:text-xs font-mono text-slate-500 tracking-wide mt-1 flex items-center justify-center gap-1.5 uppercase">
                <Cpu className="w-3 h-3 text-indigo-500 animate-spin" />
                <span>{lang === "hi" ? "100% एन्क्रिप्टेड क्रेडेंशियल बैकएंड वॉल्ट" : "100% Encrypted Credentials Backend Vault"}</span>
              </p>
            </div>
          </div>

          {/* SECURITY ALARM AND ERROR DIALOGS */}
          {error && (
            <div className="mb-6 p-3 bg-rose-500/10 border border-rose-500/20 text-rose-300 rounded-xl relative overflow-hidden flex items-start gap-2.5">
              <div className="absolute top-0 left-0 w-1 h-full bg-rose-500" />
              <ShieldAlert className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
              <div className="text-xs font-medium space-y-0.5">
                <span className="font-bold text-rose-200 block uppercase tracking-wider">{lang === "hi" ? "सुरक्षा उल्लंघ" : "SECURITY THREAT REPORTED"}</span>
                <p>{error}</p>
              </div>
            </div>
          )}

          {successMessage && (
            <div className="mb-6 p-3 bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 rounded-xl relative overflow-hidden flex items-start gap-2.5">
              <div className="absolute top-0 left-0 w-1 h-full bg-emerald-500" />
              <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
              <div className="text-xs font-medium space-y-0.5">
                <span className="font-bold text-emerald-200 block uppercase tracking-wider">{lang === "hi" ? "सुरक्षित अनुमति स्वीकृत" : "AUTHORIZATION APPROVED"}</span>
                <p>{successMessage}</p>
              </div>
            </div>
          )}

          {/* SECURE HIGH-TECH TAB SWITCHERS */}
          <div className="grid grid-cols-2 bg-slate-950 p-1 rounded-xl mb-6 border border-slate-800/80">
            <button
              type="button"
              onClick={() => {
                setActiveTab("login");
                setError(null);
                setSuccessMessage(null);
              }}
              className={`py-2 px-3 text-xs font-black transition duration-200 rounded-lg cursor-pointer uppercase ${
                activeTab === "login"
                  ? "bg-indigo-600/90 text-white shadow-md drop-shadow-[0_0_8px_rgba(99,102,241,0.25)]"
                  : "text-slate-400 hover:text-slate-200"
              }`}
            >
              🚀 {lang === "hi" ? "लॉगिन" : "ACCESS (SIGN IN)"}
            </button>
            <button
              type="button"
              onClick={() => {
                setActiveTab("register");
                setError(null);
                setSuccessMessage(null);
              }}
              className={`py-2 px-3 text-xs font-black transition duration-200 rounded-lg cursor-pointer uppercase ${
                activeTab === "register"
                  ? "bg-indigo-600/90 text-white shadow-md drop-shadow-[0_0_8px_rgba(99,102,241,0.25)]"
                  : "text-slate-400 hover:text-slate-200"
              }`}
            >
              🛰️ {lang === "hi" ? "नया रजिस्ट्रेशन" : "DEPLOY (REGISTER)"}
            </button>
          </div>

          {/* FORM AREA */}
          {activeTab === "login" ? (
            /* TAB 1: USER SECURE LOG IN */
            <form onSubmit={handleLoginSubmit} className="space-y-5">
              
              {/* Access ID */}
              <div>
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5 flex justify-between">
                  <span>{lang === "hi" ? "आईडेंटिटी की (नाम, ईमेल या नंबर)" : "CREDENTIAL ACCESS ID (NAME, EMAIL, OR PHONE)"}</span>
                  <span className="text-indigo-400 text-[9px] font-mono select-none">MANDATORY</span>
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                    <User className="h-4.5 w-4.5 text-slate-500" />
                  </div>
                  <input
                    type="text"
                    required
                    value={loginId}
                    onChange={(e) => setLoginId(e.target.value)}
                    placeholder={lang === "hi" ? "यूजरनेम, ईमेल या मोबाइल दर्ज करें..." : "Enter Username, Email, or 10-digit number..."}
                    className="block w-full pl-10.5 pr-4 py-3 bg-slate-950 border border-slate-800 rounded-xl text-sm focus:outline-hidden focus:border-indigo-500 focus:ring-1 focus:ring-indigo-550 text-slate-200 placeholder:text-slate-600 transition"
                  />
                </div>
              </div>

              {/* Secure Password Key */}
              <div>
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5 flex justify-between">
                  <span>{lang === "hi" ? "सुरक्षा पासवर्ड" : "SECURE CYBER PASSCODE"}</span>
                  <span className="text-indigo-400 text-[9px] font-mono select-none">AES-256</span>
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                    <Lock className="h-4.5 w-4.5 text-slate-500" />
                  </div>
                  <input
                    type={showPassword ? "text" : "password"}
                    required
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    placeholder="••••••••"
                    className="block w-full pl-10.5 pr-11 py-3 bg-slate-950 border border-slate-800 rounded-xl text-sm focus:outline-hidden focus:border-indigo-500 focus:ring-1 focus:ring-indigo-550 text-slate-200 placeholder:text-slate-600 transition tracking-widest font-mono"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-500 hover:text-slate-300 transition"
                  >
                    {showPassword ? <EyeOff className="h-4.5 w-4.5" /> : <Eye className="h-4.5 w-4.5" />}
                  </button>
                </div>
              </div>

              {/* Multi-Factor Captcha Safeguard block */}
              <div className="p-3.5 bg-slate-950 border border-slate-850 rounded-2xl space-y-2">
                <label className="block text-[9.5px] font-black text-slate-500 uppercase tracking-widest flex justify-between">
                  <span>{lang === "hi" ? "रोबोट सुरक्षा सत्यापन" : "CRYPTO ANTI-BOT CHALLENGE"}</span>
                  <span className="text-emerald-400 font-extrabold flex items-center gap-1 text-[9px]">
                    <ShieldCheck className="w-3.5 h-3.5 animate-pulse" />
                    SECURE SHIELD
                  </span>
                </label>
                <div className="flex items-center gap-3">
                  <div className="flex-1 bg-black text-slate-100 font-mono font-black text-center tracking-widest text-[16px] py-2 px-3 rounded-xl border border-slate-800 relative overflow-hidden flex items-center justify-center select-none">
                    <div className="absolute inset-0 bg-[radial-gradient(#ffffff08_1px,transparent_1px)] [background-size:8px_8px]" />
                    <div className="absolute inset-x-0 h-px bg-amber-500/25 -rotate-6 transform pointer-events-none" />
                    <span className="text-amber-400 tracking-widest font-black select-none pointer-events-none">{captchaCode}</span>
                    <button
                      type="button"
                      onClick={handleRefreshCaptcha}
                      className="ml-auto text-slate-500 hover:text-white transition duration-150 p-1 cursor-pointer bg-slate-900 border border-slate-800 rounded-lg"
                      title="Generate new passcode"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  <input
                    type="text"
                    required
                    maxLength={4}
                    value={userCaptcha}
                    onChange={(e) => setUserCaptcha(e.target.value.toUpperCase())}
                    placeholder="CAPT"
                    className="w-24 px-2 py-2 bg-black border border-slate-800 rounded-xl text-center text-sm font-black text-amber-400 focus:outline-hidden focus:border-indigo-500 placeholder:text-slate-700 font-mono uppercase"
                  />
                </div>
              </div>

              {lockoutTimer > 0 && (
                <div className="p-3 bg-rose-500/10 border border-rose-500/20 text-rose-400 rounded-xl flex items-center justify-center gap-2 text-[10px] font-black uppercase tracking-wider animate-pulse">
                  <Ban className="w-4 h-4" />
                  <span>{lang === "hi" ? `सुरक्षा ब्रेक: ${lockoutTimer}सेकंड प्रतीक्षा करें` : `BRUTE DETECTED - SYSTEM LOCKED FOR ${lockoutTimer}s`}</span>
                </div>
              )}

              {/* Login Button */}
              <button
                type="submit"
                disabled={lockoutTimer > 0 || isLoading}
                className="w-full flex items-center justify-center py-3.5 px-4 text-xs font-black rounded-xl text-white bg-indigo-650 hover:bg-indigo-750 disabled:bg-slate-850 disabled:text-slate-650 disabled:cursor-not-allowed transition duration-150 cursor-pointer uppercase active:scale-97 shadow-md drop-shadow-[0_0_8px_rgba(99,102,241,0.2)]"
              >
                {isLoading ? (
                  <span className="flex items-center gap-2 font-mono">
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    {lang === "hi" ? "सत्यापित किया जा रहा है..." : "CRYPTOGRAPHIC DECRYPTING..."}
                  </span>
                ) : lockoutTimer > 0 ? (
                  lang === "hi" ? "चैंबर बंद है" : "CHAMBER LOCK DOWN"
                ) : (
                  <span className="flex items-center gap-1.5">
                    <Fingerprint className="w-4.5 h-4.5" />
                    {lang === "hi" ? "लॉगिन करें और तिजोरी खोलें" : "Decrypt Vault & Sign In"}
                  </span>
                )}
              </button>

            </form>
          ) : (
            /* TAB 2: REGISTER PROFILE (Enrolls into database securely) */
            <form onSubmit={handleRegisterSubmit} className="space-y-4">
              
              {/* Full Name */}
              <div>
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">
                  {lang === "hi" ? "पूर्ण नाम (यूजरनेम)" : "FULL PROFILE NAME"}
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                    <User className="h-4 w-4 text-slate-500" />
                  </div>
                  <input
                    type="text"
                    required
                    value={regUsername}
                    onChange={(e) => setRegUsername(e.target.value)}
                    placeholder={lang === "hi" ? "उदा. शिवा चंद..." : "e.g. Shiva Chand..."}
                    className="block w-full pl-10.5 pr-4 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm focus:outline-hidden focus:border-indigo-500 focus:ring-1 focus:ring-indigo-550 text-slate-200 placeholder:text-slate-700 transition"
                  />
                </div>
              </div>

              {/* Private Email */}
              <div>
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">
                  {lang === "hi" ? "ईमेल आईडी" : "SECURE ELECTRONIC MAIL"}
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                    <Mail className="h-4 w-4 text-slate-500" />
                  </div>
                  <input
                    type="email"
                    required
                    value={regEmail}
                    onChange={(e) => setRegEmail(e.target.value)}
                    placeholder="yourname@gmail.com"
                    className="block w-full pl-10.5 pr-4 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm focus:outline-hidden focus:border-indigo-500 focus:ring-1 focus:ring-indigo-550 text-slate-200 placeholder:text-slate-700 transition"
                  />
                </div>
              </div>

              {/* Mandatory Verified Phone Number */}
              <div>
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1 flex justify-between items-center">
                  <span>{lang === "hi" ? "मोबाइल नंबर (अनिवार्य)" : "VERIFIED PHONE NUMBER"}</span>
                  <span className="text-[8.5px] text-amber-500 font-extrabold tracking-normal">★ CRITICAL ENTRY</span>
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                    <Phone className="h-4 w-4 text-slate-500" />
                  </div>
                  <input
                    type="tel"
                    required
                    maxLength={15}
                    value={regPhone}
                    onChange={(e) => setRegPhone(e.target.value)}
                    placeholder="+91 98765 43210"
                    className="block w-full pl-10.5 pr-4 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm focus:outline-hidden focus:border-indigo-500 focus:ring-1 focus:ring-indigo-550 text-slate-200 placeholder:text-slate-700 transition font-mono font-bold"
                  />
                </div>
              </div>

              {/* Bank Selection */}
              <div>
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">
                  {lang === "hi" ? "अपना बैंक चुनें" : "ACTIVE HOME LOAN BANK"}
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                    <Building2 className="h-4 w-4 text-slate-500" />
                  </div>
                  <select
                    value={regBank}
                    onChange={(e) => setRegBank(e.target.value)}
                    className="block w-full pl-10.5 pr-4 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs sm:text-sm focus:outline-hidden focus:border-indigo-500 text-slate-300 font-black cursor-pointer appearance-none"
                  >
                    <option value="State Bank of India (SBI)">State Bank of India (SBI)</option>
                    <option value="HDFC Bank">HDFC Bank</option>
                    <option value="ICICI Bank">ICICI Bank</option>
                    <option value="Punjab National Bank (PNB)">Punjab National Bank (PNB)</option>
                    <option value="Federal Bank">Federal Bank</option>
                    <option value="Axis Bank">Axis Bank</option>
                    <option value="Canara Bank">Canara Bank</option>
                  </select>
                </div>
              </div>

              {/* Passcode */}
              <div>
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">
                  {lang === "hi" ? "नया पासवर्ड बनाएँ" : "CHOOSE VAULT PASSWORD"}
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                    <KeyRound className="h-4 w-4 text-slate-500" />
                  </div>
                  <input
                    type={showPassword ? "text" : "password"}
                    required
                    value={regPassword}
                    onChange={(e) => setRegPassword(e.target.value)}
                    placeholder="••••••••"
                    className="block w-full pl-10.5 pr-11 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm focus:outline-hidden focus:border-indigo-500 focus:ring-1 focus:ring-indigo-550 text-slate-200 placeholder:text-slate-700 transition tracking-widest font-mono"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-500 hover:text-slate-300 transition"
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>

              {/* Bot Check Captcha */}
              <div className="p-2.5 bg-slate-950 border border-slate-850 rounded-xl flex items-center justify-between gap-2.5">
                <div className="bg-black py-1.5 px-3 rounded-lg border border-slate-800 text-center relative overflow-hidden select-none flex items-center justify-between w-32 shrink-0">
                  <span className="text-amber-400/90 font-mono font-black tracking-widest text-xs pointer-events-none">{captchaCode}</span>
                  <button
                    type="button"
                    onClick={handleRefreshCaptcha}
                    className="text-slate-600 hover:text-white transition p-0.5 ml-2 cursor-pointer"
                  >
                    <RefreshCw className="w-3 h-3" />
                  </button>
                </div>
                <input
                  type="text"
                  required
                  maxLength={4}
                  value={userCaptcha}
                  onChange={(e) => setUserCaptcha(e.target.value.toUpperCase())}
                  placeholder="CODE"
                  className="w-full px-2 py-1.5 bg-black border border-slate-800 rounded-lg text-center text-xs font-black text-amber-400 placeholder:text-slate-700 uppercase font-mono focus:border-indigo-400"
                />
              </div>

              {/* Deploy Button */}
              <button
                type="submit"
                disabled={isLoading}
                className="w-full flex items-center justify-center py-3.5 px-4 text-xs font-black rounded-xl text-white bg-emerald-650 hover:bg-emerald-750 disabled:bg-slate-850 transition duration-150 cursor-pointer uppercase shadow-md drop-shadow-[0_0_8px_rgba(16,185,129,0.15)]"
              >
                {isLoading ? (
                  <span className="flex items-center gap-2 font-mono">
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    DEPOLING PORTAL...
                  </span>
                ) : (
                  <span className="flex items-center gap-1.5">
                    <ShieldCheck className="w-4.5 h-4.5 animate-pulse" />
                    {lang === "hi" ? "सुरक्षित रूप से रजिस्टर करें" : "Deploy Secure Account Vault"}
                  </span>
                )}
              </button>

            </form>
          )}

          {/* SANDBOX GUEST SIMULATION SHORTCUT FOR SYSTEM SPEED */}
          <div className="mt-6 pt-5 border-t border-slate-850 text-center space-y-4">
            <button
              id="preset-login-demo-btn"
              type="button"
              onClick={setDemoAccount}
              className="inline-flex items-center gap-1.5 text-[10.5px] font-bold text-slate-400 hover:text-indigo-400 transition cursor-pointer bg-slate-950/80 hover:bg-slate-950 border border-slate-800/80 px-4 py-2.5 rounded-xl uppercase tracking-wider w-full justify-center shadow-inner"
            >
              <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
              <span>{lang === "hi" ? "डेमो सैंडबॉक्स क्रेडेंशियल ऑटोफिल करें" : "Simulate Sandbox Guest Profile"}</span>
            </button>

            {/* Founder Credit Info Box */}
            <div className="w-full bg-slate-950 border border-slate-850 rounded-2xl p-3.5 transition text-center shadow-inner">
              <span className="text-[8.5px] font-black text-slate-500 uppercase tracking-widest block mb-1">
                ⚙️ {lang === "hi" ? "डिजिटल परिसंपत्ति विवरण" : "SECURED ECOSYSTEM CONTROL"}
              </span>
              <p className="text-[11.5px] font-black text-slate-300">
                {lang === "hi" ? "संस्थापक और स्वामी: शिवा चंद" : "Founder & Owner: Shiva Chand"}
              </p>
              <p className="text-[9.5px] text-indigo-400 font-mono mt-0.5">
                shivachand67p@gmail.com
              </p>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
