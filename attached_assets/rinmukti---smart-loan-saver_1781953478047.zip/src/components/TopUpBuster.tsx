import React from "react";
import { LoanInput, PrepaymentInput, LumpSumPayment } from "../types";
import { calculateEMI } from "../utils/loanCalculator";
import { Sparkles, Trash2, ArrowUpRight, TrendingUp, DollarSign, Calendar, ShieldCheck, Flame, Zap, CheckCircle2 } from "lucide-react";
import { translations } from "../utils/translations";

interface TopUpBusterProps {
  input: LoanInput;
  prepayments: PrepaymentInput;
  onChangeInput: (newInput: LoanInput) => void;
  onChangePrepayments: (newPrepayments: PrepaymentInput) => void;
  lang: "en" | "hi" | "bilingual";
}

export default function TopUpBuster({
  input,
  prepayments,
  onChangeInput,
  onChangePrepayments,
  lang,
}: TopUpBusterProps) {
  const t = translations[lang];

  // Extract topup params or set defaults
  const topUpAmount = input.topUpAmount || 0;
  const topUpRate = input.topUpRate || input.rate;
  const topUpMonth = input.topUpMonth || 24;

  const totalTenureMonths = input.tenureYears * 12;
  const remainingMonthsTopUp = Math.max(1, totalTenureMonths - topUpMonth + 1);

  // Calculate separate EMIs
  const baseEMI = calculateEMI(input.amount, input.rate, input.tenureYears);
  const topUpEMI = topUpAmount > 0 ? calculateEMI(topUpAmount, topUpRate, remainingMonthsTopUp / 12) : 0;

  // Handler to configure Topup Loan quickly
  const handleSetTopUpValue = (field: keyof LoanInput, value: number | undefined) => {
    onChangeInput({
      ...input,
      [field]: value === 0 ? undefined : value,
    });
  };

  // Prepayment accelerator actions
  const applyPrepaymentAction = (type: "snowball" | "lumpsum" | "reset") => {
    if (type === "snowball") {
      // Add extra ₹3,000 monthly
      onChangePrepayments({
        ...prepayments,
        monthlyExtra: Math.max(prepayments.monthlyExtra, 3000),
      });
    } else if (type === "lumpsum") {
      // Add a lump sum payment targeted in the near months of topup activation
      const targetMonth = Math.min(totalTenureMonths, topUpMonth + 3);
      const lumpAmt = Math.round(topUpAmount * 0.15) || 50000; // 15% of top-up or 50k

      // Avoid duplicates
      const hasDuplicate = prepayments.lumpSums.some(
        (l) => l.atMonth === targetMonth && Math.abs(l.amount - lumpAmt) < 50
      );

      if (!hasDuplicate) {
        const newLump: LumpSumPayment = {
          id: "topup-lump-" + Math.random().toString(36).substr(2, 9),
          amount: lumpAmt,
          atMonth: targetMonth,
          label: lang === "en" ? "Topup Prepayment Strike" : "टॉप-अप बस्टर एकमुश्त भुगतान",
        };
        onChangePrepayments({
          ...prepayments,
          lumpSums: [...prepayments.lumpSums, newLump].sort((a, b) => a.atMonth - b.atMonth),
        });
      }
    } else if (type === "reset") {
      onChangePrepayments({
        ...prepayments,
        monthlyExtra: 0,
        lumpSums: prepayments.lumpSums.filter((l) => !l.id || !l.id.startsWith("topup-")),
      });
    }
  };

  const isSnowballActive = prepayments.monthlyExtra >= 3000;
  const isLumpActive = prepayments.lumpSums.some((l) => l.id && l.id.startsWith("topup-"));

  return (
    <div id="topup-buster-panel" className="bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-sm border border-slate-100 dark:border-slate-800 transition duration-300">
      
      {/* 👑 BILINGUAL HEADER */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6 pb-5 border-b border-slate-100 dark:border-slate-800">
        <div className="flex items-center space-x-3">
          <div className="p-3 bg-gradient-to-br from-amber-500 to-amber-600 text-white rounded-2xl shadow-sm">
            <Zap className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <h2 className="text-lg md:text-xl font-bold text-slate-900 dark:text-white tracking-tight flex items-center gap-1.5 flex-wrap">
              <span>{lang === "en" ? "Top-Up Loan Buster Plan" : "टॉप-अप कर्ज मुक्ति प्लान"}</span>
              <span className="text-xs bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-305 px-2.5 py-0.5 rounded-full font-black border border-amber-200 dark:border-amber-900 shadow-tiny select-none">
                {lang === "en" ? "Accelerated Payoff Guide" : "शीघ्र भुगतान विधि"}
              </span>
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 font-semibold">
              {lang === "en" 
                ? "How to isolate, calculate, and completely finish your top-up loan ahead of tenure!" 
                : "जानिए टॉप-अप लोन की किस्त को चुटकी में खत्म करने और लाखों का ब्याज बचाने की अचूक रणनीतियां!"}
            </p>
          </div>
        </div>

        {topUpAmount > 0 && (
          <button
            id="btn-remove-topup-completely"
            onClick={() => {
              handleSetTopUpValue("topUpAmount", undefined);
              handleSetTopUpValue("topUpRate", undefined);
              handleSetTopUpValue("topUpMonth", undefined);
            }}
            className="px-3.5 py-1.5 text-xs text-rose-600 hover:text-white hover:bg-rose-600 bg-rose-50 dark:bg-rose-950/20 dark:hover:bg-rose-900 border border-rose-200 dark:border-rose-900 font-bold rounded-xl transition duration-200 cursor-pointer flex items-center gap-1"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>{lang === "en" ? "Remove Top-Up" : "टॉप-अप हटाए"}</span>
          </button>
        )}
      </div>

      {topUpAmount <= 0 ? (
        /* PROMPT TO ACTIVATE TOP-UP LOAN */
        <div id="topup-intro-visual-prompt" className="p-6 bg-amber-50/20 dark:bg-amber-950/10 rounded-2xl border border-dashed border-amber-300 dark:border-amber-500/20 text-center space-y-4">
          <div className="mx-auto w-12 h-12 bg-amber-500/10 text-amber-600 dark:text-amber-400 rounded-full flex items-center justify-center text-2xl select-none">
            🦸‍♂️
          </div>
          <div className="max-w-md mx-auto">
            <h3 className="text-sm sm:text-base font-black text-slate-800 dark:text-slate-205">
              {lang === "en" ? "No Active Top-Up Loan Set" : "कोई टॉप-अप लोन सक्रिय नहीं है"}
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 leading-relaxed">
              {lang === "en"
                ? "Did you borrow extra cash over your base loan? Add top-up details separately to analyse its impact and simulate quick foreclosure strategies!"
                : "क्या आपने होम लोन के ऊपर कोई एक्स्ट्रा टॉप-अप लोन लिया है? यदि हाँ, तो शुरू करने के लिए नीचे दिए सिमुलेटर बटन को दबाएं!"}
            </p>
          </div>

          <div className="flex justify-center gap-3 flex-wrap">
            <button
              id="btn-simulate-small-topup"
              onClick={() => {
                handleSetTopUpValue("topUpAmount", 300000);
                handleSetTopUpValue("topUpRate", 9.5);
                handleSetTopUpValue("topUpMonth", 36);
              }}
              className="px-4 py-2 bg-slate-900 hover:bg-slate-800 dark:bg-slate-200 dark:hover:bg-white text-white dark:text-slate-900 text-xs font-black rounded-xl cursor-pointer shadow-xs transition active:scale-95"
            >
              {lang === "en" ? "Simulate ₹3 Lakhs Top-Up" : "₹3 लाख का टॉप-अप चालू करें"}
            </button>
            <button
              id="btn-simulate-mid-topup"
              onClick={() => {
                handleSetTopUpValue("topUpAmount", 750000);
                handleSetTopUpValue("topUpRate", 9.0);
                handleSetTopUpValue("topUpMonth", 24);
              }}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black rounded-xl cursor-pointer shadow-xs transition active:scale-95"
            >
              {lang === "en" ? "Simulate ₹7.5 Lakhs Top-Up" : "₹7.5 लाख का टॉप-अप चालू करें"}
            </button>
          </div>
        </div>
      ) : (
        /* ACTIVE TOP-UP BUSTER PLANNER SCREEN */
        <div className="space-y-6">
          
          {/* STATS SUMMARY GRID COVERS SEPARATED SYSTEM LOGS */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            
            {/* Top-up principal */}
            <div id="stat-topup-principal" className="p-4 bg-slate-50 dark:bg-slate-900 rounded-2.5xl border border-slate-100 dark:border-slate-800">
              <span className="text-[10px] uppercase font-black tracking-wider text-slate-400 block">
                {lang === "en" ? "Top-up Borrowed" : "टॉप-अप मूलधन"}
              </span>
              <p className="text-lg font-extrabold text-amber-700 dark:text-amber-400 mt-1 font-sans">
                ₹{Math.round(topUpAmount).toLocaleString("en-IN")}
              </p>
              <span className="text-[9px] text-slate-450 dark:text-slate-500 font-medium block mt-0.5">
                {lang === "en" ? `Triggered at Month ${topUpMonth}` : `माह ${topUpMonth} से प्रारंभ`}
              </span>
            </div>

            {/* Interest Difference */}
            <div id="stat-topup-rate" className="p-4 bg-slate-50 dark:bg-slate-900 rounded-2.5xl border border-slate-100 dark:border-slate-800">
              <span className="text-[10px] uppercase font-black tracking-wider text-slate-400 block">
                {lang === "en" ? "Top-Up Rate vs Base" : "टॉप-अप ब्याज दर"}
              </span>
              <p className="text-lg font-extrabold text-rose-600 dark:text-rose-400 mt-1 font-sans">
                {topUpRate}% PA
              </p>
              <span className="text-[9px] text-slate-450 dark:text-slate-500 font-semibold block mt-0.5">
                {topUpRate > input.rate 
                  ? (lang === "en" ? `⚠️ ${Math.round((topUpRate - input.rate)*10)/10}% extra vs base` : `⚠️ बेस लोन से एक्स्ट्रा ब्याज दर!`)
                  : (lang === "en" ? "In parity with base rate" : "बेस लोन के समान दर")}
              </span>
            </div>

            {/* Separate EMI generated */}
            <div id="stat-topup-emi" className="p-4 bg-slate-50 dark:bg-slate-900 rounded-2.5xl border border-slate-100 dark:border-slate-800">
              <span className="text-[10px] uppercase font-black tracking-wider text-slate-400 block">
                {lang === "en" ? "Top-Up Separate EMI" : "एक्स्ट्रा मासिक किस्त"}
              </span>
              <p className="text-lg font-extrabold text-slate-800 dark:text-slate-100 mt-1 font-sans">
                ₹{Math.round(topUpEMI).toLocaleString("en-IN")}
              </p>
              <span className="text-[9px] text-indigo-500 dark:text-indigo-400 font-bold block mt-0.5">
                {lang === "en" ? `${Math.round(remainingMonthsTopUp)} billing periods` : `${Math.round(remainingMonthsTopUp)} महीनों तक किस्त`}
              </span>
            </div>

            {/* Combined billing impact */}
            <div id="stat-topup-total-emi" className="p-4 bg-gradient-to-br from-indigo-50/70 to-indigo-150/10 dark:from-indigo-950/20 dark:to-slate-900 rounded-2.5xl border border-indigo-100/50 dark:border-indigo-900/30">
              <span className="text-[10.5px] uppercase font-black tracking-wider text-indigo-700 dark:text-indigo-300 block">
                {lang === "en" ? "Your New Total EMI" : "अब कुल EMI किस्त"}
              </span>
              <p className="text-xl font-black text-indigo-650 dark:text-indigo-400 mt-0.5 font-sans">
                ₹{Math.round(baseEMI + topUpEMI).toLocaleString("en-IN")}
              </p>
              <span className="text-[9.5px] text-slate-500 dark:text-slate-400 font-medium block mt-0.5">
                {lang === "en" ? `Base ₹${Math.round(baseEMI).toLocaleString("en-IN")} + Top-up` : `मूल ₹${Math.round(baseEMI).toLocaleString("en-IN")} + टॉप-अप`}
              </span>
            </div>

          </div>

          {/* 🎯 SEPARATE TOP-UP PARAMETER SLIDERS CONTROLLERS (ADD SEPARATE CONTROL ENGINES) */}
          <div className="bg-slate-50/60 dark:bg-slate-900/55 p-5 rounded-2xl border border-slate-100 dark:border-slate-800/80 space-y-4">
            <h3 className="text-xs sm:text-sm font-black text-slate-800 dark:text-slate-205 flex items-center gap-1.5 uppercase">
              <span className="w-2 h-2 rounded-full bg-amber-500 inline-block" />
              {lang === "en" ? "Tune Top-Up Separately" : "टॉप-अप लोन मूल्यों को बदलें"}
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
              
              {/* slider 1: topup amount */}
              <div>
                <div className="flex justify-between items-center mb-1 text-xs">
                  <span className="text-slate-500 font-semibold">{lang === "en" ? "Top-Up Principal" : "टॉप-अप एक्स्ट्रा लोन(₹)"}</span>
                  <span className="font-bold text-indigo-650 dark:text-indigo-400">₹{Math.round(topUpAmount).toLocaleString("en-IN")}</span>
                </div>
                <input
                  id="slider-topup-buster-amount"
                  type="range"
                  min={50000}
                  max={5000000}
                  step={20000}
                  value={topUpAmount}
                  onChange={(e) => handleSetTopUpValue("topUpAmount", parseFloat(e.target.value))}
                  className="w-full h-1.5 bg-slate-200 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-500"
                />
              </div>

              {/* slider 2: interest rate */}
              <div>
                <div className="flex justify-between items-center mb-1 text-xs">
                  <span className="text-slate-500 font-semibold">{lang === "en" ? "Interest Rate (% PA)" : "ब्याज दर (% प्रति वर्ष)"}</span>
                  <span className="font-bold text-rose-600 dark:text-rose-400">{topUpRate}%</span>
                </div>
                <input
                  id="slider-topup-buster-rate"
                  type="range"
                  min={5}
                  max={25}
                  step={0.1}
                  value={topUpRate}
                  onChange={(e) => handleSetTopUpValue("topUpRate", parseFloat(e.target.value))}
                  className="w-full h-1.5 bg-slate-200 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-500"
                />
              </div>

              {/* slider 3: month taken */}
              <div>
                <div className="flex justify-between items-center mb-1 text-xs">
                  <span className="text-slate-500 font-semibold">{lang === "en" ? "Month Borrowed" : "किस महीने में ऋण शुरू किया"}</span>
                  <span className="font-bold text-slate-700 dark:text-slate-250 font-mono">Mo {topUpMonth}</span>
                </div>
                <input
                  id="slider-topup-buster-month"
                  type="range"
                  min={1}
                  max={Math.max(12, totalTenureMonths - 12)}
                  step={1}
                  value={topUpMonth}
                  onChange={(e) => handleSetTopUpValue("topUpMonth", parseInt(e.target.value, 10))}
                  className="w-full h-1.5 bg-slate-200 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-500"
                />
              </div>

            </div>
          </div>

          {/* ⚡ THE DEBT-BUSTER STRATEGY TOOLKIT (कर्ज खत्म करने का अचूक तरीका) */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <Flame className="w-5 h-5 text-rose-500 animate-pulse" />
              <h3 className="text-sm sm:text-base font-black text-slate-800 dark:text-slate-100 uppercase tracking-tight">
                {lang === "en" ? "Strategies to Eliminate Top-up Loan Fast" : "टॉप-अप लोन को जड़ से खत्म करने के तरीके"}
              </h3>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              
              {/* Method 1: The Dedicate Snowflake Snowball */}
              <div 
                id="topup-method-snowball" 
                className={`p-5 rounded-2xl border transition duration-200 flex flex-col justify-between ${
                  isSnowballActive 
                    ? "bg-indigo-50/70 border-indigo-300 dark:bg-indigo-950/20 dark:border-indigo-900" 
                    : "bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:shadow-xs"
                }`}
              >
                <div>
                  <div className="flex justify-between items-start mb-2.5">
                    <span className="px-2.5 py-1 bg-indigo-55 text-indigo-700 dark:bg-indigo-950/40 dark:text-indigo-300 rounded-lg text-[10px] font-extrabold uppercase tracking-widest">
                      {lang === "en" ? "Rule 1: Snowball Attack" : "रणनीति १: स्नोबॉल हमला"}
                    </span>
                    {isSnowballActive && (
                      <span className="flex items-center text-[10px] font-black bg-emerald-500 text-white px-2 py-0.5 rounded-full shadow-tiny animate-pulse">
                        <CheckCircle2 className="w-3" />
                      </span>
                    )}
                  </div>
                  <h4 className="font-bold text-slate-800 dark:text-slate-100 leading-snug">
                    {lang === "en" ? "Top-Up Snowflake Attack (+₹3,000/mo)" : "किस्त के ऊपर एक्स्ट्रा ₹3,000 प्रति महीना"}
                  </h4>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-2 leading-relaxed">
                    {lang === "en"
                      ? "Pay an extra ₹3,000 per month above the combined EMI. Because a top-up loan balance is small, even a minor extra payout pays it off extremely fast!"
                      : "कंबाइंड किस्त के अलावा हर महीने ₹3,000 अतिरिक्त जमा करें। चूँकि टॉप-अप की राशि कम होती है, मासिक मामूली अतिरिक्त मूलधन इसे बहुत जल्द समाप्त कर देगा!"}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between">
                  <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400">
                    💡 {lang === "en" ? "Pays topup off to 60% faster!" : "⏱️ ७०% पहले लोन पूरा खत्म!"}
                  </span>
                  
                  <button
                    id="btn-apply-snowball-topup"
                    onClick={() => applyPrepaymentAction("snowball")}
                    className={`px-3 py-1.5 text-xs font-black rounded-lg transition-all cursor-pointer ${
                      isSnowballActive
                        ? "bg-emerald-600 text-white"
                        : "bg-slate-900 hover:bg-slate-800 text-white dark:bg-slate-850 dark:hover:bg-slate-750"
                    }`}
                  >
                    {isSnowballActive 
                      ? (lang === "en" ? "Active" : "सक्रिय है") 
                      : (lang === "en" ? "Apply Strategy" : "लागू करें")}
                  </button>
                </div>
              </div>

              {/* Method 2: The Tactical near Milestone (15% lumpsum strike) */}
              <div 
                id="topup-method-milestone" 
                className={`p-5 rounded-2xl border transition duration-200 flex flex-col justify-between ${
                  isLumpActive 
                    ? "bg-amber-50/40 border-amber-300 dark:bg-amber-950/15 dark:border-amber-900" 
                    : "bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:shadow-xs"
                }`}
              >
                <div>
                  <div className="flex justify-between items-start mb-2.5">
                    <span className="px-2.5 py-1 bg-amber-55 text-amber-800 dark:bg-amber-950/40 dark:text-amber-300 rounded-lg text-[10px] font-extrabold uppercase tracking-widest">
                      {lang === "en" ? "Rule 2: The Lumpsum Strike" : "रणनीति २: एकमुश्त प्रहार"}
                    </span>
                    {isLumpActive && (
                      <span className="flex items-center text-[10px] font-black bg-emerald-500 text-white px-2 py-0.5 rounded-full shadow-tiny animate-pulse">
                        <CheckCircle2 className="w-3" />
                      </span>
                    )}
                  </div>
                  <h4 className="font-bold text-slate-800 dark:text-slate-100 leading-snug">
                    {lang === "en" 
                      ? `Once-Off 15% Prepayment Strike (₹${(Math.round(topUpAmount * 0.15) || 50000).toLocaleString("en-IN")})` 
                      : `एक बार में 15% का एक्स्ट्रा धक्का (₹${(Math.round(topUpAmount * 0.15) || 50000).toLocaleString("en-IN")})`}
                  </h4>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-2 leading-relaxed">
                    {lang === "en"
                      ? "Pay a single 15% lump-sum three months after taking the top-up loan. Depositing early crashes the compounding interest curve before it accumulates."
                      : "लोन लेने के केवल ३ महीने के भीतर एक बार में १५% मूलधन का अतिरिक्त भुगतान कर दें। ऐसा प्रारंभिक चरण में करने से लोन पर ब्याज चक्र टूट जाता है!"}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between">
                  <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400">
                    💡 {lang === "en" ? "Save hefty interest compounding!" : "🔥 ब्याज कवकनाशी प्रभाव!"}
                  </span>
                  
                  <button
                    id="btn-apply-lump-topup"
                    onClick={() => applyPrepaymentAction("lumpsum")}
                    className={`px-3 py-1.5 text-xs font-black rounded-lg transition-all cursor-pointer ${
                      isLumpActive
                        ? "bg-emerald-600 text-white"
                        : "bg-slate-900 hover:bg-slate-800 text-white dark:bg-slate-850 dark:hover:bg-slate-750"
                    }`}
                  >
                    {isLumpActive 
                      ? (lang === "en" ? "Applied" : "लागू है") 
                      : (lang === "en" ? "Apply Strike" : "स्ट्राइक मारें")}
                  </button>
                </div>
              </div>

            </div>

            {/* General Payoff tips list */}
            <div className="bg-amber-500/5 dark:bg-amber-500/5 p-4 rounded-2xl border border-amber-300/40 dark:border-amber-500/20 text-xs text-slate-750 dark:text-slate-300 space-y-2 font-medium">
              <h4 className="font-extrabold text-amber-900 dark:text-amber-205 uppercase tracking-wider text-[11px] flex items-center gap-1">
                🛡️ {lang === "en" ? "Standard Top-Up Foreclosure Checklist" : "जल्दी खत्म करने के महत्वपूर्ण नियम (Checklist):"}
              </h4>
              <ul className="list-disc pl-5 mt-1.5 space-y-1.5 text-[11.5px] leading-relaxed">
                <li>
                  <strong>{lang === "en" ? "Interest parity lookup:" : "ब्याज दर संतुलन नियम:"}</strong>{" "}
                  {lang === "en" 
                    ? "Ensure the lender isn't charging >1.5% higher than your home loan. If they are, challenge them to reduce it to match the base rate."
                    : "सुनिश्चित करें कि बैंक इसपर मुख्य होम लोन से 1-2% अधिक ब्याज न वसूले। बैंक को ब्याज दर मुख्य लोन के समान करने का अनुरोध पत्र भेजें!"}
                </li>
                <li>
                  <strong>{lang === "en" ? "Consolidate into Home Loan principal:" : "मूल राशि में समाहित करना:"}</strong>{" "}
                  {lang === "en"
                    ? "If possible, pay regular extra lump sums specifically targeting the top-up account first, as it usually accrues a higher interest rate than Base Loan."
                    : "चूंकि टॉप-अप लोन का ब्याज अधिक होता है, अतिरिक्त बोनस हमेशा मुख्य लोन से पहले 'टॉप-अप लोन' खाते में डलवाएं ताकि अधिक ब्याज से मुक्ति मिल सके!"}
                </li>
                <li>
                  <strong>{lang === "en" ? "Cancel/Modify automatic sliders:" : "रिसेट सुरक्षात्मक नियम:"}</strong>{" "}
                  {lang === "en" ? "You can clear these custom simulated accelerated rules anytime below:" : "आप एक्स्ट्रा सिमुलेशन को किसी भी समय नीचे दिए बटन से रद्द कर सकते हैं:"}
                </li>
              </ul>

              {(isSnowballActive || isLumpActive) && (
                <div className="pt-2 flex justify-start">
                  <button
                    id="btn-reset-topup-buster"
                    onClick={() => applyPrepaymentAction("reset")}
                    className="px-3.5 py-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-705 text-slate-700 dark:text-slate-300 text-[10px] font-black rounded-lg transition cursor-pointer"
                  >
                    {lang === "en" ? "Reset Accelerated Simulated Rules" : "सभी एक्स्ट्रा सिमुलेशन को रद्द करें"}
                  </button>
                </div>
              )}
            </div>

          </div>

        </div>
      )}

    </div>
  );
}
