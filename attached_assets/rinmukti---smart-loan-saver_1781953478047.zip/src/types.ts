export interface LoanInput {
  amount: number;         // Principal Loan Amount (e.g., ₹25,00,000)
  rate: number;           // Annual Interest Rate % (e.g., 8.5)
  tenureYears: number;    // Loan Tenure in years (e.g., 20)
  startDate: string;      // Start Date YYYY-MM
  // Optional Top-up details
  topUpAmount?: number;      // e.g., ₹5,00,050
  topUpRate?: number;        // e.g., 9.2 %
  topUpMonth?: number;       // Month at which the top-up is taken (e.g., month 24)
}

export interface PrepaymentInput {
  monthlyExtra: number;        // Extra payment every month
  yearlyExtra: number;         // Extra payment once a year (e.g., bonus or 1 extra EMI)
  yearlyIncreasePercent: number; // Annual increase in regular EMI % (e.g., 5% every year)
  lumpSums: LumpSumPayment[];  // Multiple one-time lump-sum payments
}

export interface LumpSumPayment {
  id: string;
  amount: number;
  atMonth: number; // month index of the loan (e.g., 12th month, 24th month)
  label?: string;   // e.g., "Bonus", "Mutual Fund Maturity"
}

export interface AmortizationRow {
  monthNumber: number;
  yearNumber: number;
  monthInYear: number;
  dateLabel: string;
  openingBalance: number;
  scheduledEMI: number;
  actualEMI: number;
  regularInterest: number;
  regularPrincipal: number;
  extraPayment: number;
  totalPaidThisMonth: number;
  closingBalance: number;
  cumulativeInterest: number;
  cumulativePrincipal: number;
  isPrepaid: boolean;
}

export interface LoanReport {
  input: LoanInput;
  prepayments: PrepaymentInput;
  standardMonthlyEMI: number;
  standardTotalInterest: number;
  standardTotalPaid: number;
  standardTenureMonths: number;
  acceleratedTotalInterest: number;
  acceleratedTotalPaid: number;
  acceleratedTenureMonths: number;
  interestSaved: number;
  tenureSavedMonths: number;
  schedule: AmortizationRow[];
  standardSchedule: AmortizationRow[];
}

export interface SavedProfile {
  id: string;
  name: string;
  input: LoanInput;
  prepayments: PrepaymentInput;
  createdAt: string;
}
