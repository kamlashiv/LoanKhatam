import { LoanInput, PrepaymentInput, AmortizationRow, LoanReport, LumpSumPayment } from "../types";

// Helper to format date label
export function getMonthLabel(startDateStr: string, monthOffset: number): string {
  const date = new SetDate(startDateStr || "2026-06");
  date.setMonth(date.getMonth() + monthOffset);
  const months = [
    "Jan (जनवरी)", "Feb (फरवरी)", "Mar (मार्च)", "Apr (अप्रैल)", "May (मई)", "Jun (जून)",
    "Jul (जुलाई)", "Aug (अगस्त)", "Sep (सितंबर)", "Oct (अक्टूबर)", "Nov (नवंबर)", "Dec (दिसंबर)"
  ];
  return `${months[date.getMonth()]} ${date.getFullYear()}`;
}

class SetDate extends Date {
  constructor(dateStr: string) {
    // Parse YYYY-MM
    const parts = dateStr.split("-");
    const year = parseInt(parts[0], 10) || 2026;
    const month = parseInt(parts[1], 10) ? parseInt(parts[1], 10) - 1 : 5;
    super(year, month, 15); // Use 15th to avoid timezone shift errors
  }
}

// Calculate regular Monthly EMI
export function calculateEMI(principal: number, annualRate: number, tenureYears: number): number {
  const r = annualRate / 12 / 100;
  const n = tenureYears * 12;
  if (r === 0) return principal / n;
  return (principal * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
}

// Generate the standard schedule (No prepayments)
export function generateStandardSchedule(input: LoanInput): AmortizationRow[] {
  const { amount, rate, tenureYears, startDate, topUpAmount = 0, topUpRate, topUpMonth = 0 } = input;
  const monthlyRate = rate / 12 / 100;
  const topUpMonthlyRate = (topUpRate || rate) / 12 / 100;
  const totalMonths = tenureYears * 12;

  const baseEMI = calculateEMI(amount, rate, tenureYears);
  const remainingMonthsTopUp = Math.max(1, totalMonths - topUpMonth + 1);
  const topUpEMI = topUpAmount > 0 && topUpMonth > 0 
    ? calculateEMI(topUpAmount, topUpRate || rate, remainingMonthsTopUp / 12) 
    : 0;

  const schedule: AmortizationRow[] = [];
  let baseRemainingBalance = amount;
  let topUpRemainingBalance = 0;
  let cumulativeInterest = 0;
  let cumulativePrincipal = 0;

  for (let m = 1; m <= totalMonths * 2; m++) {
    // Add top-up if any when that month starts
    if (topUpAmount > 0 && topUpMonth > 0 && m === topUpMonth) {
      topUpRemainingBalance += topUpAmount;
    }

    const currentTotalBalance = baseRemainingBalance + topUpRemainingBalance;
    if (currentTotalBalance <= 0.01) {
      if (topUpAmount > 0 && topUpMonth > m) {
        // Keep loop running until we hit top-up month
      } else {
        break;
      }
    }

    // Determine current scheduled EMI
    let currentScheduledEMI = baseEMI;
    if (topUpAmount > 0 && topUpMonth > 0 && m >= topUpMonth) {
      currentScheduledEMI = baseEMI + topUpEMI;
    }

    // Calculate interest
    const baseInterest = baseRemainingBalance * monthlyRate;
    const topUpInterest = topUpRemainingBalance * topUpMonthlyRate;
    const interest = baseInterest + topUpInterest;

    let principalPaid = currentScheduledEMI - interest;
    if (principalPaid < 0) principalPaid = 0;

    if (principalPaid > currentTotalBalance) {
      principalPaid = currentTotalBalance;
    }

    // Deduct principalPaid from balances (first topUp balance, then base balance)
    let remainingPrincipalToPay = principalPaid;
    let paidToTopUp = 0;
    if (topUpRemainingBalance > 0) {
      paidToTopUp = Math.min(remainingPrincipalToPay, topUpRemainingBalance);
      topUpRemainingBalance = Math.max(0, topUpRemainingBalance - paidToTopUp);
      remainingPrincipalToPay -= paidToTopUp;
    }
    let paidToBase = 0;
    if (baseRemainingBalance > 0) {
      paidToBase = Math.min(remainingPrincipalToPay, baseRemainingBalance);
      baseRemainingBalance = Math.max(0, baseRemainingBalance - paidToBase);
      remainingPrincipalToPay -= paidToBase;
    }

    const actualPaymentThisMonth = interest + principalPaid;
    const closingBalance = baseRemainingBalance + topUpRemainingBalance;

    cumulativeInterest += interest;
    cumulativePrincipal += principalPaid;

    const yearNumber = Math.ceil(m / 12);
    const monthInYear = m % 12 === 0 ? 12 : m % 12;

    schedule.push({
      monthNumber: m,
      yearNumber,
      monthInYear,
      dateLabel: getMonthLabel(startDate, m - 1),
      openingBalance: currentTotalBalance,
      scheduledEMI: currentScheduledEMI,
      actualEMI: actualPaymentThisMonth,
      regularInterest: interest,
      regularPrincipal: principalPaid,
      extraPayment: 0,
      totalPaidThisMonth: actualPaymentThisMonth,
      closingBalance,
      cumulativeInterest,
      cumulativePrincipal,
      isPrepaid: false,
    });
  }

  return schedule;
}

// Generate accelerated schedule with multiple prepayment methods plus optional Top-Up
export function calculateLoanReport(input: LoanInput, prepayments: PrepaymentInput): LoanReport {
  const { amount, rate, tenureYears, startDate, topUpAmount = 0, topUpRate, topUpMonth = 0 } = input;
  const { monthlyExtra, yearlyExtra, yearlyIncreasePercent, lumpSums } = prepayments;

  const monthlyRate = rate / 12 / 100;
  const topUpMonthlyRate = (topUpRate || rate) / 12 / 100;
  const totalMonths = tenureYears * 12;
  
  // 1. Calculate standard values (incorporates top-up if any)
  const baseEMI = calculateEMI(amount, rate, tenureYears);
  const remainingMonthsTopUp = Math.max(1, totalMonths - topUpMonth + 1);
  const topUpEMI = topUpAmount > 0 && topUpMonth > 0 
    ? calculateEMI(topUpAmount, topUpRate || rate, remainingMonthsTopUp / 12) 
    : 0;

  const standardSchedule = generateStandardSchedule(input);
  const standardTotalPaid = standardSchedule.reduce((sum, row) => sum + row.totalPaidThisMonth, 0);
  const standardTotalInterest = standardSchedule.reduce((sum, row) => sum + row.regularInterest, 0);
  const standardTenureMonths = standardSchedule.length;

  // 2. Generate accelerated schedule
  const schedule: AmortizationRow[] = [];
  let baseRemainingBalance = amount;
  let topUpRemainingBalance = 0;
  let cumulativeInterest = 0;
  let cumulativePrincipal = 0;

  for (let m = 1; m <= totalMonths * 3; m++) { // safe margin
    if (topUpAmount > 0 && topUpMonth > 0 && m === topUpMonth) {
      topUpRemainingBalance += topUpAmount;
    }

    const currentTotalBalance = baseRemainingBalance + topUpRemainingBalance;
    if (currentTotalBalance <= 0.01) {
      if (topUpAmount > 0 && topUpMonth > m) {
        // Wait till topup triggers
      } else {
        break;
      }
    }

    const yearNumber = Math.ceil(m / 12);
    const monthInYear = m % 12 === 0 ? 12 : m % 12;

    // Regular base EMI increases by yearlyIncreasePercent on every year anniversary
    let currentRegularBaseEMI = baseEMI;
    if (yearlyIncreasePercent > 0 && yearNumber > 1) {
      currentRegularBaseEMI = baseEMI * Math.pow(1 + yearlyIncreasePercent / 100, yearNumber - 1);
    }

    // Determine target scheduled regular EMI 
    let currentRegularEMI = currentRegularBaseEMI;
    if (topUpAmount > 0 && topUpMonth > 0 && m >= topUpMonth) {
      currentRegularEMI = currentRegularBaseEMI + topUpEMI;
    }

    // Checking Interest
    const baseInterest = baseRemainingBalance * monthlyRate;
    const topUpInterest = topUpRemainingBalance * topUpMonthlyRate;
    const interest = baseInterest + topUpInterest;
    
    // B. Extra prepayments check
    let extra = 0;

    // - Monthly extra
    if (monthlyExtra > 0) {
      extra += monthlyExtra;
    }

    // - Yearly extra (added on anniversary e.g. month 12, 24, 36...)
    if (yearlyExtra > 0 && monthInYear === 12) {
      extra += yearlyExtra;
    }

    // - One-time lump sums at specific month
    const applicableLumpSums = lumpSums.filter(l => l.atMonth === m);
    applicableLumpSums.forEach(l => {
      extra += l.amount;
    });

    // C. Calculate standard monthly payoff flow
    let regularPrincipal = currentRegularEMI - interest;
    if (regularPrincipal < 0) {
      regularPrincipal = 0;
    }

    // Total available principal to pay: regular principal + extra
    let totalPrincipalPaid = regularPrincipal + extra;
    let isPrepaidThisMonth = extra > 0;

    if (totalPrincipalPaid > currentTotalBalance) {
      totalPrincipalPaid = currentTotalBalance;
      // Adjust extra payment down if it overpays the remaining balance
      const maxExtraNeeded = currentTotalBalance - regularPrincipal;
      extra = Math.max(0, maxExtraNeeded);
      isPrepaidThisMonth = extra > 0;
    }

    // Deduct principalPaid from balances (first topUp balance, then base balance)
    let remainingPrincipalToPay = totalPrincipalPaid;
    let paidToTopUp = 0;
    if (topUpRemainingBalance > 0) {
      paidToTopUp = Math.min(remainingPrincipalToPay, topUpRemainingBalance);
      topUpRemainingBalance = Math.max(0, topUpRemainingBalance - paidToTopUp);
      remainingPrincipalToPay -= paidToTopUp;
    }
    let paidToBase = 0;
    if (baseRemainingBalance > 0) {
      paidToBase = Math.min(remainingPrincipalToPay, baseRemainingBalance);
      baseRemainingBalance = Math.max(0, baseRemainingBalance - paidToBase);
      remainingPrincipalToPay -= paidToBase;
    }

    const totalPaidThisMonth = interest + totalPrincipalPaid;
    const closingBalance = baseRemainingBalance + topUpRemainingBalance;

    cumulativeInterest += interest;
    cumulativePrincipal += totalPrincipalPaid;

    schedule.push({
      monthNumber: m,
      yearNumber,
      monthInYear,
      dateLabel: getMonthLabel(startDate, m - 1),
      openingBalance: currentTotalBalance,
      scheduledEMI: currentRegularEMI,
      actualEMI: totalPaidThisMonth - extra,
      regularInterest: interest,
      regularPrincipal: totalPrincipalPaid - extra,
      extraPayment: extra,
      totalPaidThisMonth,
      closingBalance,
      cumulativeInterest,
      cumulativePrincipal,
      isPrepaid: isPrepaidThisMonth,
    });
  }

  const acceleratedTotalPaid = schedule.reduce((sum, row) => sum + row.totalPaidThisMonth, 0);
  const acceleratedTotalInterest = schedule.reduce((sum, row) => sum + row.regularInterest, 0);
  const acceleratedTenureMonths = schedule.length;

  const interestSaved = Math.max(0, standardTotalInterest - acceleratedTotalInterest);
  const tenureSavedMonths = Math.max(0, standardTenureMonths - acceleratedTenureMonths);

  return {
    input,
    prepayments,
    standardMonthlyEMI: baseEMI + (topUpAmount > 0 && topUpMonth > 0 ? topUpEMI : 0),
    standardTotalInterest,
    standardTotalPaid,
    standardTenureMonths,
    acceleratedTotalInterest,
    acceleratedTotalPaid,
    acceleratedTenureMonths,
    interestSaved,
    tenureSavedMonths,
    schedule,
    standardSchedule,
  };
}

// Convert amortization schedule to CSV format
export function convertScheduleToCSV(report: LoanReport): string {
  const headers = [
    "Month Number (महीना नं.)",
    "Year (साल)",
    "Payment Date (भुगतान तारीख)",
    "Opening Balance (शुरुआती बकाया)",
    "Scheduled EMI (नियमित किस्त)",
    "Extra Prepayment (अतिरिक्त भुगतान)",
    "Interest Paid (ब्याज भुगतान)",
    "Principal Paid (मूलधन भुगतान)",
    "Total Paid This Month (कुल भुगतान)",
    "Closing Balance (अंतिम बकाया)",
    "Cumulative Interest (कुल ब्याज अब तक)",
  ];

  const rows = report.schedule.map(row => [
    row.monthNumber,
    row.yearNumber,
    row.dateLabel,
    row.openingBalance.toFixed(2),
    row.scheduledEMI.toFixed(2),
    row.extraPayment.toFixed(2),
    row.regularInterest.toFixed(2),
    (row.regularPrincipal + row.extraPayment).toFixed(2),
    row.totalPaidThisMonth.toFixed(2),
    row.closingBalance.toFixed(2),
    row.cumulativeInterest.toFixed(2),
  ]);

  const csvContent = [
    `Loan Savings Report - Created on ${new Date().toLocaleDateString()}`,
    `Original Loan Amount,${report.input.amount}`,
    `Annual Rate of Interest,${report.input.rate}%`,
    `Original Tenure,${report.input.tenureYears} Years (${report.standardTenureMonths} Months)`,
    `Standard Monthly EMI,${report.standardMonthlyEMI.toFixed(2)}`,
    `Standard Total Interest,${report.standardTotalInterest.toFixed(2)}`,
    `Accelerated Total Interest,${report.acceleratedTotalInterest.toFixed(2)}`,
    `Total Interest SAVED,${report.interestSaved.toFixed(2)}`,
    `Tenure SAVED,${report.tenureSavedMonths} Months (${(report.tenureSavedMonths / 12).toFixed(1)} Years)`,
    "", // Empty line
    headers.join(","),
    ...rows.map(r => r.join(",")),
  ].join("\n");

  return csvContent;
}

// Simple Parser for JSON/CSV uploaded files
export interface ParsedUploadResult {
  amount?: number;
  rate?: number;
  tenureYears?: number;
  monthlyExtra?: number;
  yearlyExtra?: number;
  yearlyIncreasePercent?: number;
  lumpSums?: LumpSumPayment[];
}

export function parseUploadedFileContent(text: string, extension: string): ParsedUploadResult {
  const result: ParsedUploadResult = {};

  if (extension === "json") {
    try {
      const data = JSON.parse(text);
      // Try to read common properties
      if (data.amount || data.loanAmount || data.Principal) {
        result.amount = Number(data.amount || data.loanAmount || data.Principal);
      }
      if (data.rate || data.interestRate || data.Rate) {
        result.rate = Number(data.rate || data.interestRate || data.Rate);
      }
      if (data.tenureYears || data.tenure || data.Tenure) {
        result.tenureYears = Number(data.tenureYears || data.tenure || data.Tenure);
      }
      if (data.prepayments || data.prepayment) {
        const prep = data.prepayments || data.prepayment;
        if (prep.monthlyExtra) result.monthlyExtra = Number(prep.monthlyExtra);
        if (prep.yearlyExtra) result.yearlyExtra = Number(prep.yearlyExtra);
        if (prep.yearlyIncreasePercent) result.yearlyIncreasePercent = Number(prep.yearlyIncreasePercent);
        if (Array.isArray(prep.lumpSums)) result.lumpSums = prep.lumpSums;
      } else {
        if (data.monthlyExtra) result.monthlyExtra = Number(data.monthlyExtra);
        if (data.yearlyExtra) result.yearlyExtra = Number(data.yearlyExtra);
        if (data.yearlyIncreasePercent) result.yearlyIncreasePercent = Number(data.yearlyIncreasePercent);
        if (Array.isArray(data.lumpSums)) result.lumpSums = data.lumpSums;
      }
    } catch (e) {
      throw new Error("Invalid JSON structure (गलत JSON फ़ाइल)");
    }
  } else if (extension === "csv" || extension === "txt") {
    try {
      const lines = text.split("\n");
      // Read simple key-value lines
      lines.forEach(line => {
        const parts = line.split(",");
        if (parts.length >= 2) {
          const key = parts[0].trim().toLowerCase();
          const val = Number(parts[1].trim());
          if (!isNaN(val)) {
            if (key.includes("amount") || key.includes("principal") || key === "loan") {
              result.amount = val;
            } else if (key.includes("rate") || key.includes("interest")) {
              result.rate = val;
            } else if (key.includes("tenure") || key === "years" || key === "duration") {
              result.tenureYears = val;
            } else if (key.includes("monthly") && key.includes("extra")) {
              result.monthlyExtra = val;
            } else if (key.includes("yearly") && key.includes("extra")) {
              result.yearlyExtra = val;
            } else if (key.includes("increase") || key.includes("top-up") || key.includes("percent")) {
              result.yearlyIncreasePercent = val;
            }
          }
        }
      });
    } catch (e) {
      throw new Error("Invalid CSV or text structure (गलत CSV या टेक्स्ट फ़ाइल)");
    }
  }

  return result;
}
