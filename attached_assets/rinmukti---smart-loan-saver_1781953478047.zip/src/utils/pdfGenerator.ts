import { jsPDF } from "jspdf";
import { LoanReport } from "../types";

export function generateReportPDF(report: LoanReport, lang: "en" | "hi" | "bilingual") {
  const doc = new jsPDF({
    orientation: "portrait",
    unit: "mm",
    format: "a4",
  });

  const {
    standardMonthlyEMI,
    standardTotalInterest,
    standardTotalPaid,
    standardTenureMonths,
    acceleratedTotalInterest,
    acceleratedTotalPaid,
    acceleratedTenureMonths,
    interestSaved,
    tenureSavedMonths,
    prepayments,
    input
  } = report;

  // Formatting helpers
  const formatCurrency = (val: number) => {
    return "INR " + Math.round(val).toLocaleString("en-IN");
  };

  const yearsSaved = Math.floor(tenureSavedMonths / 12);
  const remainingMonthsSaved = tenureSavedMonths % 12;
  let savedTimeLabel = "";
  if (yearsSaved > 0 && remainingMonthsSaved > 0) {
    savedTimeLabel = `${yearsSaved} Yr(s) and ${remainingMonthsSaved} Month(s)`;
  } else if (yearsSaved > 0) {
    savedTimeLabel = `${yearsSaved} Yr(s)`;
  } else if (remainingMonthsSaved > 0) {
    savedTimeLabel = `${remainingMonthsSaved} Month(s)`;
  } else {
    savedTimeLabel = "0 Months (No change)";
  }

  const regularEndDate = report.standardSchedule.length > 0 
    ? report.standardSchedule[report.standardSchedule.length - 1].dateLabel 
    : "-";

  const acceleratedEndDate = report.schedule.length > 0
    ? report.schedule[report.schedule.length - 1].dateLabel
    : "-";

  // COLOR PALETTE (Warm Slate & Deep Indigo & Emerald)
  const PRIMARY_COLOR = [27, 38, 59]; // Navy
  const SECONDARY_COLOR = [79, 70, 229]; // Indigo
  const ACCENT_COLOR = [16, 185, 129]; // emerald green
  const TEXT_DARK = [51, 65, 85]; // slate 700
  const TEXT_LIGHT = [100, 116, 139]; // slate 500
  const BG_LIGHT = [248, 250, 252]; // slate 50

  // --- HEADER SECTION ---
  doc.setFillColor(PRIMARY_COLOR[0], PRIMARY_COLOR[1], PRIMARY_COLOR[2]);
  doc.rect(0, 0, 210, 40, "F");

  // App Title Logo
  doc.setTextColor(255, 255, 255);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(22);
  doc.text("LOANSAVER", 15, 18);

  doc.setFont("helvetica", "normal");
  doc.setFontSize(10);
  doc.setTextColor(190, 200, 220);
  doc.text("Personal Debt Prepayment & Acceleration Report", 15, 24);

  // Download Date & Stamp
  const today = new Date().toLocaleDateString("en-IN", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });
  doc.setFontSize(8);
  doc.setTextColor(255, 255, 255);
  doc.text(`Generated on: ${today}`, 195, 18, { align: "right" });
  doc.text("Status: Verified Standard Calculation", 195, 24, { align: "right" });

  doc.setFillColor(ACCENT_COLOR[0], ACCENT_COLOR[1], ACCENT_COLOR[2]);
  doc.rect(0, 40, 210, 2, "F");

  // --- COLUMN LAYOUT FOR METRICS ---
  let currentY = 55;

  // 1. Initial Parameters Panel
  doc.setFillColor(BG_LIGHT[0], BG_LIGHT[1], BG_LIGHT[2]);
  doc.rect(15, currentY, 180, 25, "F");
  doc.setDrawColor(226, 232, 240);
  doc.rect(15, currentY, 180, 25);

  doc.setTextColor(PRIMARY_COLOR[0], PRIMARY_COLOR[1], PRIMARY_COLOR[2]);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(10);
  doc.text("ORIGINAL LOAN PARAMETERS", 20, currentY + 6);

  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  doc.setTextColor(TEXT_DARK[0], TEXT_DARK[1], TEXT_DARK[2]);
  doc.text(`Principal: ${formatCurrency(input.amount)}`, 20, currentY + 14);
  doc.text(`Interest Rate: ${input.rate}% P.A.`, 75, currentY + 14);
  doc.text(`Tenure: ${input.tenureYears} Years (${input.tenureYears * 12} Mos)`, 125, currentY + 14);
  doc.text(`EMI Start: ${input.startDate || "Current month"}`, 20, currentY + 20);
  doc.text(`Base Monthly EMI: ${formatCurrency(standardMonthlyEMI)}`, 75, currentY + 20);

  currentY += 35;

  // --- BIG SPARKLING SAVINGS SUMMARY SECTION ---
  doc.setFillColor(240, 253, 250); // very light emerald
  doc.setDrawColor(16, 185, 129); // emerald line
  doc.rect(15, currentY, 180, 42, "F");
  doc.rect(15, currentY, 180, 42);

  // Badge Header
  doc.setFillColor(ACCENT_COLOR[0], ACCENT_COLOR[1], ACCENT_COLOR[2]);
  doc.rect(15, currentY, 70, 7, "F");
  doc.setTextColor(255, 255, 255);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(9);
  doc.text("ACCELERATED RETIREMENT SUMMARY", 20, currentY + 5);

  doc.setTextColor(PRIMARY_COLOR[0], PRIMARY_COLOR[1], PRIMARY_COLOR[2]);
  doc.setFontSize(11);
  doc.text("TOTAL CASH SAVED (INTEREST SAVED):", 20, currentY + 16);
  
  // Large saving number
  doc.setTextColor(ACCENT_COLOR[0], ACCENT_COLOR[1], ACCENT_COLOR[2]);
  doc.setFontSize(24);
  doc.text(formatCurrency(interestSaved), 20, currentY + 26);

  // Tenure saved message
  doc.setTextColor(PRIMARY_COLOR[0], PRIMARY_COLOR[1], PRIMARY_COLOR[2]);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(10);
  doc.text(`PAYOFF TIMELINE SLASHED BY:`, 115, currentY + 16);
  doc.setTextColor(SECONDARY_COLOR[0], SECONDARY_COLOR[1], SECONDARY_COLOR[2]);
  doc.setFontSize(16);
  doc.text(savedTimeLabel, 115, currentY + 24);

  // Timeline comparisons
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8.5);
  doc.setTextColor(TEXT_DARK[0], TEXT_DARK[1], TEXT_DARK[2]);
  doc.text(`Normal End: ${regularEndDate}`, 115, currentY + 31);
  doc.text(`New Accelerated End: ${acceleratedEndDate}`, 115, currentY + 36);

  const interestSavedPct = standardTotalInterest > 0 ? (interestSaved / standardTotalInterest) * 100 : 0;
  doc.setFont("helvetica", "italic");
  doc.setFontSize(8.5);
  doc.setTextColor(TEXT_LIGHT[0], TEXT_LIGHT[1], TEXT_LIGHT[2]);
  doc.text(`* This represents a massive reduction of ${interestSavedPct.toFixed(1)}% in your total outstanding interest expense.`, 20, currentY + 36);

  currentY += 52;

  // --- DETAIL T-CHART FOR PAIN COMPARISON ---
  doc.setTextColor(PRIMARY_COLOR[0], PRIMARY_COLOR[1], PRIMARY_COLOR[2]);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(11);
  doc.text("FINANCIAL OUTCOMES COMPARATIVE ANALYSIS", 15, currentY);

  currentY += 5;
  doc.setLineWidth(0.2);
  doc.setDrawColor(203, 213, 225);
  doc.line(15, currentY, 195, currentY);

  // Setup table values side by side
  currentY += 8;
  doc.setFontSize(9.5);
  doc.setFont("helvetica", "bold");
  doc.text("Summary Metrics", 15, currentY);
  doc.text("Standard Path (Lazy)", 95, currentY);
  doc.text("Savings Plan Path", 150, currentY);

  currentY += 3;
  doc.line(15, currentY, 195, currentY);

  const rows = [
    ["Monthly Principal + Interest EMI", formatCurrency(standardMonthlyEMI), formatCurrency(standardMonthlyEMI + prepayments.monthlyExtra)],
    ["Annual Extra Payoff Sum", "None / ₹0", formatCurrency(prepayments.yearlyExtra)],
    ["Annual Regular EMI Top-Up", "Disabled / 0%", `${prepayments.yearlyIncreasePercent}% Per Year`],
    ["Total Months Paid", `${standardTenureMonths} Months (${(standardTenureMonths / 12).toFixed(1)} Yrs)`, `${acceleratedTenureMonths} Months (${(acceleratedTenureMonths / 12).toFixed(1)} Yrs)`],
    ["Total Interest Accrued", formatCurrency(standardTotalInterest), formatCurrency(acceleratedTotalInterest)],
    ["Grand Final Capital Sum Paid", formatCurrency(standardTotalPaid), formatCurrency(acceleratedTotalPaid)],
  ];

  rows.forEach((row) => {
    currentY += 7;
    doc.setFont("helvetica", "normal");
    doc.setFontSize(8.5);
    doc.setTextColor(TEXT_DARK[0], TEXT_DARK[1], TEXT_DARK[2]);
    doc.text(row[0], 15, currentY);

    doc.setFont("helvetica", "normal");
    doc.text(row[1], 95, currentY);

    doc.setFont("helvetica", "bold");
    if (row[0].includes("Grand Final") || row[0].includes("Total Interest")) {
      doc.setTextColor(ACCENT_COLOR[0], ACCENT_COLOR[1], ACCENT_COLOR[2]);
    } else {
      doc.setTextColor(SECONDARY_COLOR[0], SECONDARY_COLOR[1], SECONDARY_COLOR[2]);
    }
    doc.text(row[2], 150, currentY);
  });

  currentY += 15;

  // --- SPECIAL INSTRUCTIONS & MOTIVATIONAL BANNER ---
  doc.setFillColor(BG_LIGHT[0], BG_LIGHT[1], BG_LIGHT[2]);
  doc.rect(15, currentY, 180, 24, "F");
  doc.setDrawColor(226, 232, 240);
  doc.rect(15, currentY, 180, 24);

  doc.setFont("helvetica", "bold");
  doc.setFontSize(8.5);
  doc.setTextColor(PRIMARY_COLOR[0], PRIMARY_COLOR[1], PRIMARY_COLOR[2]);
  doc.text("HOW TO DEPLOY THIS STRATEGY WITH YOUR BANK:", 20, currentY + 5);

  doc.setFont("helvetica", "normal");
  doc.setFontSize(7.5);
  doc.setTextColor(TEXT_DARK[0], TEXT_DARK[1], TEXT_DARK[2]);
  doc.text("1. Set aside the configured Monthly Extra amount in your savings account immediately on salary credit.", 20, currentY + 11);
  doc.text("2. Request your lender bank to adjust all extra sums exclusively toward the Principal component, not future EMIs.", 20, currentY + 15);
  doc.text("3. Implement the yearly Top-Up increment option online or via your bank branch every 12 months.", 20, currentY + 19);

  currentY += 34;

  // --- PREPAYMENT MILESTONES (Lump Sums) ---
  if (prepayments.lumpSums.length > 0) {
    doc.setTextColor(PRIMARY_COLOR[0], PRIMARY_COLOR[1], PRIMARY_COLOR[2]);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(10);
    doc.text("SAVIONS ONE-TIME MILITARY MILESTONES LOADED", 15, currentY);

    currentY += 4;
    doc.setDrawColor(226, 232, 240);
    doc.line(15, currentY, 195, currentY);

    prepayments.lumpSums.slice(0, 4).forEach((ls, idx) => {
      currentY += 5;
      doc.setFont("helvetica", "normal");
      doc.setFontSize(8);
      doc.setTextColor(TEXT_DARK[0], TEXT_DARK[1], TEXT_DARK[2]);
      doc.text(`${idx + 1}. Month ${ls.atMonth} Milestone`, 15, currentY);
      doc.text(`Amount: ${formatCurrency(ls.amount)}`, 60, currentY);
      doc.text(`Note: ${ls.label || "Bonus / Savings influx"}`, 120, currentY);
    });

    currentY += 10;
  }

  // --- FOOTER AND DISCLAIMER ---
  doc.setTextColor(TEXT_LIGHT[0], TEXT_LIGHT[1], TEXT_LIGHT[2]);
  doc.setFont("helvetica", "italic");
  doc.setFontSize(7);
  doc.text("Disclaimer: This tool calculates interest values based on standard daily reduction compounding formulas. Actual banks may have processing fees, dynamic marginal interest adjustments, or customized lock-in periods for prepayments. Print this roadmap as a strategic guideline to reclaim your financial freedom.", 15, 275);

  doc.setDrawColor(226, 232, 240);
  doc.line(15, 278, 195, 278);

  doc.setFont("helvetica", "bold");
  doc.setFontSize(7);
  doc.setTextColor(PRIMARY_COLOR[0], PRIMARY_COLOR[1], PRIMARY_COLOR[2]);
  doc.text("Reclaim Financial Freedom with LoanSaver Applet. Empowering families to clear loans 2x faster.", 15, 282);

  // Save the PDF physically
  const fileName = `LoanSaver_Report_${Math.round(interestSaved)}_Saved.pdf`;
  doc.save(fileName);
}
