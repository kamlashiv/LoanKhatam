export interface LanguageStrings {
  appName: string;
  appSubtitle: string;
  bilingualBadge: string;
  safetyBadge: string;
  quickBannerText: string;
  
  // Step guidelines
  step1Title: string;
  step1Desc: string;
  step2Title: string;
  step2Desc: string;
  step3Title: string;
  step3Desc: string;

  // Actions & Controls
  analyticsTitle: string;
  analyticsSubtitle: string;
  resetSavingsBtn: string;
  uploadFormatBtn: string;
  closeBtn: string;
  uploadGuideTitle: string;
  uploadGuideDesc: string;
  csvFormatGuide: string;
  csvFormatNote: string;
  jsonFormatGuide: string;
  jsonFormatNote: string;
  uploadErrorPrefix: string;
  clearBtn: string;
  extractingDocument: string;
  extractionSuccess: string;
  multiFormatUploadGuide: string;

  // Profiles Manager
  profileTitle: string;
  profileSubtitle: string;
  saveCurrentBtn: string;
  uploadFileBtn: string;
  saveProfilePlaceholder: string;
  saveBtn: string;
  cancelBtn: string;
  noProfilesItem: string;

  // Main input details
  loanDetailsTitle: string;
  principalLabel: string;
  interestRateLabel: string;
  tenureLabel: string;
  startDateLabel: string;

  // Playbook Prepayment Planner
  plannerTitle: string;
  monthlyExtraLabel: string;
  yearlyExtraLabel: string;
  yearlyExtraNote: string;
  topupLabel: string;
  topupNote: string;

  // Lump Sum payments
  lumpsumTitle: string;
  lumpsumSubtitle: string;
  amtLabel: string;
  monthIndexLabel: string;
  lumpNoteLabel: string;
  lumpPlaceholder: string;
  addedMilestonesHeader: string;
  noLumpsumLabel: string;

  // Strategy hacks
  hacksTitle: string;
  hacksSubtitle: string;
  magicExplainHeader: string;
  magicExplainText: string;

  // Cards
  interestSavedTitle: string;
  pureNetSavingsLabel: string;
  heavyInterestSavingsNote: string;
  prepaymentHelpNote: string;
  standardCostLabel: string;
  newCostLabel: string;

  tenureSavedTitle: string;
  debtFreeLabel: string;
  timeSavingPctNote: string;
  regularEndDateLabel: string;
  newEndDateLabel: string;

  emiDetailsTitle: string;
  regularEMIItem: string;
  monthlyExtraItem: string;
  yearlyTopupItem: string;
  totalPaidStandardItem: string;
  totalPaidSavingsItem: string;
  motivationalCarNote: string;

  // Charts
  chartsTitle: string;
  chartsSubtitle: string;
  tabBalanceTrend: string;
  tabCostSave: string;
  chartsStandardLegend: string;
  chartsAcceleratedLegend: string;
  chartInfoTextBalance: string;
  chartInfoTextCost: string;

  // Table
  tableTitle: string;
  tableSubtitle: string;
  viewYearlyBtn: string;
  viewMonthlyBtn: string;
  exportCsvBtn: string;
  exportPdfBtn: string;
  exportJsonBtn: string;
  searchPlaceholderYearly: string;
  searchPlaceholderMonthly: string;
  totalDurationRowText: string;
  colYear: string;
  colOpening: string;
  colEMI: string;
  colExtra: string;
  colInterest: string;
  colPrincipal: string;
  colClosing: string;
  noRecordsFound: string;
  showingRecordsPrefix: string;
  btnPrev: string;
  btnNext: string;
  fullPaidOffLabel: string;
}

export const translations: Record<"en" | "hi" | "bilingual", LanguageStrings> = {
  en: {
    appName: "RinMukti | Smart Loan-Saver",
    appSubtitle: "Unlock interest freedom early. Save massive lifetime cash with smart voluntary repayments",
    bilingualBadge: "Bilingual Supported",
    safetyBadge: "100% Secure Calculation",
    quickBannerText: "Using a 5% Annual Top-up strategy saves ₹4.5L in interest and 4 years of tenure on average!",
    
    step1Title: "1. Enter Loan Details",
    step1Desc: "Fill in your active loan's principal amount, interest rate (APR) and tenure.",
    step2Title: "2. Set Extra Savings",
    step2Desc: "Toggle extra monthly, annual, or one-time lump sum prepayment strategies.",
    step3Title: "3. Export & Save",
    step3Desc: "Examine the dynamic payoff schedule and export the data to Excel or PDF.",

    analyticsTitle: "Live Savings Analytics",
    analyticsSubtitle: "Stats update instantly as you fine-tune your parameters and payment strategies",
    resetSavingsBtn: "Reset Extra Savings",
    uploadFormatBtn: "Upload Guide & CSV Template",
    closeBtn: "Close",
    uploadGuideTitle: "File Upload Template Instructions",
    uploadGuideDesc: "Load external profiles using standard JSON or flat CSV spreadsheets formatted as follows:",
    csvFormatGuide: "Plain CSV Format (Simple Key-Value)",
    csvFormatNote: "Note: Ensure each key is followed by its numeric value separated by a comma.",
    jsonFormatGuide: "JSON Format (Advanced Developer Profile)",
    jsonFormatNote: "Verify standard quotes and brace matches before drag-and-drop actions.",
    uploadErrorPrefix: "Upload Error",
    clearBtn: "Clear",
    extractingDocument: "Extracting loan details using Gemini AI...",
    extractionSuccess: "Successfully extracted loan details!",
    multiFormatUploadGuide: "Upload PDF documents, JPEG/PNG images, or JSON/CSV files. Gemini AI will automatically extract primary loan details.",

    profileTitle: "Saved Loan Profiles",
    profileSubtitle: "Save different scenario runs to compare multiple options directly",
    saveCurrentBtn: "Save Current Setup",
    uploadFileBtn: "Upload File (JSON/CSV/PDF/Image)",
    saveProfilePlaceholder: "e.g., SBI Home Loan, Federal Car Loan",
    saveBtn: "Save Profile",
    cancelBtn: "Cancel",
    noProfilesItem: "No saved setup profiles. Put details and click save to lock a comparison.",

    loanDetailsTitle: "Original Loan Parameters",
    principalLabel: "Principal Loan Amount (₹)",
    interestRateLabel: "Annual Interest Rate (% P.A.)",
    tenureLabel: "Original Tenure (Years)",
    startDateLabel: "EMI Payments Start Month",

    plannerTitle: "Prepayment & Top-up Planner",
    monthlyExtraLabel: "Extra Monthly Prepayment Recurring (₹)",
    yearlyExtraLabel: "Extra Yearly Prepayment (₹)",
    yearlyExtraNote: "Applied automatically at every annual loan anniversary (Month 12, 24...)",
    topupLabel: "Annual EMI Top-up (%)",
    topupNote: "Increase your regular EMI by this % every year as your annual income hikes",

    lumpsumTitle: "One-Time Lump-Sum Milestones",
    lumpsumSubtitle: "Add unexpected cash influxes (Bonuses, FD Maturation, Assets sale) to pay at specific months",
    amtLabel: "Lump-Sum Amount (₹)",
    monthIndexLabel: "Paid in Month Index (1 - Max Tenure Months)",
    lumpNoteLabel: "Label / Note (e.g. Bonus)",
    lumpPlaceholder: "e.g. Mutual Fund Maturity",
    addedMilestonesHeader: "Added One-Time Milestones",
    noLumpsumLabel: "No one-time milestones added yet.",

    hacksTitle: "Smart Payoff Leverage Strategies",
    hacksSubtitle: "Select any strategy below to instantly load it into the prepayment dashboard",
    magicExplainHeader: "The Prepayment Acceleration Magic",
    magicExplainText: "In primary years of a loan, 70-80% of your EMI goes strictly to absolute interest while principal decreases sluggishly. Any additional prepayment directly eats into the core Principal balance. This drops the compound interest calculation rate immediately, slicing years off your loan!",

    interestSavedTitle: "Total Net Interest Saved",
    pureNetSavingsLabel: "Your Net Cash Interest Savings:",
    heavyInterestSavingsNote: "Amazing! Slashed total compounding interest charge by",
    prepaymentHelpNote: "Add prepayment parameters to simulate high compound interest savings here",
    standardCostLabel: "Standard Cost:",
    newCostLabel: "Savings Plan Cost:",

    tenureSavedTitle: "Accelerated Payoff Timeline",
    debtFreeLabel: "Saves Time & Slashes Years:",
    timeSavingPctNote: "Wow! Your active loan timeline is reduced by",
    regularEndDateLabel: "Standard payoff date:",
    newEndDateLabel: "Savings plan payoff date:",

    emiDetailsTitle: "Monthly Installment Breakdown",
    regularEMIItem: "Base Monthly EMI:",
    monthlyExtraItem: "Monthly Extra Prepayment:",
    yearlyTopupItem: "Annual Regular EMI Topup:",
    totalPaidStandardItem: "Total Paid (Standard Path):",
    totalPaidSavingsItem: "Total Paid (Savings Plan Path):",
    motivationalCarNote: "Redeemed cash can buy a brand new vehicle or fund your family's future!",

    chartsTitle: "Comparative Progress Visual Chart",
    chartsSubtitle: "Visualize how your balance decreases faster under different strategies",
    tabBalanceTrend: "Balance Over Time",
    tabCostSave: "Total Costs Saved",
    chartsStandardLegend: "Standard Balance Timeline",
    chartsAcceleratedLegend: "Accelerated Payoff Plan",
    chartInfoTextBalance: "The green line represents your accelerated payoff path. The steep decline demonstrates severe savings in total cumulative tenure.",
    chartInfoTextCost: "Review total outstanding package costs. The amber bar (Interest) collapses dramatically on applying smart prepayments.",

    tableTitle: "Detailed Amortization & Repayment Ledger",
    tableSubtitle: "Examine complete scheduled calculations breakdown side-by-side",
    viewYearlyBtn: "Yearly Collapsed Summary",
    viewMonthlyBtn: "Monthly Detailed View",
    exportCsvBtn: "Download Excel/CSV Report",
    exportPdfBtn: "Download PDF Report",
    exportJsonBtn: "Download JSON Data",
    searchPlaceholderYearly: "Search Years or Labels (e.g., Year 2)...",
    searchPlaceholderMonthly: "Search Date Labels or Months (e.g., Jul 2028)...",
    totalDurationRowText: "Total schedule size:",
    colYear: "Duration Period",
    colOpening: "Opening Balance",
    colEMI: "EMI Sum Paid",
    colExtra: "Prepaid Extra Sum",
    colInterest: "Interest Component",
    colPrincipal: "Principal Restructured",
    colClosing: "Outstanding Closing",
    noRecordsFound: "No schedule records matched your query filter.",
    showingRecordsPrefix: "Displaying payments line items",
    btnPrev: "Prev",
    btnNext: "Next",
    fullPaidOffLabel: "Fully Paid Off!",
  },
  hi: {
    appName: "ऋणमुक्ति (RinMukti) | स्मार्ट लोन सेविंग",
    appSubtitle: "कर्ज के चक्रव्यूह से जल्दी मुक्ति पाएं, भारी ब्याज बचाएं और अपने बैंक लोन से आजादी पाएं",
    bilingualBadge: "द्विभाषी सहायता सक्रिय",
    safetyBadge: "100% सुरक्षित और सटीक गणना",
    quickBannerText: "सालाना केवल 5% EMI बढ़ाने वाली रणनीति से औसतन ₹4.5 लाख का ब्याज और 4 साल बचते हैं!",
    
    step1Title: "1. लोन विवरण भरें",
    step1Desc: "अपने लोन का मूलधन, लागू ब्याज दर (%) और कुल वर्षों की अवधि यहाँ दर्ज़ करें।",
    step2Title: "2. बचत योजना सक्रिय करें",
    step2Desc: "मासिक एक्स्ट्रा, सालाना बोनस या बीच-बीच में मिलने वाली एकमुश्त राशि का विवरण सेट करें।",
    step3Title: "3. आँकड़े डाउनलोड करें",
    step3Desc: "लाइव ब्याज बचत पत्र देखें और पूरी टेबल को एक्सेल, CSV या प्रिंट पीडीएफ के रूप में निकालें।",

    analyticsTitle: "लाइव बचत विश्लेषण",
    analyticsSubtitle: "जैसे ही आप विवरण बदलेंगे, लाइव गणितीय आँकड़े तुरंत अपडेट हो जाएंगे",
    resetSavingsBtn: "अतिरिक्त भुगतान हटाएं",
    uploadFormatBtn: "फ़ाइल अपलोड करने की गाइड",
    closeBtn: "बंद करें",
    uploadGuideTitle: "फ़ाइल अपलोड करने का प्रारूप और निर्देश",
    uploadGuideDesc: "आप अपनी पूर्व सहेजी हुई ऋण फ़ाइलों (JSON या CSV) को नीचे दिए प्रारूप में यहाँ ला सकते हैं:",
    csvFormatGuide: "सरल CSV प्रारूप (कुंजी-मूल्य)",
    csvFormatNote: "ध्यान दें: प्रत्येक पंक्ति में की (Key) और उसका मूल्य कौमा (,) से अलग होना चाहिए।",
    jsonFormatGuide: "JSON प्रारूप (उन्नत स्तर)",
    jsonFormatNote: "सुनिश्चित करें कि कर्ली ब्रैकेट और डबल कोट्स पूरी तरह सही और संतुलित हों।",
    uploadErrorPrefix: "अपलोड विफलता",
    clearBtn: "हटाएं",
    extractingDocument: "जेमिनी एआई द्वारा लोन के विवरण निकाले जा रहे हैं...",
    extractionSuccess: "लोन का विवरण सफलतापूर्वक निकाल लिया गया है!",
    multiFormatUploadGuide: "आप कोई भी PDF दस्तावेज, JPEG या PNG इमेज, या JSON/CSV फाइल अपलोड कर सकते हैं। हमारा जेमिनी एआई स्वतः विवरण निकाल लेगा।",

    profileTitle: "सहेजे गए लोन प्रोफाइल",
    profileSubtitle: "अनेक बैंक योजनाओं की आपस में सीधी तुलना करने के लिए प्रोफाइल सहेजें",
    saveCurrentBtn: "वर्तमान सेटअप सहेजें",
    uploadFileBtn: "फ़ाइल लाएं (JSON/CSV/PDF/इमेज)",
    saveProfilePlaceholder: "जैसे: एसबीआई होम लोन, एचडीएफसी कार लोन",
    saveBtn: "प्रोफ़ाइल सहेजें",
    cancelBtn: "रद्द करें",
    noProfilesItem: "कोई प्रोफाइल नहीं है। चालू कैलकुलेशन सहेजने के लिए नया सहेजें बटन दबाएं।",

    loanDetailsTitle: "ऋण की जानकारी (मूल विवरण)",
    principalLabel: "कुल लोन ली गई राशि / मूलधन (₹)",
    interestRateLabel: "लागू वार्षिक ब्याज दर (% प्रतिवर्ष)",
    tenureLabel: "लोन चुकाने की कुल अवधि (वर्षों में)",
    startDateLabel: "EMI शुरू होने का महीना",

    plannerTitle: "अतिरिक्त भुगतान योजनाकार (किस्त जमा)",
    monthlyExtraLabel: "हर महीने कितनी अतिरिक्त राशि चुकाएंगे? (₹)",
    yearlyExtraLabel: "सालाना अतिरिक्त एकमुश्त भुगतान (₹)",
    yearlyExtraNote: "यह राशि हर लोन वर्ष की वर्षगांठ (12वें, 24वें महीने आदि) पर स्वतः जोड़ी जाएगी",
    topupLabel: "सालाना EMI टॉप-अप बढ़ोतरी (%)",
    topupNote: "जैसे सैलरी बढ़ेगी, अपनी सामान्य EMI को हर साल इतने % बढ़ाते जाएं",

    lumpsumTitle: "बीच-बीच में होने वाले एकमुश्त भुगतान",
    lumpsumSubtitle: "जब भी आपको बोनस, कोप फंड मैच्योरिटी या अन्य फायदा हो, उस विशिष्ट महीने में भुगतान जोड़ें",
    amtLabel: "एकमुश्त भुगतान राशि (₹)",
    monthIndexLabel: "लोन के कौन से महीने में? (जैसे 12 या 24)",
    lumpNoteLabel: "संक्षिप्त विवरण / नोट (वैकल्पिक)",
    lumpPlaceholder: "जैसे: बोनस, जमीन की बिक्री",
    addedMilestonesHeader: "जोड़े गए अतिरिक्त मील के पत्थर",
    noLumpsumLabel: "कोई एकमुश्त मील का पत्थर नहीं जोड़ा गया है।",

    hacksTitle: "लोन जल्दी चुकाने के वैज्ञानिक तरीके",
    hacksSubtitle: "नीचे दी गई किसी भी बचत रणनीति को क्लिक करें और देखें कि आपका लाखों का ब्याज कैसे बचता है",
    magicExplainHeader: "अतिरिक्त भुगतान का वैज्ञानिक जादू कैसे काम करता है?",
    magicExplainText: "लोन के शुरूआती वर्षों में आपके EMI का 70 से 80 फ़ीसदी हिस्सा सिर्फ ब्याज के रूप में बैंक रख लेता है। जब भी आप एक्स्ट्रा पैसे देते हैं, वह सीधे आपके मूलधन को कम करता है जिससे आने वाले सालों का कुल चक्रवृद्दि ब्याज शून्य की तरफ बढ़ जाता है!",

    interestSavedTitle: "कुल ब्याज की शुद्ध बचत",
    pureNetSavingsLabel: "बचाया गया कुल शुद्ध ब्याज:",
    heavyInterestSavingsNote: "बधाई! आपके ब्याज के भार में कमी दर्ज की गई है लगभग",
    prepaymentHelpNote: "ऊपर अतिरिक्त मासिक या वार्षिक भुगतान भरकर अपने कर्ज का ब्याज न्यूनतम करें",
    standardCostLabel: "साधारण ब्याज लागत:",
    newCostLabel: "स्मार्ट प्लान ब्याज लागत:",

    tenureSavedTitle: "कर्जमुक्ति की समय सीमा",
    debtFreeLabel: "लोन खत्म करने में बची अवधि:",
    timeSavingPctNote: "शानदार! आपकी कर्जमुक्ति की समय सीमा कम हो गई है लगभग",
    regularEndDateLabel: "प्रस्तावित अंतिम तिथि:",
    newEndDateLabel: "बचत योजना से अंतिम तिथि:",

    emiDetailsTitle: "मासिक किस्त का लाइव गणित",
    regularEMIItem: "नियमित मासिक EMI:",
    monthlyExtraItem: "मासिक अतिरिक्त जमा:",
    yearlyTopupItem: "वार्षिक EMI टॉप-अप दर:",
    totalPaidStandardItem: "कुल भुगतान (साधारण मार्ग):",
    totalPaidSavingsItem: "कुल भुगतान (बचत योजना मार्ग):",
    motivationalCarNote: "बचत के पैसों से आप नई प्रॉपर्टी, बच्चों की पढ़ाई या नई कार प्लान कर सकते हैं!",

    chartsTitle: "प्रगति और कमी का ग्राफिकल चार्ट",
    chartsSubtitle: "एक नज़र में देखें कि साधारण भुगतान के मुकाबले बचत योजना से लोन कैसे तेजी से खत्म होता है",
    tabBalanceTrend: "लोन बैलेंस की गिरावट",
    tabCostSave: "लागत में कम्पैरिजन",
    chartsStandardLegend: "साधारण ऋण निपटान",
    chartsAcceleratedLegend: "अतिरिक्त भुगतान त्वरित योजना",
    chartInfoTextBalance: "हरी रेखा दर्शाती है कि आपकी बचत योजना से लोन कैसे तेजी से शून्य पर पहुँच जाता है।",
    chartInfoTextCost: "यहाँ ब्याज का पीला हिस्सा है, जो आपकी समझदारी भरे प्री-पेमेंट से काफी छोटा हो जाता है।",

    tableTitle: "विस्तृत भुगतान विवरण तालिका (लेजर)",
    tableSubtitle: "प्रत्येक वर्ष और महीने के खातों की गणितीय गणना जांचें",
    viewYearlyBtn: "वार्षिक सारांश दृश्य",
    viewMonthlyBtn: "महीनेवार विस्तृत विवरण",
    exportCsvBtn: "एक्सेल/CSV सारणी डाउनलोड करें",
    exportPdfBtn: "पीडीएफ (PDF) रिपोर्ट डाउनलोड करें",
    exportJsonBtn: "जेएसओएन (JSON) डेटा डाउनलोड करें",
    searchPlaceholderYearly: "साल खोजें (जैसे: Year 3)...",
    searchPlaceholderMonthly: "महीना या तारीख खोजें (जैसे: Jan 2028)...",
    totalDurationRowText: "कुल भुगतान अवधि का आकार:",
    colYear: "ऋण भुगतान का समय",
    colOpening: "प्रारंभिक बकाया राशि",
    colEMI: "चुकाई गई नियमित EMI",
    colExtra: "अतिरिक्त स्वैच्छिक भुगतान",
    colInterest: "बैंक द्वारा काटा गया ब्याज",
    colPrincipal: "वास्तविक कम हुआ मूलधन",
    colClosing: "शेष बकाया ऋण राशि",
    noRecordsFound: "खोजे गए मूल्य के अनुसार कोई रिकॉर्ड उपलब्ध नहीं है।",
    showingRecordsPrefix: "दिखाए जा रहे लाइन आइटम विवरण",
    btnPrev: "पिछला",
    btnNext: "अगला",
    fullPaidOffLabel: "बधाई! ऋण समाप्त",
  },
  bilingual: {
    appName: "लोनबचत | Loan Saver & Payoff Calculator",
    appSubtitle: "कर्जमुक्ति कैलकुलेटर एवं ब्याज बचत मार्गदर्शिका — आसानी से समझें और लोन जल्दी चुकाएं",
    bilingualBadge: "Bilingual Supported (द्विभाषी)",
    safetyBadge: "100% Save Safe (सुरक्षित)",
    quickBannerText: "5% भुगतान रणनीति से औसतन ₹4.5 लाख का ब्याज और 4 साल की अवधि बचती है!",
    
    step1Title: "1. लोन विवरण दर्ज करें / Input Loan",
    step1Desc: "कैलकुलेटर में अपनी वर्तमान लोन राशि, ब्याज (%) और अवधि डालें।",
    step2Title: "2. अतिरिक्त बचत चुनें / Set Prepayments",
    step2Desc: "नीचे दिए गए एक्स्ट्रा बचत तरीकों (जैसे 1 Extra EMI या 5% टॉप-अप) को लागू करें।",
    step3Title: "3. बचत सहेजें व डाउनलोड करें / Save & Export",
    step3Desc: "बचत रिपोर्ट और सारणी देखें, फिर इसे एक्सेल/CSV के रूप में सहेजने के लिए डाउनलोड करें।",

    analyticsTitle: "लाइव बचत एनालिटिक्स (Real-time Savings)",
    analyticsSubtitle: "जैसे ही आप इनपुट या बचत रणनीति बदलेंगे, आँकड़े तुरंत अपडेट हो जाएंगे",
    resetSavingsBtn: "सभी एक्स्ट्रा भुगतान हटाएँ (Reset Savings)",
    uploadFormatBtn: "अपलोड गाइड (Upload Format)",
    closeBtn: "बंद करें (Close)",
    uploadGuideTitle: "फ़ाइल अपलोड टेम्प्लेट निर्देश (File Format Guide)",
    uploadGuideDesc: "आप प्लेटफार्म में सीधे अपनी पूर्व सहेजी हुई फाइलें (CSV या JSON) अपलोड करके सिमुलेशन चालू कर सकते हैं:",
    csvFormatGuide: "CSV/TXT प्रारूप (CSV Key-Value Pairs)",
    csvFormatNote: "नोट: एक लाइन में की (key) और वैल्यू को कौमा(,) से अलग करके लिखें।",
    jsonFormatGuide: "JSON प्रारूप (Advanced Profile Object)",
    jsonFormatNote: "ये फ़ाइल आप कहीं भी बनाकर `.json` या `.csv` नाम से अपलोड कर सकते हैं।",
    uploadErrorPrefix: "त्रुटी / Upload Error",
    clearBtn: "क्लियर (Clear)",
    extractingDocument: "जेमिनी एआई द्वारा डेटा निकाला जा रहा है / Extracting details with Gemini AI...",
    extractionSuccess: "विवरण सफलतापूर्वक निकाला गया! / Extracted successfully!",
    multiFormatUploadGuide: "आप PDF, JPG, PNG इमेज या JSON/CSV फाइल अपलोड कर सकते हैं / Upload PDF, JPG, PNG images or JSON/CSV files.",

    profileTitle: "ऋण खाता प्रोफ़ाइल (Saved Loan Profiles)",
    profileSubtitle: "अपने विभिन्न लोन प्रोफ़ाइल को सहेजें या रीसेट करें",
    saveCurrentBtn: "नया सहेजें (Save Current)",
    uploadFileBtn: "फ़ाइल अपलोड / Upload (JSON/CSV/PDF/Img)",
    saveProfilePlaceholder: "उदाहरण: Home Loan SBI, Car Loan HDFC",
    saveBtn: "सहेजें (Save)",
    cancelBtn: "रद्द करें (Cancel)",
    noProfilesItem: "कोई प्रोफाइल सहेजी नहीं गई है। सेव का उपयोग करके तुलना करें।",

    loanDetailsTitle: "लोन की मूल जानकारी (Original Loan Details)",
    principalLabel: "कुल लोन राशि / Principal Loan Amount (₹)",
    interestRateLabel: "ब्याज दर / Interest Rate (% P.A.)",
    tenureLabel: "लोन की अवधि / Tenure (Years/साल)",
    startDateLabel: "किस्त शुरू होने का महीना / EMI Start Date",

    plannerTitle: "अतिरिक्त भुगतान योजना (Prepayment / Savings Planner)",
    monthlyExtraLabel: "हर महीने कितना एक्स्ट्रा जमा करेंगे? / Monthly Extra (₹)",
    yearlyExtraLabel: "सालाना अतिरिक्त भुगतान / Yearly Extra (₹)",
    yearlyExtraNote: "हर वर्ष की वर्षगांठ (12वें महीने) पर जमा होगा",
    topupLabel: "हर साल EMI कितनी % बढाएंगे? / EMI Top-Up (%)",
    topupNote: "वेतन वृद्धि (Salary Hike) को सीधे ऋण भुगतान में उपयोग करें",

    lumpsumTitle: "एकमुश्त विशेष भुगतान (One-Time Lump-Sum Payments)",
    lumpsumSubtitle: "यदि आपको बीच में कभी बड़ी राशि मिलनी है (जैसे एलआईसी मैच्योरिटी, जमीन की बिक्री, या बोनस), तो उसे यहाँ जोड़ें",
    amtLabel: "राशि / Amount (₹)",
    monthIndexLabel: "लोन का कौन सा महीना? / Month Index (1 - Max)",
    lumpNoteLabel: "विवरण / Note (Optional)",
    lumpPlaceholder: "उदा. FD Maturity, Bonus",
    addedMilestonesHeader: "जोड़े गए भुगतान (Added Milestones)",
    noLumpsumLabel: "कोई एकमुश्त एक्स्ट्रा पेमेंट नहीं जोड़ा गया है।",

    hacksTitle: "लोन जल्दी खत्म करने के जादुई तरीके (Smart Payoff Strategies)",
    hacksSubtitle: "नीचे दिए गए तरीकों में से किसी को भी चुनें और देखें कि आपका कितना पैसा और समय बचता है",
    magicExplainHeader: "ऐसा क्यों होता है? (Magic of Compound Prepayment)",
    magicExplainText: "शुरुआती सालों में आपके EMI का 70-80% हिस्सा सिर्फ ब्याज (Interest) चुकाने में जाता है, जिससे आपका मूलधन (Principal) बहुत धीरे-धीरे घटता है। जब आप कोई भी अतिरिक्त भुगतान (Extra Payment) करते हैं, तो वह पूरा पैसा सीधे आपके मूलधन (Principal) को घटाने में जाता है। इससे आगे बनने वाला ब्याज नाटकीय रूप से कम हो जाता है और लोन सालों पहले चुकता हो जाता है!",

    interestSavedTitle: "ब्याज की कुल बचत / Interest Saved",
    pureNetSavingsLabel: "आपकी कुल शुद्ध बचत:",
    heavyInterestSavingsNote: "ब्याज में लगभग इतना हिस्सा बचा है:",
    prepaymentHelpNote: "एक्स्ट्रा पेमेंट बढ़ाकर यहाँ ब्याज बचाएं",
    standardCostLabel: "नियमित ब्याज:",
    newCostLabel: "नया ब्याज:",

    tenureSavedTitle: "कर्जमुक्ति अवधि बचत / Tenure Saved",
    debtFreeLabel: "इतने समय पहले ऋण मुक्त होंगे:",
    timeSavingPctNote: "लोन की अवधि काफी जल्दी खत्म होगी लगभग:",
    regularEndDateLabel: "नियमित अंतिम तिथि:",
    newEndDateLabel: "नई अंतिम तिथि:",

    emiDetailsTitle: "EMI विवरण / Monthly Installment",
    regularEMIItem: "नियमित मासिक EMI:",
    monthlyExtraItem: "मासिक अतिरिक्त (Prepay):",
    yearlyTopupItem: "वार्षिक EMI बढ़ोतरी:",
    totalPaidStandardItem: "कुल भुगतान (नियम):",
    totalPaidSavingsItem: "कुल भुगतान (बचत योजना):",
    motivationalCarNote: "बचाई गई राशि से आप एक नई कार, मकान का सुधार या बच्चों की शिक्षा फाइनेंस कर सकते हैं!",

    chartsTitle: "बचत ग्राफ़िकल तुलना (Visual Progress Charts)",
    chartsSubtitle: "समझें कि समय के साथ आपका कर्ज कैसे कम होता है",
    tabBalanceTrend: "लोन बैलेंस / Balance Trend",
    tabCostSave: "लागत तुलना / Cost Save",
    chartsStandardLegend: "Standard Balance (साधारण कर्ज)",
    chartsAcceleratedLegend: "Accelerated Balance (बचत योजना)",
    chartInfoTextBalance: "ग्राफ दिखाता है कि अतिरिक्त पेमेंट करने से लोन कैसे जल्दी खत्म (यानी शून्य पर) हो जाता है। ढलान वाली हरी रेखा समय और ब्याज की भारी राहत को दर्शाती है.",
    chartInfoTextCost: "यहाँ तुलनात्मक कुल लागत देखें। पीली पट्टी दर्शाती है कि आपको बैंक को कितना ब्याज देना होगा। बचत योजना अपनाने से पीला हिस्सा उल्लेखनीय रूप से छोटा हो जाता है!",

    tableTitle: "लोन भुगतान सारणी (Full Amortization Schedule)",
    tableSubtitle: "महीने या साल के हिसाब से अपने मूलधन और ब्याज भुगतानों को ट्रैक करें",
    viewYearlyBtn: "वार्षिक (Yearly Summary)",
    viewMonthlyBtn: "महीनेवार (Monthly detailed)",
    exportCsvBtn: "एक्सेल/CSV डाउनलोड करें",
    exportPdfBtn: "पीडीएफ / PDF डाउनलोड करें",
    exportJsonBtn: "डेटा / JSON डाउनलोड करें",
    searchPlaceholderYearly: "खोजें (e.g., Year 1, 2030)...",
    searchPlaceholderMonthly: "खोजें (e.g., Mar 2028, 14)...",
    totalDurationRowText: "कुल भुगतान अवधि आकार:",
    colYear: "वर्ष (Year)",
    colOpening: "शुरुआती बकाया (Opening Balance)",
    colEMI: "किस्त भुगतान (Scheduled EMI)",
    colExtra: "अतिरिक्त (Extra Prepayment)",
    colInterest: "चुकाया ब्याज (Interest Paid)",
    colPrincipal: "कुल चुकाया मूलधन (Principal Saved)",
    colClosing: "अंतिम बकाया (Closing Balance)",
    noRecordsFound: "खोज के अनुसार कोई भुगतान नहीं मिला।",
    showingRecordsPrefix: "दिखाए जा रहे हैं",
    btnPrev: "पिछला (Prev)",
    btnNext: "अगला (Next)",
    fullPaidOffLabel: "ऋण समाप्त! Paid Off",
  }
};
